@echo off
chcp 65001 >nul
echo ========================================
echo   课业 StudyDeck - ffmpeg 安装工具
echo ========================================
echo.
echo 正在下载 ffmpeg（用于 MKV/AVI 等格式的转码播放）…
echo 下载源：GitHub BtbN 官方构建
echo.
python "%~dp0download_ffmpeg.py"
echo.
if exist "%~dp0ffmpeg.exe" (
    echo [成功] ffmpeg 已安装到程序目录。
    echo 现在可以在设置里指定媒体库目录，播放 MKV/AVI 等格式了。
) else (
    echo [失败] ffmpeg 安装失败，请检查网络后重试。
)
echo.
pause
