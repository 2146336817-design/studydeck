// @ts-check
// 资料库视图：上传 / 文件夹 / 下载 / 打开 / 移动。
// （从 views-task.js 拆出。）
import { I } from './icons.js';
import { S, dbDel, dbGet, dbPut } from './db.js';
import { confirmDialog, openModal, toast } from './ui.js';
import { el, esc, fmtDateTime, fmtSize, uid } from './util.js';
import { render, viewHead } from './viewkit.js';

let resCur='';  // 资料库当前文件夹（模块级，切视图/上传后保留层级）

function viewResources(main){
  const TYPES=['教辅','试卷','笔记','其他'];
  main.innerHTML=viewHead('资料库','收集的电子版教辅、试卷、笔记等，可建文件夹分门别类，全部保存在本机浏览器')+
    '<div style="display:flex;align-items:center;gap:9px;flex-wrap:wrap;margin-bottom:14px">'+
      '<button class="btn btn-primary" id="resAdd">'+I('upload')+' 上传资料</button>'+
      '<button class="btn" id="resUpFolder">'+I('folder')+' 上传文件夹</button>'+
      '<button class="btn" id="resMkDir">'+I('folder')+' 新建文件夹</button>'+
      '<button class="btn" id="resExportAll">'+I('download')+' 全部导出</button>'+
      '<select class="input" id="resType" style="width:auto">'+
        '<option value="all">全部分类</option>'+TYPES.map(t=>'<option value="'+t+'">'+t+'</option>').join('')+
      '</select><span class="small muted" id="resCount"></span></div>'+
    '<div id="resPath" style="margin-bottom:8px"></div>'+
    '<div class="tiny dim" style="margin-bottom:10px">'+I('folder')+' 支持把文件拖拽到本页直接导入当前文件夹；导出用每行的「下载」或上方「全部导出」</div>'+
    '<div id="resList"></div>';
  const list=main.querySelector('#resList');
  const folderById=id=>S.resources.find(r=>r.kind==='folder'&&r.id===id);
  function folderCrumbs(id){
    const out=[];let c=id;const guard=new Set();
    while(c&&!guard.has(c)){guard.add(c);const f=folderById(c);if(!f)break;out.unshift(f);c=f.folder||'';}
    return out;
  }
  function drawPath(){
    const p=main.querySelector('#resPath');if(!p)return;
    const cr=folderCrumbs(resCur);
    p.innerHTML='<span class="small dim">'+I('folder')+' </span><a class="small" data-cr="root" style="cursor:pointer">资料库</a>'+
      cr.map(f=>'<span class="small dim"> / </span><a class="small" data-cr="'+f.id+'" style="cursor:pointer">'+esc(f.name)+'</a>').join('');
    p.querySelectorAll('[data-cr]').forEach(a=>a.onclick=()=>{resCur=a.dataset.cr==='root'?'':a.dataset.cr;draw();});
  }
  const hi=()=>{main.style.outline='2px dashed var(--acc)';main.style.outlineOffset='-6px';main.style.background='var(--bg2)';main.style.borderRadius='12px';};
  const unhi=()=>{main.style.outline='';main.style.outlineOffset='';main.style.background='';main.style.borderRadius='';};
  const draw=()=>{
    const t=(S.route.rId?'all':main.querySelector('#resType').value);
    const folders=S.resources.filter(r=>r.kind==='folder'&&(r.folder||'')===resCur).sort((a,b)=>b.createdAt-a.createdAt);
    let items=S.resources.filter(r=>r.kind!=='folder'&&(r.folder||'')===resCur);
    items=items.filter(r=>t==='all'||r.type===t).sort((a,b)=>b.createdAt-a.createdAt);
    main.querySelector('#resCount').textContent='共 '+S.resources.filter(r=>r.kind!=='folder').length+' 份资料';
    drawPath();
    if(!folders.length&&!items.length){list.innerHTML='<div class="empty">'+I('folder')+'<div class="empty-title">'+(resCur?'这个文件夹还是空的':'还没有资料')+'</div><div>点「上传资料」或把文件拖进来；点「新建文件夹」分类整理</div></div>';return;}
    list.innerHTML=folders.map(f=>
      '<div class="card" style="display:flex;align-items:center;gap:12px;padding:13px 16px;margin-bottom:10px;cursor:pointer" data-fd="'+f.id+'">'+
        '<span style="color:var(--accent);flex:none">'+I('folder')+'</span>'+
        '<div style="flex:1;min-width:0"><div class="ellipsis" style="font-weight:600">'+esc(f.name)+'</div>'+
        '<div class="tiny dim">文件夹 · '+S.resources.filter(r=>r.kind!=='folder'&&r.folder===f.id).length+' 份资料'+(S.resources.filter(r=>r.kind==='folder'&&r.folder===f.id).length>0?' · '+S.resources.filter(r=>r.kind==='folder'&&r.folder===f.id).length+' 个子文件夹':'')+'</div></div>'+
        '<button class="btn btn-sm" data-fopen="'+f.id+'">打开</button>'+
        '<button class="btn btn-sm btn-danger" data-fdel="'+f.id+'">删除</button></div>').join('')+
    items.map(r=>
      '<div class="card" style="display:flex;align-items:center;gap:12px;padding:13px 16px;margin-bottom:10px" data-id="'+r.id+'">'+
        '<span class="pill" style="flex:none">'+esc(r.type||'其他')+'</span>'+
        '<div style="flex:1;min-width:0"><div class="ellipsis" style="font-weight:600">'+esc(r.name)+'</div>'+
        '<div class="tiny dim">'+fmtSize(r.size||0)+' · '+fmtDateTime(r.createdAt)+'</div></div>'+
        '<button class="btn btn-sm" data-open="'+r.id+'">打开</button>'+
        '<button class="btn btn-sm" data-dl="'+r.id+'">下载</button>'+
        '<button class="btn btn-sm" data-mv="'+r.id+'" title="移动到文件夹">'+I('folder')+' 移动</button>'+
        '<button class="btn btn-sm btn-danger" data-del="'+r.id+'">删除</button>'+
      '</div>').join('');
    list.querySelectorAll('[data-fd]').forEach(c=>c.onclick=e=>{if(!e.target.closest('button')){resCur=c.dataset.fd;draw();}});
    list.querySelectorAll('[data-fopen]').forEach(b=>b.onclick=()=>{resCur=b.dataset.fopen;draw();});
    list.querySelectorAll('[data-fdel]').forEach(b=>b.onclick=async()=>{
      const f=S.resources.find(x=>x.id===b.dataset.fdel);
      if(!await confirmDialog('删除文件夹','确定删除文件夹「'+esc(f?f.name:'')+'」吗？里面的资料和子文件夹会移到根目录（资料不删除）','删除'))return;
      const inner=[...S.resources.filter(r=>(r.folder||'')===f.id)];
      for(const it of inner){it.folder='';await dbPut('resources',it);}
      await dbDel('resources',f.id);
      const i=S.resources.findIndex(x=>x.id===f.id);if(i>=0)S.resources.splice(i,1);
      if(resCur===f.id)resCur='';draw();
    });
    list.querySelectorAll('[data-open]').forEach(b=>b.onclick=()=>openResource(b.dataset.open));
    list.querySelectorAll('[data-dl]').forEach(b=>b.onclick=()=>downloadResource(b.dataset.dl));
    list.querySelectorAll('[data-mv]').forEach(b=>b.onclick=()=>moveResource(b.dataset.mv,()=>draw()));
    list.querySelectorAll('[data-del]').forEach(b=>b.onclick=async()=>{
      const r=S.resources.find(x=>x.id===b.dataset.del);
      if(!await confirmDialog('删除资料','确定删除「'+esc(r?r.name:'')+'」吗？其内容将从本机一并删除','删除'))return;
      if(r&&r.kind==='folder-item'){for(const it of (r.files||[]))await dbDel('blobs',it.id);}
      await dbDel('blobs',b.dataset.del);await dbDel('resources',b.dataset.del);
      const i=S.resources.findIndex(x=>x.id===b.dataset.del);if(i>=0)S.resources.splice(i,1);draw();
    });
    if(S.route.rId){const el=list.querySelector('[data-id="'+S.route.rId+'"]');if(el){el.scrollIntoView({behavior:'smooth',block:'center'});el.style.outline='2px solid #0f6b54';el.style.outlineOffset='-2px';}}
  };
  main.querySelector('#resType').onchange=draw;
  main.querySelector('#resMkDir').onclick=()=>{
    const body=el('div');
    body.innerHTML='<div class="field"><input class="input" id="mkDirName" placeholder="文件夹名称，如：数学 / 高三试卷" style="font-size:15px"></div>';
    const foot=document.createDocumentFragment();
    const cancel=el('button','btn','取消'), ok=el('button','btn btn-primary','创建');
    foot.append(cancel,ok);
    const md=openModal({title:'新建文件夹',body,footer:foot,dismissable:false});
    cancel.onclick=()=>md.close();
    ok.onclick=async()=>{
      const name=(body.querySelector('#mkDirName').value||'').trim();
      if(!name){toast('请输入文件夹名称','err');return;}
      ok.disabled=true;
      try{
        const f={id:uid(),kind:'folder',name,folder:resCur||'',createdAt:Date.now()};
        await dbPut('resources',f);S.resources.push(f);
        md.close();draw();
        toast('已创建文件夹「'+name+'」'+(resCur?'（在 '+folderCrumbs(resCur).map(x=>x.name).join(' / ')+' 内）':''),'ok');
      }catch(e){ok.disabled=false;toast('创建失败：'+e.message,'err');}
    };
  };
  main.querySelector('#resAdd').onclick=()=>{
    const inp=document.createElement('input');inp.type='file';inp.multiple=true;
    inp.onchange=async()=>{
      if(!inp.files.length){toast('未选择文件','err');return;}
      const t=await pickTypeAndFiles(Array.from(inp.files));
      if(t)uploadResources(t,Array.from(inp.files),resCur);
    };
    inp.click();
  };
  main.querySelector('#resUpFolder').onclick=()=>{
    const inp=document.createElement('input');inp.type='file';inp.webkitdirectory=true;
    inp.onchange=async()=>{
      const files=Array.from(inp.files||[]);
      if(!files.length){toast('未选择文件夹','err');return;}
      const folderName=(files[0].webkitRelativePath||'').split('/')[0]||'未命名文件夹';
      await uploadFolder(folderName,files,resCur);
    };
    inp.click();
  };
  main.querySelector('#resExportAll').onclick=async()=>{
    const fs=S.resources.filter(r=>r.kind!=='folder');
    if(!fs.length){toast('没有资料可导出','err');return;}
    if(!await confirmDialog('全部导出','将逐份下载全部 '+fs.length+' 份资料到本机下载目录，继续吗？','开始导出'))return;
    for(const r of fs)downloadResource(r.id);
  };
  main.addEventListener('dragover',e=>{e.preventDefault();e.stopPropagation();hi();});
  main.addEventListener('dragleave',e=>{if(e.target===main)unhi();});
  main.addEventListener('drop',async e=>{
    e.preventDefault();e.stopPropagation();unhi();
    const files=e.dataTransfer&&e.dataTransfer.files?Array.from(e.dataTransfer.files):[];
    if(!files.length){toast('未读取到文件','err');return;}
    if(files[0].webkitRelativePath){const folderName=(files[0].webkitRelativePath||'').split('/')[0]||'未命名文件夹';await uploadFolder(folderName,files,resCur);return;}
    const t=await pickTypeAndFiles(files);
    if(t)uploadResources(t,files,resCur);
  });
  draw();
}

async function moveResource(id,after){
  const r=S.resources.find(x=>x.id===id);if(!r)return;
  const folders=S.resources.filter(x=>x.kind==='folder');
  const body=el('div');
  body.innerHTML='<div class="field"><label class="field-label">移动「'+esc(r.name)+'」到</label><select class="input" id="mvTo" style="width:100%">'+
    '<option value="">根目录</option>'+folders.map(f=>'<option value="'+f.id+'">'+esc(f.name)+'</option>').join('')+'</select></div>';
  const foot=document.createDocumentFragment();
  const cancel=el('button','btn','取消'), ok=el('button','btn btn-primary','移动');
  foot.append(cancel,ok);
  const md=openModal({title:'移动资料',body,footer:foot,dismissable:true});
  cancel.onclick=()=>md.close();
  ok.onclick=async()=>{r.folder=body.querySelector('#mvTo').value;await dbPut('resources',r);md.close();toast('已移动','ok');if(after)after();};
}

async function uploadResources(type,files,folder){
  folder=folder||'';
  let ok=0;
  for(const f of files){
    const id=uid();
    try{await dbPut('blobs',{id,blob:f});}
    catch(e){toast('保存失败：'+f.name,'err');continue;}
    const r={id,name:f.name,type,size:f.size,createdAt:Date.now(),folder};
    await dbPut('resources',r);S.resources.push(r);ok++;
  }
  if(ok)toast('已导入 '+ok+' 份资料到「'+type+'」','ok');
  render();
  return ok;
}

async function uploadFolder(folderName,files,parent){
  const items=[];
  for(const f of files){
    const id=uid();
    try{await dbPut('blobs',{id,blob:f});}catch(e){continue;}
    items.push({id,name:f.name,path:f.webkitRelativePath||f.name,size:f.size});
  }
  if(!items.length){toast('保存失败','err');return;}
  const size=items.reduce((s,i)=>s+(i.size||0),0);
  const r={id:uid(),kind:'folder-item',name:folderName,type:'文件夹',size,fileCount:items.length,files:items,createdAt:Date.now(),folder:parent||''};
  await dbPut('resources',r);S.resources.push(r);
  toast('已上传文件夹「'+folderName+'」共 '+items.length+' 个文件','ok');
  render();
}

function pickTypeAndFiles(files){
  const TYPES=['教辅','试卷','笔记','其他'];
  const body=el('div');
  body.innerHTML='<div class="field"><label class="field-label">导入分类 · 共 '+files.length+' 个文件</label><select class="input" id="resUpType" style="width:100%">'+
    TYPES.map(t=>'<option value="'+t+'">'+t+'</option>').join('')+'</select></div>'+
    '<p class="small muted">PDF、图片、文档等均可</p>';
  const foot=document.createDocumentFragment();
  const cancel=el('button','btn','取消'), ok=el('button','btn btn-primary','导入');
  foot.append(cancel,ok);
  const md=openModal({title:'导入资料',body,footer:foot,dismissable:true});
  return new Promise(resolve=>{
    cancel.onclick=()=>{md.close();resolve(null);};
    ok.onclick=()=>{const t=body.querySelector('#resUpType').value;md.close();resolve(t);};
  });
}

async function downloadResource(id){
  const r=S.resources.find(x=>x.id===id);if(!r){toast('文件不存在','err');return;}
  if(r.kind==='folder-item'){
    let n=0;
    for(const it of (r.files||[])){
      const b=await dbGet('blobs',it.id);if(!b)continue;
      const url=URL.createObjectURL(b.blob);
      const a=document.createElement('a');a.href=url;a.download=it.name;document.body.appendChild(a);a.click();a.remove();
      setTimeout(()=>URL.revokeObjectURL(url),60000);n++;
    }
    toast('已开始下载文件夹 '+n+' 个文件','ok');
    return;
  }
  const b=await dbGet('blobs',id); if(!b){toast('文件不存在','err');return;}
  const url=URL.createObjectURL(b.blob);
  const a=document.createElement('a');a.href=url;a.download=r.name||'资料';
  document.body.appendChild(a);a.click();a.remove();
  setTimeout(()=>URL.revokeObjectURL(url),60000);
}

async function openResource(id){
  const r=S.resources.find(x=>x.id===id);if(!r){toast('文件不存在','err');return;}
  if(r.kind==='folder-item'){
    const body=el('div');
    body.innerHTML='<div class="small dim" style="margin-bottom:8px">'+esc(r.name)+' · '+(r.fileCount||0)+' 个文件，点文件名预览，点右侧下载</div><div id="flList"></div>';
    const fl=body.querySelector('#flList');
    const files=r.files||[];
    fl.innerHTML=files.map((it,i)=>
      '<div style="display:flex;align-items:center;gap:10px;padding:8px 6px;border-bottom:1px solid var(--border)">'+
      '<span style="color:var(--text-3)">'+(i+1)+'</span>'+
      '<div style="flex:1;min-width:0;cursor:pointer" data-openf="'+it.id+'"><div class="ellipsis" style="font-weight:600">'+esc(it.name)+'</div>'+
      '<div class="tiny dim">'+esc(it.path)+' · '+fmtSize(it.size||0)+'</div></div>'+
      '<button class="btn btn-sm" data-dlf="'+it.id+'">下载</button></div>').join('')||'<div class="small dim">空文件夹</div>';
    fl.querySelectorAll('[data-openf]').forEach(x=>x.onclick=async()=>{const fb=await dbGet('blobs',x.dataset.openf);if(fb){const u=URL.createObjectURL(fb.blob);window.open(u,'_blank');setTimeout(()=>URL.revokeObjectURL(u),60000);}});
    fl.querySelectorAll('[data-dlf]').forEach(x=>x.onclick=async()=>{const fb=await dbGet('blobs',x.dataset.openf);if(fb){const u=URL.createObjectURL(fb.blob);const a=document.createElement('a');a.href=u;a.download=((files.find(f=>f.id===x.dataset.openf))||{}).name||'file';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),60000);}});
    const foot=document.createDocumentFragment();
    const close=el('button','btn','关闭');foot.append(close);
    const md=openModal({title:'文件夹 · '+r.name,body,footer:foot,wide:true,dismissable:true});
    close.onclick=()=>md.close();
    return;
  }
  const b=await dbGet('blobs',id); if(!b){toast('文件不存在','err');return;}
  const url=URL.createObjectURL(b.blob);
  window.open(url,'_blank');
  setTimeout(()=>URL.revokeObjectURL(url),60000);
}


export { resCur, viewResources, moveResource, uploadResources, uploadFolder, pickTypeAndFiles, downloadResource, openResource };
