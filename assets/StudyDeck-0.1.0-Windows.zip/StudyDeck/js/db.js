// @ts-check
//
// 类型说明：`S` 与各条记录都按 js/types.js 的 typedef 标注，所以
// `S.courses[0].nam`、`log.id`（tasklog 没有 id）这类错误会被 tsc 直接拦下。
// 少数地方用 `any` 是**有意的**：测试里的 IndexedDB 是手写桩，与 DOM 的
// IDB* 类型不兼容，硬套会让类型变成噪音而不是约束。
import { blobsHave, dateKey, todayKey } from './core.js';
import { STORE_KEYS } from './schema.js';

/** @type {any} */
let DB = null;

/* 建表时主键取自 schema.js 的 STORE_KEYS —— 单一真源。
   以前主键字段在这里写一遍、在过滤/读取处再写一遍，tasklog 就是那样写错的
   （它用 key 而不是 id，按 id 过滤会把打卡记录全丢掉）。 */
/** @param {string} store @returns {string} */
const KEY = (store) => /** @type {Record<string,string>} */ (STORE_KEYS)[store] || 'id';

/** 打开/升级数据库连接。@returns {Promise<any>} */
function openDB(){
  /* 用 any 让 resolve() 可以不带参数：JSDoc 里 Promise<void> + res() 会触发 TS2810。 */
  return new Promise(/** @type {any} */ ((/** @type {any} */ res, /** @type {any} */ rej)=>{
    const rq=indexedDB.open('studydeck',6);
    rq.onupgradeneeded=(e)=>{
      const db=/** @type {any} */ (e.target).result;
      if(db.objectStoreNames.contains('mindmaps')) db.deleteObjectStore('mindmaps');
      if(!db.objectStoreNames.contains('courses')) db.createObjectStore('courses',{keyPath:KEY('courses')});
      if(!db.objectStoreNames.contains('episodes')){const s=db.createObjectStore('episodes',{keyPath:KEY('episodes')});s.createIndex('byCourse','courseId',{unique:false});}
      if(!db.objectStoreNames.contains('notes')){const s=db.createObjectStore('notes',{keyPath:KEY('notes')});s.createIndex('byCourse','courseId',{unique:false});}
      if(!db.objectStoreNames.contains('attachments')) db.createObjectStore('attachments',{keyPath:KEY('attachments')});
      if(!db.objectStoreNames.contains('blobs')) db.createObjectStore('blobs',{keyPath:KEY('blobs')});
      if(!db.objectStoreNames.contains('sessions')){const s=db.createObjectStore('sessions',{keyPath:KEY('sessions')});s.createIndex('byStart','start',{unique:false});s.createIndex('byEp','epId',{unique:false});}
      if(!db.objectStoreNames.contains('kv')) db.createObjectStore('kv',{keyPath:KEY('kv')});
      if(!db.objectStoreNames.contains('mistakes')) db.createObjectStore('mistakes',{keyPath:KEY('mistakes')});
      if(!db.objectStoreNames.contains('tasks')) db.createObjectStore('tasks',{keyPath:KEY('tasks')});
      if(!db.objectStoreNames.contains('tasklog')) db.createObjectStore('tasklog',{keyPath:KEY('tasklog')});
      if(!db.objectStoreNames.contains('resources')) db.createObjectStore('resources',{keyPath:KEY('resources')});
    };
    rq.onsuccess=()=>{DB=rq.result;res();};
    rq.onerror=()=>rej(rq.error);
  }));
}

/**
 * 在一个 object store 上跑一次操作。
 * @param {string} store
 * @param {IDBTransactionMode} mode
 * @param {(s:any)=>any} fn
 * @returns {Promise<any>}
 */
function tx(store, mode, fn){
  return new Promise((res,rej)=>{
    const t=DB.transaction(store,mode); const s=t.objectStore(store);
    const r=fn(s); const ret=undefined;
    if(r&&r.onsuccess!==undefined){ r.onsuccess=()=>res(r.result); r.onerror=()=>rej(r.error); }
    else { t.oncomplete=()=>res(ret); }
    t.onerror=()=>rej(t.error); t.onabort=()=>rej(t.error);
  });
}

/** @param {string} store @returns {Promise<any[]>} */
const dbAll=store=>tx(store,'readonly',s=>s.getAll());

/** @param {string} store @param {string} id @returns {Promise<any>} */
const dbGet=(store,id)=>tx(store,'readonly',s=>s.get(id));

/** @param {string} store @param {any} o @returns {Promise<any>} */
const dbPut=(store,o)=>tx(store,'readwrite',s=>s.put(o));

/**
 * @param {string} store
 * @param {any[]} arr
 * @returns {Promise<void>}
 */
function dbPutMany(store, arr){return new Promise((res,rej)=>{
  const t=DB.transaction(store,'readwrite'),s=t.objectStore(store);
  arr.forEach(o=>s.put(o)); t.oncomplete=()=>res(); t.onerror=()=>rej(t.error);});}
/** @param {string} store @param {string} id @returns {Promise<any>} */
const dbDel=(store,id)=>tx(store,'readwrite',s=>s.delete(id));

/** @param {string} store @returns {Promise<any>} */
const dbClear=store=>tx(store,'readwrite',s=>s.clear());

/** @param {string} key @returns {Promise<any>} */
const kvGet=async key=>{const r=await dbGet('kv',key);return r?r.value:undefined;};

/** @param {string} key @param {any} value @returns {Promise<any>} */
const kvSet=(key,value)=>dbPut('kv',{key,value});

/* 持久化设置。放在数据层而不是视图层：
   它只是把 S.settings 写回 kv —— 放到 views-dispatch 会让 ui.js 反向依赖整个视图层
   （ui → views-dispatch → app → ui 的环），弹窗模块不该为了存个设置去拉进全部视图。 */
async function saveSettings(){ await kvSet('settings', S.settings); }


/* 全局状态。

   注意：初始值里**不要**调用 todayKey()/pad2() 这类 util 的函数。
   · 这里处于模块求值期。db 现在只依赖 core.js（零依赖的叶子），**不再是 import 环**
     （历史上的 db ⇄ util 环已随 core.js 拆分消除，`npm run cycle` 会守住这一点）。
     但求值期调用仍然是坏主意：换个入口顺序、或将来有人把纯函数挪回 util，
     TDZ 风险就会回来（见 tools/eval-order-check.mjs）。
   · 更要紧的是：那样算出来的日期在页面加载时就定死了，程序开过午夜也不会更新，
     周视图/月视图会停在昨天。
   所以这两个"今天/本月"的默认值改为惰性：读取处一律用 `S.ui.task.day || todayKey()` 兜底
   （views-task.js 里已经是这么写的），切页时显式赋值即可。 */
/** @type {import('./types.js').AppState} */
const S={courses:[],episodes:[],notes:[],attachments:[],sessions:[],mistakes:[],tasks:[],tasklog:[],resources:[],proxy:false,settings:{
  theme:'light', dailyGoal:60, autoLocal:true, autoNext:true, biliMode:'auto', biliQn:80, sessdata:'', timerTickSound:false, autoBackup:true, showCountdown:true, countdownDate:''
}, route:{name:'dashboard'}, ui:{courseFilter:'all', epFilter:'all', noteCourse:'all', noteQuery:'', mist:{subject:'all',chapter:'all',point:'all',status:'all',q:''}, task:{tab:'daily',day:'',month:''}}};

async function loadAll(){
  const [c,e,n,a,ss,mk,tk,tl,rs,set,bl] = await Promise.all([
    dbAll('courses'),dbAll('episodes'),dbAll('notes'),dbAll('attachments'),dbAll('sessions'),dbAll('mistakes'),dbAll('tasks'),dbAll('tasklog'),dbAll('resources'),kvGet('settings'),dbAll('blobs')
  ]);
  S.courses=c; S.episodes=e; S.notes=n; S.attachments=a; S.sessions=ss; S.mistakes=mk; S.tasks=tk; S.tasklog=tl; S.resources=rs;
  blobsHave.clear(); for(const b of bl) if(b&&b.blob) blobsHave.add(b.id);
  if(set) Object.assign(S.settings,set);
  /* 排序字段在类型上都是可选的（旧备份可能缺），所以一律给兜底值 ——
     既消掉"possibly undefined"，也把"缺字段时按什么排"写明确了。 */
  S.courses.sort((a,b)=>((a.sort??a.createdAt)||0)-((b.sort??b.createdAt)||0));
  S.episodes.sort((a,b)=> a.courseId===b.courseId ? (a.order||0)-(b.order||0) : (a.courseId<b.courseId?-1:1));
  S.notes.sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0));
  S.sessions.sort((a,b)=>(b.start||0)-(a.start||0));
  S.mistakes.sort((a,b)=>((b.wrongAt||b.createdAt)||0)-((a.wrongAt||a.createdAt)||0));
  S.tasks.sort((a,b)=>((a.order||0)-(b.order||0))||((a.createdAt||0)-(b.createdAt||0)));
}

/** @param {string} cid @returns {import('./types.js').Episode[]} */
const epsOf=cid=> S.episodes.filter(e=>e.courseId===cid).sort((a,b)=>(a.order||0)-(b.order||0));

/** @param {string} cid @returns {import('./types.js').Course|undefined} */
const courseOf=cid=> S.courses.find(c=>c.id===cid);

/* 防御缺字段的笔记记录：epIds 可能来自手工改过/旧版本的备份而缺失，
   不设防时 n.epIds.includes() 会直接抛异常（打开分集笔记面板时触发）。 */
/** @param {string} epid @returns {import('./types.js').Note[]} */
const notesOfEp=epid=> S.notes.filter(n=>Array.isArray(n.epIds)&&n.epIds.includes(epid));

/** @param {string} nid @returns {import('./types.js').Attachment[]} */
const attsOfNote=nid=> S.attachments.filter(a=>a.noteId===nid).sort((a,b)=>(a.createdAt||0)-(b.createdAt||0));

/** @param {string} cid @returns {{total:number,done:number,pct:number}} */
function courseProgress(cid){const eps=epsOf(cid); const total=eps.length;
  const done=eps.filter(e=>e.status===2).length; return {total,done,pct:total?Math.round(done/total*100):0};}

/** @returns {Record<string,number>} 每天的学习秒数 */
function learnedByDay(){ /** @type {Record<string,number>} */ const m=/** @type {any} */ ({}); S.sessions.forEach(s=>{const k=dateKey(s.end||s.start||0);m[k]=(m[k]||0)+(s.sec||0);});return m;}

/** @param {number} t0 @param {number} t1 @returns {number} */
function learnedBetween(t0,t1){return S.sessions.reduce((sum,s)=>{const t=s.end||s.start||0;return (t>=t0&&t<t1)?sum+(s.sec||0):sum;},0);}

/** 连续学习天数。
 *  注意：dateKey() 接受**毫秒时间戳**，所以 Date 对象要显式 .getTime()；
 *  session 的 end/start 在类型上可选，因此用 ?? 0 兜底（不能留 undefined）。 */
function calcStreak(){
  const days=new Set(S.sessions.map(s=>dateKey(s.end??s.start??0)));
  let streak=0; let cur=todayKey();
  if(!days.has(cur)){ // 今天还没学则从昨天起算不断签
    const d=new Date(); d.setDate(d.getDate()-1); cur=dateKey(d.getTime());
  }
  while(days.has(cur)){streak++; const d=new Date(cur+'T00:00:00'); d.setDate(d.getDate()-1); cur=dateKey(d.getTime());}
  return streak;
}

/* ============ Toast / Modal ============ */

export { S, attsOfNote, calcStreak, courseOf, courseProgress, dbAll, dbClear, dbDel, dbGet, dbPut, dbPutMany, epsOf, kvGet, kvSet, learnedBetween, learnedByDay, loadAll, notesOfEp, openDB, saveSettings };
