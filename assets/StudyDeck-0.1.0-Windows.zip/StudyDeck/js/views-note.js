import { I } from './icons.js';
import { S, attsOfNote, courseOf, dbDel, dbGet, dbPut } from './db.js';
import { confirmDialog, openModal, toast } from './ui.js';
import { $, MK_STATUS, attsOfMk, el, esc, fmtDateTime, fmtSize, humanAgo, md2html, mkStatusOf, openAttachment, rangeText, safeColor, todayKey, uid } from './util.js';
import { render, viewHead } from './viewkit.js';
import { noteForm } from './player.js';
import { aiAnalyzeMistake, aiConfigured, showAiResult } from './ai.js';

function viewNotes(main){
  if(S.route.note){const t=S.notes.find(n=>n.id===S.route.note);if(t)S.ui.noteCourse=t.courseId||'all';}
  main.innerHTML=
    viewHead('笔记','文字、图片、PDF 都保存在本机，按课程与分集整理',
      '<button class="btn btn-primary" id="newNote">'+I('plus')+' 写笔记</button>')+
    '<div class="notes-layout"><div class="card notes-side" id="noteSide"></div><div id="noteMain"></div></div>';
  main.querySelector('#newNote').onclick=()=>{
    if(!S.courses.length){toast('请先创建课程','err');location.hash='#/courses';return;}
    noteForm({courseId:S.ui.noteCourse==='all'?S.courses[0].id:S.ui.noteCourse});
  };
  const side=main.querySelector('#noteSide');
  const sideItems=[{id:'all',name:'全部笔记',icon:'note'},...S.courses.map(c=>({id:c.id,name:c.name,icon:'book',color:c.color}))];
  side.innerHTML=sideItems.map(it=>'<div class="nav-item '+(S.ui.noteCourse===it.id?'active':'')+'" data-id="'+it.id+'">'+
    (it.color?'<span style="width:9px;height:9px;border-radius:3px;background:'+safeColor(it.color)+';display:inline-block"></span>':I(it.icon))+
    '<span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">'+esc(it.name)+'</span><span style="margin-left:auto;font-size:11px;color:var(--text-3)">'+
    (it.id==='all'?S.notes.length:S.notes.filter(n=>n.courseId===it.id).length)+'</span></div>').join('')+
    '<div class="nav-sep"></div><div style="padding:4px 10px"><input class="input" id="noteQ" placeholder="搜索笔记…" value="'+esc(S.ui.noteQuery)+'"></div>';
  side.querySelectorAll('.nav-item[data-id]').forEach(d=>d.onclick=()=>{S.ui.noteCourse=d.dataset.id;render();});
  side.querySelector('#noteQ').oninput=e=>{S.ui.noteQuery=e.target.value;drawNotes();};
  function drawNotes(){
    let list=[...S.notes];
    if(S.ui.noteCourse!=='all')list=list.filter(n=>n.courseId===S.ui.noteCourse);
    const q=S.ui.noteQuery.trim().toLowerCase();
    if(q)list=list.filter(n=>(n.title+' '+n.text).toLowerCase().includes(q));
    list.sort((a,b)=>b.updatedAt-a.updatedAt);
    const box=main.querySelector('#noteMain');
    if(!list.length){box.innerHTML='<div class="empty">'+I('note')+'<div class="empty-title">'+(S.notes.length?'没有匹配的笔记':'还没有笔记')+'</div><div>听课中的要点、截图、课件 PDF 都可以收在这里</div></div>';return;}
    box.innerHTML=list.map(n=>{
      const c=courseOf(n.courseId);const atts=attsOfNote(n.id);
      return '<div class="card note-item" data-id="'+n.id+'"><div class="ni-title">'+esc(n.title)+'</div>'+
        '<div class="ni-meta"><span style="display:inline-flex;align-items:center;gap:5px">'+(c?'<span style="width:8px;height:8px;border-radius:2px;background:'+safeColor(c.color)+'"></span>'+esc(c.name):'未分类')+'</span>'+
        '<span>'+rangeText(n.epIds,n.courseId)+'</span><span>'+humanAgo(n.updatedAt)+'</span></div>'+
        '<div class="ni-text">'+esc((n.text||'').replace(/[#>*`-]/g,'').slice(0,180)||'（无文字内容）')+'</div>'+
        (atts.length?'<div class="att-strip">'+atts.slice(0,6).map(a=>'<span class="att-chip">'+((a.type||'').startsWith('image/')?I('image'):I('file'))+'<span>'+esc(a.name)+'</span></span>').join('')+(atts.length>6?'<span class="att-chip">+'+(atts.length-6)+'</span>':'')+'</div>':'')+'</div>';
    }).join('');
    box.querySelectorAll('.note-item').forEach(it=>it.onclick=()=>noteForm({note:S.notes.find(n=>n.id===it.dataset.id)}));
    box.querySelectorAll('.att-chip').forEach(()=>{});
    if(S.route.note){const it=box.querySelector('[data-id="'+S.route.note+'"]');if(it)it.click();}
  }
  drawNotes();
}

/* ================================================================
 * 错题本模块
 * ================================================================ */

function mkSubjects(){return [...new Set(S.mistakes.map(m=>m.subject).filter(Boolean))].sort();}

function mkChapters(sub){return [...new Set(S.mistakes.filter(m=>!sub||sub==='all'||m.subject===sub).map(m=>m.chapter).filter(Boolean))].sort();}

function mkPoints(sub,ch){const s=new Set();S.mistakes.forEach(m=>{if((!sub||sub==='all'||m.subject===sub)&&(!ch||ch==='all'||m.chapter===ch))(m.points||[]).forEach(x=>s.add(x));});return [...s].sort();}

function mkFiltered(){
  const u=S.ui.mist;let list=[...S.mistakes];
  if(u.subject!=='all')list=list.filter(m=>m.subject===u.subject);
  if(u.chapter!=='all')list=list.filter(m=>m.chapter===u.chapter);
  if(u.point!=='all')list=list.filter(m=>(m.points||[]).includes(u.point));
  if(u.status!=='all')list=list.filter(m=>m.status===+u.status);
  const q=(u.q||'').trim().toLowerCase();
  if(q)list=list.filter(m=>[m.subject,m.chapter,m.stem,m.analysis,(m.points||[]).join(' ')].join(' ').toLowerCase().includes(q));
  list.sort((a,b)=>(b.wrongAt||b.createdAt)-(a.wrongAt||a.createdAt));
  return list;
}

function viewMistakes(main){
  const u=S.ui.mist;
  if(S.route.mId){const m=S.mistakes.find(x=>x.id===S.route.mId);if(m){u.subject=m.subject||'all';u.chapter='all';u.point='all';u.status='all';}}
  main.innerHTML=
    viewHead('错题本','按学科、章节、知识点整理错题；图片、PDF 试卷与解析都保存在本机',
      '<button class="btn btn-primary" id="newMk">'+I('plus')+' 收录错题</button>')+
    '<div class="notes-layout"><div class="card notes-side" id="mkSide"></div><div id="mkMain"></div></div>';
  main.querySelector('#newMk').onclick=()=>mistakeForm({});
  /* 侧栏：状态 + 学科 + 搜索 */
  const side=main.querySelector('#mkSide');
  const cnt=v=>v==='all'?S.mistakes.length:S.mistakes.filter(m=>m.status===+v).length;
  let sh='<div class="mk-side-group">掌握状态</div>';
  [['all','全部'],['0','待复习'],['1','复习中'],['2','已掌握']].forEach(([v,n])=>{
    sh+='<div class="nav-item '+(u.status===v?'active':'')+'" data-status="'+v+'"><span>'+n+'</span><span class="mk-count">'+cnt(v)+'</span></div>';
  });
  sh+='<div class="mk-side-group">学科</div>';
  sh+='<div class="nav-item '+(u.subject==='all'?'active':'')+'" data-subject="all"><span>全部学科</span><span class="mk-count">'+S.mistakes.length+'</span></div>';
  mkSubjects().forEach(s=>{
    sh+='<div class="nav-item '+(u.subject===s?'active':'')+'" data-subject="'+esc(s)+'"><span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">'+esc(s)+'</span><span class="mk-count">'+S.mistakes.filter(m=>m.subject===s).length+'</span></div>';
  });
  sh+='<div class="nav-sep"></div><div style="padding:4px 10px"><input class="input" id="mkQ" placeholder="搜索题干 / 知识点…" value="'+esc(u.q)+'"></div>';
  side.innerHTML=sh;
  side.querySelectorAll('[data-status]').forEach(d=>d.onclick=()=>{u.status=d.dataset.status;render();});
  side.querySelectorAll('[data-subject]').forEach(d=>d.onclick=()=>{u.subject=d.dataset.subject;u.chapter='all';u.point='all';render();});
  side.querySelector('#mkQ').oninput=e=>{u.q=e.target.value;drawList();};
  /* 右栏：章节 / 知识点筛选条 + 卡片网格 */
  const chs=mkChapters(u.subject),pts=mkPoints(u.subject,u.chapter);
  const box=main.querySelector('#mkMain');
  box.innerHTML='<div class="mk-filterbar">'+
      '<select class="select" id="mkFCh"><option value="all">全部章节</option>'+chs.map(c=>'<option value="'+esc(c)+'"'+(u.chapter===c?' selected':'')+'>'+esc(c)+'</option>').join('')+'</select>'+
      '<select class="select" id="mkFPt"><option value="all">全部知识点</option>'+pts.map(c=>'<option value="'+esc(c)+'"'+(u.point===c?' selected':'')+'>'+esc(c)+'</option>').join('')+'</select>'+
      '<span class="small dim" id="mkCountL"></span></div><div id="mkGrid"></div>';
  box.querySelector('#mkFCh').onchange=e=>{u.chapter=e.target.value;u.point='all';render();};
  box.querySelector('#mkFPt').onchange=e=>{u.point=e.target.value;drawList();};
  function drawList(){
    const list=mkFiltered();
    main.querySelector('#mkCountL').textContent='共 '+list.length+' 题';
    const grid=main.querySelector('#mkGrid');
    if(!list.length){
      grid.outerHTML='<div class="empty" id="mkGrid">'+I('target')+'<div class="empty-title">'+(S.mistakes.length?'没有匹配的错题':'还没有收录错题')+'</div><div>拍照、截图、PDF 试卷都可以收录，按章节与知识点归类复习</div><button class="btn btn-primary" id="mkEmptyAdd" style="margin-top:14px">'+I('plus')+' 收录第一题</button></div>';
      const b=main.querySelector('#mkEmptyAdd');if(b)b.onclick=()=>mistakeForm({});
      return;
    }
    if(grid.tagName!=='DIV'||grid.classList.contains('empty'))grid.outerHTML='<div id="mkGrid"></div>';
    const g2=main.querySelector('#mkGrid');
    g2.className='mk-grid';
    g2.innerHTML=list.map(m=>{
      const st=mkStatusOf(m.status),atts=attsOfMk(m.id),nImg=atts.filter(a=>(a.type||'').startsWith('image/')).length;
      return '<div class="card mk-card s'+m.status+'" data-id="'+m.id+'">'+
        '<div class="mk-crumb"><span style="color:var(--accent-text);background:var(--accent-soft);padding:1px 8px;border-radius:5px">'+esc(m.subject||'未分类')+'</span>'+
        (m.chapter?'<span>· '+esc(m.chapter)+'</span>':'')+'</div>'+
        (m.stem?'<div class="mk-stem">'+esc(m.stem)+'</div>':'<div class="mk-stem dim">（无题干文字，见附件）</div>')+
        ((m.points||[]).length?'<div class="mk-points">'+m.points.map(x=>'<span class="point-tag">'+esc(x)+'</span>').join('')+'</div>':'')+
        '<div class="mk-foot"><span class="tiny dim">'+(nImg?I('image')+' '+nImg+' 图 · ':'')+(atts.length-nImg?I('file')+' '+(atts.length-nImg)+' 文件 · ':'')+humanAgo(m.wrongAt||m.createdAt)+'</span>'+
        '<span class="mk-status-pill" data-st="'+m.id+'" style="background:'+st.color+'">'+st.name+'</span></div></div>';
    }).join('');
    g2.querySelectorAll('.mk-card').forEach(c=>c.onclick=()=>{const l=mkFiltered();mistakeDetail(l.findIndex(x=>x.id===c.dataset.id),l);});
    g2.querySelectorAll('[data-st]').forEach(p=>p.onclick=e=>{e.stopPropagation();const m=S.mistakes.find(x=>x.id===p.dataset.st);m.status=(m.status+1)%3;m.updatedAt=Date.now();dbPut('mistakes',m);drawList();});
  }
  drawList();
  if(S.route.mId){const l=mkFiltered();const i=l.findIndex(x=>x.id===S.route.mId);if(i>=0)mistakeDetail(i,l);}
}

/* 知识点标签编辑器 */

function pointEditor(box, points){
  function draw(){
    box.innerHTML=points.map((x,i)=>'<span class="point-tag">'+esc(x)+'<i class="tag-x" data-i="'+i+'">×</i></span>').join('')+
      '<input placeholder="输入知识点后回车（如：二次函数）">';
    box.querySelectorAll('.tag-x').forEach(x=>x.onclick=()=>{points.splice(+x.dataset.i,1);draw();});
    const inp=box.querySelector('input');
    inp.onkeydown=e=>{
      if(e.key==='Enter'||e.key===','||e.key==='，'){e.preventDefault();const v=inp.value.trim().replace(/,$/,'');if(v&&!points.includes(v))points.push(v);inp.value='';draw();box.querySelector('input').focus();}
      else if(e.key==='Backspace'&&!inp.value&&points.length){points.pop();draw();box.querySelector('input').focus();}
    };
  }
  draw();
}

function mistakeForm(opt){
  const isNew=!opt.mk;
  const mk=opt.mk||{id:uid(),subject:opt.subject||'',chapter:'',points:[],stem:'',analysis:'',status:0,wrongAt:Date.now(),createdAt:Date.now(),updatedAt:Date.now()};
  const wrap=el('div');
  wrap.innerHTML=
    '<div class="field"><div style="display:flex;gap:9px;flex-wrap:wrap">'+
      '<div style="flex:1;min-width:150px"><label class="field-label">学科 <span style="color:var(--danger)">*</span></label><input class="input" id="mfSub" list="dlMkSub" placeholder="如：数学" value="'+esc(mk.subject)+'"><datalist id="dlMkSub">'+mkSubjects().map(s=>'<option value="'+esc(s)+'">').join('')+'</datalist></div>'+
      '<div style="flex:1;min-width:150px"><label class="field-label">章节</label><input class="input" id="mfCh" list="dlMkCh" placeholder="如：第三章 函数" value="'+esc(mk.chapter)+'"><datalist id="dlMkCh"></datalist></div></div></div>'+
    '<div class="field"><label class="field-label">知识点（回车添加，可多个）</label><div class="tag-editor" id="mfPts"></div></div>'+
    '<div class="field"><label class="field-label">题干 / 错因简述（可留空，直接传图也行）</label><textarea class="textarea" id="mfStem" style="min-height:80px" placeholder="题目原文、错误选项、当时怎么错的…"></textarea></div>'+
    '<div class="field"><label class="field-label">正解与复盘</label><div style="display:flex;gap:7px;margin-bottom:7px"><div class="filter-chip on" id="mfTabEdit">编辑</div><div class="filter-chip" id="mfTabPrev">预览</div></div>'+
      '<div id="mfEditBox"><textarea class="textarea" id="mfAna" style="min-height:150px" placeholder="正确解法、关键步骤、复盘结论，支持简单 Markdown"></textarea></div>'+
      '<div id="mfPrevBox" style="display:none"><div class="card md-preview" id="mfPrev" style="padding:14px;min-height:150px"></div></div></div>'+
    '<div class="field"><label class="field-label">附件：题目照片、试卷 / 解析 PDF 等，保存在本机</label>'+
      '<div class="drop-zone" id="mfDrop">'+I('upload')+'<div style="margin-top:5px">点击选择，或直接把图片 / PDF 拖到这里</div></div>'+
      '<div id="mfAtts" style="margin-top:9px"></div></div>'+
    '<div class="field" style="margin-bottom:0"><label class="field-label">掌握状态</label><div style="display:flex;gap:8px" id="mfStatus">'+
      MK_STATUS.map(s=>'<button type="button" class="filter-chip '+(mk.status===s.v?'on':'')+'" data-v="'+s.v+'">'+s.name+'</button>').join('')+'</div></div>';
  const $s=id=>wrap.querySelector(id);
  $s('#mfStem').value=mk.stem;$s('#mfAna').value=mk.analysis||'';
  const points=[...(mk.points||[])];
  pointEditor($s('#mfPts'),points);
  function refreshChDl(){const sub=$s('#mfSub').value.trim();$s('#dlMkCh').innerHTML=mkChapters(sub).filter(c=>c!==$s('#mfCh').value.trim()).map(c=>'<option value="'+esc(c)+'">').join('');}
  $s('#mfSub').oninput=refreshChDl;refreshChDl();
  $s('#mfTabEdit').onclick=()=>{$s('#mfEditBox').style.display='';$s('#mfPrevBox').style.display='none';$s('#mfTabEdit').classList.add('on');$s('#mfTabPrev').classList.remove('on');};
  $s('#mfTabPrev').onclick=()=>{$s('#mfEditBox').style.display='none';$s('#mfPrevBox').style.display='';$s('#mfTabPrev').classList.add('on');$s('#mfTabEdit').classList.remove('on');$s('#mfPrev').innerHTML=md2html($s('#mfAna').value)||'<span class="dim">暂无内容</span>';};
  $s('#mfStatus').querySelectorAll('button').forEach(b=>b.onclick=()=>{mk.status=+b.dataset.v;$s('#mfStatus').querySelectorAll('button').forEach(x=>x.classList.toggle('on',+x.dataset.v===mk.status));});
  /* 附件（复用 blobs / attachments，归属记录在 noteId，kind 标记错题） */
  const attIds=attsOfMk(mk.id).map(a=>a.id);
  async function addFiles(files){
    for(const f of files){
      const id=uid();
      await dbPut('blobs',{id,blob:f});
      const att={id,noteId:mk.id,kind:'mistake',name:f.name,type:f.type||'application/octet-stream',size:f.size,createdAt:Date.now()};
      await dbPut('attachments',att);S.attachments.push(att);attIds.push(id);
    }
    drawAtts();
  }
  async function removeAtt(id){
    await dbDel('blobs',id);await dbDel('attachments',id);
    const i=S.attachments.findIndex(a=>a.id===id);if(i>=0)S.attachments.splice(i,1);
    const j=attIds.indexOf(id);if(j>=0)attIds.splice(j,1);drawAtts();
  }
  function drawAtts(){
    const list=attIds.map(id=>S.attachments.find(a=>a.id===id)).filter(Boolean);
    $s('#mfAtts').innerHTML=list.map(a=>{
      const isImg=(a.type||'').startsWith('image/');
      return '<div class="att-list-row" data-id="'+a.id+'"><div class="att-thumb">'+(isImg?I('image'):(a.type==='application/pdf'?I('pdf'):I('file')))+'</div>'+
        '<div class="att-main"><div class="att-name">'+esc(a.name)+'</div><div class="att-size">'+fmtSize(a.size)+'</div></div>'+
        '<button class="icon-btn" data-open title="预览">'+I('eye')+'</button><button class="icon-btn danger" data-del title="移除">'+I('trash')+'</button></div>';
    }).join('');
    $s('#mfAtts').querySelectorAll('.att-list-row').forEach(r=>{
      r.querySelector('[data-open]').onclick=()=>openAttachment(S.attachments.find(a=>a.id===r.dataset.id));
      r.querySelector('[data-del]').onclick=()=>removeAtt(r.dataset.id);
    });
  }
  drawAtts();
  const dz=$s('#mfDrop');
  dz.onclick=()=>{const inp=document.createElement('input');inp.type='file';inp.multiple=true;inp.accept='image/*,application/pdf,.doc,.docx,.ppt,.pptx,.txt';inp.onchange=()=>addFiles([...inp.files]);inp.click();};
  ['dragover','dragenter'].forEach(ev=>dz.addEventListener(ev,e=>{e.preventDefault();dz.classList.add('drag');}));
  ['dragleave','drop'].forEach(ev=>dz.addEventListener(ev,e=>{e.preventDefault();dz.classList.remove('drag');}));
  dz.addEventListener('drop',e=>addFiles([...e.dataTransfer.files]));

  const foot=document.createDocumentFragment();
  let delBtn;
  if(!isNew){delBtn=el('button','btn btn-danger',I('trash')+' 删除');delBtn.type='button';delBtn.style.marginRight='auto';foot.appendChild(delBtn);}
  const cancel=el('button','btn','取消');cancel.type='button';
  const ok=el('button','btn btn-primary',I('save')+' 保存');ok.type='button';
  foot.append(cancel,ok);
  const md=openModal({title:isNew?'收录错题':'编辑错题',body:wrap,footer:foot,wide:true});
  cancel.onclick=async()=>{if(isNew){for(const id of attIds){await dbDel('blobs',id);await dbDel('attachments',id);}}md.close();};
  ok.onclick=async()=>{
    mk.subject=$s('#mfSub').value.trim();mk.chapter=$s('#mfCh').value.trim();
    mk.points=points;mk.stem=$s('#mfStem').value;mk.analysis=$s('#mfAna').value;
    if(!mk.subject){toast('请填写学科','err');return;}
    if(!mk.stem.trim()&&!mk.analysis.trim()&&!attIds.length){toast('题干、解析或附件至少填一项','err');return;}
    mk.updatedAt=Date.now();if(isNew)mk.wrongAt=Date.now();
    await dbPut('mistakes',mk);
    const i=S.mistakes.findIndex(x=>x.id===mk.id);
    if(i>=0)S.mistakes[i]=mk;else S.mistakes.push(mk);
    S.mistakes.sort((a,b)=>(b.wrongAt||b.createdAt)-(a.wrongAt||a.createdAt));
    md.close();render();toast('错题已保存','ok');
  };
  if(delBtn)delBtn.onclick=async()=>{
    const okd=await confirmDialog('删除错题','确定删除这道错题及其全部附件吗？','删除');if(!okd)return;
    for(const id of attIds){await dbDel('blobs',id);await dbDel('attachments',id);}
    await dbDel('mistakes',mk.id);
    const i=S.mistakes.findIndex(x=>x.id===mk.id);if(i>=0)S.mistakes.splice(i,1);
    md.close();render();toast('已删除','ok');
  };
}

/* 错题详情（只读 + 状态流转 + 上下题） */

function mistakeDetail(idx,list){
  if(!list||!list.length)return;
  idx=Math.max(0,Math.min(idx,list.length-1));
  const mk=list[idx];const st=mkStatusOf(mk.status);
  const atts=attsOfMk(mk.id),imgs=atts.filter(a=>(a.type||'').startsWith('image/')),others=atts.filter(a=>!(a.type||'').startsWith('image/'));
  const wrap=el('div');
  wrap.innerHTML=
    '<div style="display:flex;align-items:center;gap:9px;flex-wrap:wrap;margin-bottom:4px">'+
      '<span style="font-weight:700;font-size:15px">'+esc(mk.subject)+'</span>'+
      (mk.chapter?'<span class="small dim">· '+esc(mk.chapter)+'</span>':'')+
      '<span class="mk-status-pill" style="background:'+st.color+';margin-left:auto">'+st.name+'</span></div>'+
    ((mk.points||[]).length?'<div class="mk-points" style="margin-top:8px">'+mk.points.map(x=>'<span class="point-tag">'+esc(x)+'</span>').join('')+'</div>':'')+
    (mk.stem?'<div class="mk-detail-sec"><div class="sec-lab">题干 / 错因</div><div class="mk-stem-full">'+esc(mk.stem)+'</div></div>':'')+
    (imgs.length?'<div class="mk-detail-sec"><div class="sec-lab">'+I('image')+' 题目图片（点击放大）</div><div class="mk-imgs" id="mdImgs"></div></div>':'')+
    (others.length?'<div class="mk-detail-sec"><div class="sec-lab">'+I('file')+' PDF / 文档（点击打开）</div><div id="mdFiles"></div></div>':'')+
    (mk.analysis?'<div class="mk-detail-sec"><div class="sec-lab">正解与复盘</div><div class="card md-preview" style="padding:14px">'+md2html(mk.analysis)+'</div></div>':'')+
    '<div class="small dim" style="margin-top:14px">收录于 '+fmtDateTime(mk.wrongAt||mk.createdAt)+' · 更新 '+humanAgo(mk.updatedAt)+'</div>';
  const foot=document.createDocumentFragment();
  const prev=el('button','btn btn-sm',I('chevrL')+' 上一题');prev.type='button';prev.disabled=idx<=0;prev.style.marginRight='auto';
  const next=el('button','btn btn-sm','下一题 '+I('chevR'));next.type='button';next.disabled=idx>=list.length-1;
  const cycle=el('button','btn',I('rotate')+' 标记为「'+mkStatusOf((mk.status+1)%3).name+'」');cycle.type='button';
  const toTask=el('button','btn btn-sm',I('calendar')+' 加入今日任务');toTask.type='button';
  let aiBtn;
  if(aiConfigured()){aiBtn=el('button','btn',I('sparkles')+' AI 解析');aiBtn.type='button';}
  const edit=el('button','btn btn-primary',I('edit')+' 编辑');edit.type='button';
  foot.append(prev,next,toTask,cycle);
  if(aiBtn)foot.append(aiBtn);
  foot.append(edit);
  const md=openModal({title:'错题详情',body:wrap,footer:foot,wide:true});
  /* 图片缩略（异步取 blob） */
  const imgBox=wrap.querySelector('#mdImgs');
  if(imgBox)imgs.forEach(a=>{
    const cell=el('div','mk-img');cell.innerHTML='<div class="small dim" style="display:flex;align-items:center;justify-content:center;height:100%">加载中…</div>';
    imgBox.appendChild(cell);
    dbGet('blobs',a.id).then(rec=>{if(!rec||!rec.blob)return;const u=URL.createObjectURL(rec.blob);
      cell.innerHTML='<img src="'+u+'" title="'+esc(a.name)+'">';cell.querySelector('img').onclick=()=>openAttachment(a);setTimeout(()=>URL.revokeObjectURL(u),120000);});
  });
  const fBox=wrap.querySelector('#mdFiles');
  if(fBox)fBox.innerHTML=others.map(a=>'<div class="att-list-row" data-id="'+a.id+'"><div class="att-thumb">'+(a.type==='application/pdf'?I('pdf'):I('file'))+'</div><div class="att-main"><div class="att-name">'+esc(a.name)+'</div><div class="att-size">'+fmtSize(a.size)+'</div></div><button class="icon-btn" title="打开">'+I('eye')+'</button></div>').join('');
  if(fBox)fBox.querySelectorAll('.att-list-row').forEach(r=>r.onclick=()=>openAttachment(S.attachments.find(a=>a.id===r.dataset.id)));
  toTask.onclick=async()=>{
    const dk=todayKey();
    const exist=S.tasks.find(x=>x.kind==='day'&&x.date===dk&&x.link&&x.link.type==='mistake'&&x.link.id===mk.id);
    if(exist){toast('今天已有这条错题的复习任务');return;}
    const task={id:uid(),kind:'day',date:dk,time:'',title:'复习错题：'+mk.subject+(mk.chapter?' · '+mk.chapter:''),note:'',cat:'学习',
      link:{type:'mistake',id:mk.id},repeat:'none',done:false,doneAt:0,order:Date.now(),createdAt:Date.now(),updatedAt:Date.now()};
    await dbPut('tasks',task);S.tasks.push(task);toast('已加入今日任务','ok');
  };
  prev.onclick=()=>{md.close();mistakeDetail(idx-1,list);};
  next.onclick=()=>{md.close();mistakeDetail(idx+1,list);};
  cycle.onclick=async()=>{mk.status=(mk.status+1)%3;mk.updatedAt=Date.now();await dbPut('mistakes',mk);md.close();render();mistakeDetail(idx,mkFiltered());toast('已标记为「'+mkStatusOf(mk.status).name+'」','ok');};
  edit.onclick=()=>{md.close();mistakeForm({mk});};
  if(aiBtn)aiBtn.onclick=async()=>{
    aiBtn.disabled=true;const oldHtml=aiBtn.innerHTML;aiBtn.innerHTML='解析中…';
    const res=await aiAnalyzeMistake(mk);
    aiBtn.disabled=false;aiBtn.innerHTML=oldHtml;
    if(!res.ok){toast(res.error,'err');return;}
    showAiResult('AI 错题解析 · '+esc(mk.subject||''), res.analysis||'', (text)=>{
      mk.analysis = mk.analysis ? (mk.analysis+'\n\n---\n\n'+text) : text;
      mk.updatedAt=Date.now();
      dbPut('mistakes',mk);
      const i=S.mistakes.findIndex(x=>x.id===mk.id);
      if(i>=0)S.mistakes[i]=mk;
      md.close();render();mistakeDetail(idx,mkFiltered());
      toast('AI 解析已追加到错题','ok');
    });
  };
}

/* ================================================================
 * 任务与目标模块
 * ================================================================ */

export { mistakeDetail, viewMistakes, viewNotes };
