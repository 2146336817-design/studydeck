import { I } from './icons.js';
import { S, attsOfNote, courseOf, courseProgress, dbDel, dbPut, dbPutMany, epsOf, loadAll, notesOfEp, saveSettings } from './db.js';
import { confirmDialog, openModal, toast } from './ui.js';
import { $, $$, SRC_LABEL, STATUS_LABEL, biliEmbed, biliMeta, courseInitial, courseSec, el, epLastAt, epNumberOf, epSec, esc, fmtDur, fmtDurShort, fmtTime, hostOf, humanAgo, md2html, openAttachment, parseBili, parseCollection, safeColor, uid } from './util.js';
import { render } from './viewkit.js';
import { HAS_FS, pickVideoFiles, safePutEp } from './video-files.js';
import { bindPlayer, batchEpisodeForm, courseForm, enableEpDrag, episodeForm, noteForm } from './forms.js';

/* ── 播放器私有的内部形状（不放进 types.js：它们是 MSE/DASH 的实现细节）──
   这些形状此前完全没有定义，只能从代码里反推，这也是本文件类型错误最多的原因。 */

/**
 * B 站 DASH 的一个分片引用（sidx 解析出来的 refs 元素）。
 * @typedef {Object} BiliSegment
 * @property {number} start
 * @property {number} end
 * @property {number} [dur]
 * @property {number} [size]
 */

/**
 * 解析出来的 sidx（segment index）结果。
 * @typedef {Object} BiliSidx
 * @property {number} initEnd    init 段结束位置（0 表示没有独立 init 段）
 * @property {number} idxEnd     索引段结束位置
 * @property {BiliSegment[]} refs
 * @property {number} [mediaStart]
 */

/** MSE 里 SourceBuffer 正在处理的任务。
 *  @typedef {{op:'append'|'remove', buf?:ArrayBuffer, a?:number, b?:number, name?:string}} MseTask */

/** 一个 DASH 轨道（视频或音频）。
 *  @typedef {Object} BiliTrack
 *  @property {number} id
 *  @property {number} [bandwidth]
 *  @property {string} [mimeType]
 *  @property {string} [codecs]
 *  @property {string} [baseUrl]
 *  @property {string} [segBase]
 *  @property {BiliSidx} [sidx]
 */

/** @param {import('./types.js').Course} c @returns {Promise<void>} */
async function deleteCourse(c){
  const n=epsOf(c.id).length;
  const ok=await confirmDialog('删除课程','确定删除「'+c.name+'」吗？'+(n?'其下 '+n+' 个分集将一并删除。':'')+'相关笔记与学习记录也会移除，此操作不可撤销。','删除');
  if(!ok)return;
  const epIds=new Set(epsOf(c.id).map(e=>e.id));
  const noteIds=new Set(S.notes.filter(n=>n.courseId===c.id).map(n=>n.id));
  const attIds=new Set(S.attachments.filter(a=>noteIds.has(a.noteId)).map(a=>a.id));
  await Promise.all([
    ...[...epIds].map(id=>dbDel('episodes',id)),
    ...noteIds.size?[...noteIds].map(id=>dbDel('notes',id)):[],
    ...attIds.size?[...attIds].flatMap(id=>[dbDel('attachments',id),dbDel('blobs',id)]):[],
    ...S.sessions.filter(s=>s.courseId===c.id).map(s=>dbDel('sessions',s.id)),
    dbDel('courses',c.id)
  ]);
  await loadAll(); render(); toast('已删除','ok');
}

/* 一键删除全部分集（保留课程本身；关联笔记/附件/学习记录一并移除） */

/** @param {import('./types.js').Course} c @returns {Promise<void>} */
async function deleteAllEps(c){
  const n=epsOf(c.id).length;
  if(!n){toast('该课程还没有分集','err');return;}
  const ok=await confirmDialog('清空全部分集','确定删除课程「'+c.name+'」下全部 '+n+' 个分集吗？相关笔记、附件与学习记录也会一并移除，课程本身保留。此操作不可撤销。','清空');
  if(!ok)return;
  const epIds=new Set(epsOf(c.id).map(e=>e.id));
  const noteIds=new Set(S.notes.filter(n=>n.courseId===c.id).map(n=>n.id));
  const attIds=new Set(S.attachments.filter(a=>noteIds.has(a.noteId)).map(a=>a.id));
  await Promise.all([
    ...[...epIds].map(id=>dbDel('episodes',id)),
    ...noteIds.size?[...noteIds].map(id=>dbDel('notes',id)):[],
    ...attIds.size?[...attIds].flatMap(id=>[dbDel('attachments',id),dbDel('blobs',id)]):[],
    ...S.sessions.filter(s=>epIds.has(String(s.epId||''))).map(s=>dbDel('sessions',s.id))
  ]);
  await loadAll(); render(); toast('已清空全部分集','ok');
}

/* 课程手动排序（基于指针事件拖拽，兼容所有浏览器） */

/** @param {import('./types.js').Episode} ep @param {number} st @returns {Promise<void>} */
async function setEpStatus(ep,st){
  ep.status=st; ep.completedAt=st===2?Date.now():(st===0?null:ep.completedAt||null);
  await dbPut('episodes',ep); render();
}

/** @param {import('./types.js').Episode} ep @returns {Promise<void>} */
async function cycleEpStatus(ep){await setEpStatus(ep,((ep.status||0)+1)%3);}

/** @param {import('./types.js').Episode} ep @param {number} dir @returns {Promise<void>} */
async function moveEp(ep,dir){
  const list=epsOf(ep.courseId); const i=list.findIndex(e=>e.id===ep.id); const j=i+dir;
  if(j<0||j>=list.length)return;
  const a=list[i],b=list[j]; const o=a.order;a.order=b.order;b.order=o;
  await dbPut('episodes',a);await dbPut('episodes',b);render();
}

/** @param {import('./types.js').Episode} ep @returns {Promise<void>} */
async function deleteEp(ep){
  const ok=await confirmDialog('删除分集','确定删除「'+ep.title+'」吗？其学习记录将一并删除，相关笔记会保留并变为课程笔记。','删除');
  if(!ok)return;
  await dbDel('episodes',ep.id);
  S.sessions.filter(s=>s.epId===ep.id).forEach(s=>dbDel('sessions',s.id));
  /* n.epIds 在类型上可选（旧备份可能缺失），这里按空数组兜底。 */
  for(const n of S.notes.filter(n=>Array.isArray(n.epIds)&&n.epIds.includes(ep.id))){n.epIds=(n.epIds||[]).filter(x=>x!==ep.id);await dbPut('notes',n);}
  await loadAll();render();toast('已删除','ok');
}

/* 检测本地文件选择能力 */



/* 批量添加分集 */

/** @param {HTMLElement} main */
function viewCourseDetail(main){
  const c=courseOf(String(S.route.id||''));
  if(!c){main.innerHTML='<div class="empty"><div class="empty-title">课程不存在</div><a class="btn" href="#/courses">返回课程列表</a></div>';return;}
  const p=courseProgress(c.id), sec=courseSec(c.id);
  main.innerHTML=
    '<div class="crumb"><a href="#/courses">课程</a>'+I('chevR')+'<span>'+esc(c.name)+'</span></div>'+
    '<div class="detail-head"><div class="detail-logo" style="background:'+safeColor(c.color)+'">'+esc(courseInitial(c.name))+'</div>'+
      '<div class="detail-meta"><div class="detail-name">'+esc(c.name)+'</div>'+
      '<div class="detail-sub"><span>'+esc(c.subject||'未分类')+'</span><span>'+p.done+'/'+p.total+' 集已完成</span><span>累计 '+fmtDur(sec)+'</span>'+(c.desc?'<span>'+esc(c.desc)+'</span>':'')+'</div> '+
      '<div class="progress thin" style="margin-top:7px;max-width:420px"><i style="width:'+p.pct+'%;background:'+safeColor(c.color)+'"></i></div></div>'+
      '<div style="display:flex;gap:6px;flex-shrink:0"><button class="icon-btn" id="cEdit" title="编辑课程">'+I('edit')+'</button><button class="icon-btn danger" id="cDel" title="删除课程">'+I('trash')+'</button></div></div>'+
    '<div class="ep-toolbar">'+
      ['all','todo','doing','done'].map(f=>'<button class="filter-chip '+(S.ui.epFilter===f?'on':'')+'" data-f="'+f+'">'+({all:'全部',todo:'未开始',doing:'进行中',done:'已完成'})[f]+'</button>').join('')+
      '<span style="flex:1"></span>'+
      '<button class="btn btn-danger" id="epClear">清空分集</button>'+
      '<button class="btn" id="epBatch">'+I('layers')+' 批量添加</button>'+
      '<button class="btn btn-primary" id="epAdd">'+I('plus')+' 添加分集</button></div>'+
    '<div class="ep-list" id="epList"></div>';
  /* 用 core.js 的 $ / $$ 而不是 element.querySelector：
     前者返回 any（和 querySelector 语义相同），后者返回 Element ——
     Element 上没有 onclick / dataset，会报 30 处 TS2339。
     $$ 与 querySelectorAll 等价，只是把根节点作为第二个参数传入。 */
  $('#cEdit', main).onclick=()=>courseForm(c);
  $('#cDel', main).onclick=()=>deleteCourse(c);
  $('#epAdd', main).onclick=()=>episodeForm(c,null);
  $('#epClear', main).onclick=()=>deleteAllEps(c);
  $('#epBatch', main).onclick=()=>batchEpisodeForm(c);
  $$('.filter-chip[data-f]', main).forEach((/** @type {any} */ b)=>b.onclick=()=>{S.ui.epFilter=b.dataset.f;render();});
  drawEps($('#epList', main),c);
  if(S.route.play){const ep=S.episodes.find(e=>e.id===S.route.play);if(ep)setTimeout(()=>Player.open(ep.id),50);}
}

/** @param {HTMLElement} box @param {import('./types.js').Course} c */
function drawEps(box,c){
  let eps=epsOf(c.id);
  const f=S.ui.epFilter;
  if(f!=='all')eps=eps.filter(e=>f==='todo'?e.status===0:f==='doing'?e.status===1:e.status===2);
  if(!eps.length){
    box.innerHTML='<div class="empty">'+I('list')+'<div class="empty-title">'+(epsOf(c.id).length?'该筛选下没有分集':'还没有分集')+'</div><div>'+(epsOf(c.id).length?'':'添加 B 站链接、本地视频或占位分集，开始排课')+'</div>'+
      '<button class="btn btn-primary" id="emptyBatch">'+I('layers')+' 批量添加</button></div>';
    const b=$('#emptyBatch', box);if(b)b.onclick=()=>batchEpisodeForm(c);
    return;
  }
  box.innerHTML=eps.map((e,i,arr)=>{
    const sec=epSec(e.id), last=epLastAt(e.id);
    const srcIcon=e.src==='bili'?'video':e.src==='local'?'folder':'globe';
    return '<div class="card ep-row '+(e.status===2?'is-done':'')+'" data-id="'+e.id+'">'+
      '<span class="ep-move">'+
      '<button class="icon-btn ep-up" title="上移" style="width:22px;height:18px">'+('<svg viewBox="0 0 24 24" style="width:12px" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 14l6-6 6 6"/></svg>')+'</button>'+
      '<button class="icon-btn ep-down" title="下移" style="width:22px;height:18px">'+('<svg viewBox="0 0 24 24" style="width:12px" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 10l6 6 6-6"/></svg>')+'</button></span>'+
      '<span class="ep-idx">'+(i+1)+'</span>'+
      '<span class="status-dot s'+(e.status||0)+'" title="'+STATUS_LABEL[e.status||0]+'"></span>'+
      '<div class="ep-main"><div class="ep-title">'+esc(e.title)+' '+
        '<span class="badge badge-src">'+I(srcIcon)+(/** @type {Record<string,string>} */ (SRC_LABEL))[String(e.src||'')]+(e.src==='bili'&&parseBili(e.url)&&(/** @type {any} */ (parseBili(e.url))).page>1?' P'+/** @type {any} */ (parseBili(e.url)).page:'')+'</span>'+
        (e.status===2?'<span class="done-tick">'+I('check')+'</span>':'')+'</div>'+
      '<div class="ep-meta">'+(e.fileName?'<span>'+esc(e.fileName)+'</span>':e.url?'<span class="ellipsis" style="max-width:280px">'+esc(hostOf(e.url))+'</span>':'<span class="dim">未挂视频</span>')+
        (e.estMin?'<span>计划 '+e.estMin+' 分</span>':'')+(sec?'<span>已学 '+fmtDurShort(sec)+'</span>':'')+(last?'<span>'+humanAgo(last)+'</span>':'')+'</div></div>'+
      '<div class="ep-actions">'+
        '<button class="icon-btn ep-note" title="记笔记">'+I('note')+'</button>'+
        '<button class="icon-btn ep-status" title="点击切换状态">'+I('flag')+'</button>'+
        '<button class="icon-btn ep-edit" title="编辑">'+I('edit')+'</button>'+
        '<button class="icon-btn danger ep-del" title="删除">'+I('trash')+'</button>'+
        '<button class="btn btn-sm btn-primary ep-play" style="margin-left:4px">'+I('play')+' 播放</button>'+
      '</div></div>';
  }).join('');
  /* 用 $ / $$（返回 any）：querySelectorAll 返回 Element[]，而这里要读 .dataset.id、
     要挂 .onclick，Element 上都没有。同时把"找不到分集"的记录先滤掉，
     否则 ep 可能是 undefined（原代码直接 ep.id 会抛）。 */
  /** @type {{row:any,ep:import('./types.js').Episode}[]} */
  const rows=(/** @type {any} */ ($$('.ep-row', box)
    .map((/** @type {any} */ row)=>({row, ep:S.episodes.find(x=>x.id===row.dataset.id)}))
    .filter((/** @type {any} */ it)=>!!it.ep)));
  /** 包一层"先阻止冒泡再执行"：ep-row 上各处按钮都要防止触发行本身的点击。
   *  @param {()=>void} fn @returns {(ev:any)=>void} */
  const stopThen=(fn)=>(ev)=>{ev.stopPropagation();fn();};
  for(const {row,ep} of rows){
    $('.ep-main', row).onclick=()=>Player.open(ep.id);
    $('.ep-play', row).onclick=()=>Player.open(ep.id);
    $('.ep-up', row).onclick=stopThen(()=>moveEp(ep,-1));
    $('.ep-down', row).onclick=stopThen(()=>moveEp(ep,1));
    $('.ep-note', row).onclick=stopThen(()=>noteForm({courseId:c.id,epIds:[ep.id]}));
    $('.ep-status', row).onclick=stopThen(()=>cycleEpStatus(ep));
    $('.ep-edit', row).onclick=stopThen(()=>episodeForm(c,ep));
    $('.ep-del', row).onclick=stopThen(()=>deleteEp(ep));
  }
  if(S.ui.epFilter==='all')enableEpDrag(box);
}

/* ================================================================
 * 播放器 + 学习计时器
 * ================================================================ */

/** @type {import('./types.js').PlayerState & Record<string, any>} */
const Player={
  epId:null, md:null, timer:null, objectUrl:null, curSess:null, tickTimer:null,
  /* 运行中才赋值的状态：显式声明，否则 tsc 按字面量推断认不出这些键（TS2339）。 */
  _dashCtrl:null, _fetchCtrl:null, _dashUrl:null,
  _nextTimer:null, _pendFin:null, _chkTimer:null,
  _docKey:null, _fsHandler:null,
  /** @param {import('./types.js').Session} s */
  upsert(s){const i=S.sessions.findIndex(x=>x.id===s.id);if(i>=0)S.sessions[i]=s;else S.sessions.push(s);
    S.sessions.sort((a,b)=>b.start-a.start);},
  teardownPlayback(){
    if(this._dashCtrl){try{this._dashCtrl.abort();}catch(e){}this._dashCtrl=null;}
    if(this._fetchCtrl){try{this._fetchCtrl.abort();}catch(e){}this._fetchCtrl=null;}
    /* 注意：this.teardownPlayback / mountStage / bindPanel 整条路径**测试套件覆盖不到**
       （纯 DOM + 媒体元素，happy-dom 里没有真实播放）。这里刻意保持一行内联写法，
       不做"提取公共函数"之类的等价改写 —— 改了也没人验得出来。
       写类型注解时尤其要小心保持行为不变。 */
    if(this.md){this.md.body.querySelectorAll('video').forEach((/** @type {any} */ v)=>{try{v.pause();v.removeAttribute('src');if(v.load)v.load();}catch(e){}});}
    document.querySelectorAll('.pip-active video').forEach((/** @type {any} */ v)=>{try{v.pause();v.removeAttribute('src');if(v.load)v.load();}catch(e){}});
  },
  /** @param {string} epId */
  open(epId){
    if(this._docKey){document.removeEventListener('keydown',this._docKey);this._docKey=null;}
    if(this._nextTimer){clearTimeout(this._nextTimer);this._nextTimer=null;}
    if(this._pendFin){clearTimeout(this._pendFin);this._pendFin=null;}
    this.teardownPlayback();
    this.finalize();
    document.querySelectorAll('body > #plStage').forEach(n=>n.remove());
    if(this.md){const old=this.md;this.md=null;old.close();}
    const ep=S.episodes.find(x=>x.id===epId); if(!ep)return;
    this.epId=epId;
    const c=courseOf(ep.courseId); const list=epsOf(ep.courseId);
    const idx=list.findIndex(x=>x.id===epId), prev=list[idx-1], next=list[idx+1];
    const body=el('div'); body.style.padding='0';
    body.innerHTML=
      '<div class="player-stage" id="plStage"></div>'+
      '<div class="player-panel">'+
        '<button class="icon-btn" id="plPrev" '+(prev?'':'disabled')+' title="上一集">'+I('chevrL')+'</button>'+
        '<div style="flex:1;min-width:120px"><div class="ellipsis" style="font-weight:650;font-size:13.5px">'+esc(ep.title)+'</div>'+
        '<div class="tiny dim ellipsis">'+(c?esc(c.name):'')+' · 第 '+epNumberOf(ep)+' 集 · 本集已学 <b id="plLearned">'+fmtDur(epSec(epId))+'</b></div></div>'+
        '<div class="timer-box" id="plTimer">00:00</div>'+
        '<div class="timer-controls">'+
          '<button class="timer-btn go" id="plStart" title="开始/暂停 (空格)">'+I('play')+'</button>'+
          '<button class="timer-btn" id="plAdd" title="补记 1 分钟">+1′</button>'+
        '</div>'+
        (ep.src==='bili'?'<button class="btn btn-sm" id="plBiliOpen" title="在 B 站站内打开，可切换高清清晰度">'+I('external')+' B站高清</button>':'')+
        '<button class="btn btn-sm" id="plDone">'+I('check')+' 标记完成</button>'+
        '<button class="icon-btn" id="plPiP" title="浮动小窗（可拖动/缩放）">\u25a3</button>'+
        '<button class="icon-btn" id="plNext2" '+(next?'':'disabled')+' title="下一集">'+I('chevR')+'</button>'+
        '<button class="icon-btn" id="plClose" title="关闭播放器" style="color:#e74c3c">'+I('x')+'</button>'+
      '</div>'+
      '<div class="player-note-strip" id="plNotes"></div>';
    this.md=openModal({title:'播放器',body,footer:null,wide:true,cls:'player-modal',dismissable:false,onClose:()=>{this.close();return false;}});
    // 隐藏默认标题栏，播放器自带控制
    const modal=this.md.modal; modal.querySelector('.modal-head').style.display='none';
    modal.style.width='900px';
    modal.style.position='relative';
    this.timer={running:false,startedAt:0,base:0};
    this.mountStage(ep);
    this.bindPanel(ep,prev,next);
    this.renderNotes(ep);
    this.tickTimer=setInterval(()=>this.tick(),300);
    modal._playerKey=(/** @type {any} */ e)=>{if(e.target.tagName==='INPUT'||e.target.tagName==='TEXTAREA')return;
      if(e.code==='ArrowLeft'&&prev){this.open(prev.id);}
      if(e.code==='ArrowRight'&&next){this.open(next.id);}};
    modal.addEventListener('keydown',modal._playerKey);
    this._docKey=(/** @type {any} */ e)=>{if(e.target.tagName==='INPUT'||e.target.tagName==='TEXTAREA')return;
      if(e.code==='Space'){e.preventDefault();this.toggle();}};
    document.addEventListener('keydown',this._docKey);
  },
  /** @param {import('./types.js').Episode} ep @param {import('./types.js').Episode|undefined} prev @param {import('./types.js').Episode|undefined} next */
  bindPanel(ep,prev,next){
    this.md.body.querySelector('#plPrev').onclick=()=>prev&&this.open(prev.id);
    this.md.body.querySelector('#plNext2').onclick=()=>next&&this.open(next.id);
    this.md.body.querySelector('#plStart').onclick=()=>this.toggle();
    this.md.body.querySelector('#plAdd').onclick=()=>this.addManual(60);
    const bo=this.md.body.querySelector('#plBiliOpen'); if(bo)bo.onclick=()=>this.openBiliExternal(ep);
    const pipBtn=this.md.body.querySelector('#plPiP'); if(pipBtn)pipBtn.onclick=()=>this.togglePiP();
    const cl=this.md.body.querySelector('#plClose'); if(cl)cl.onclick=()=>this.close();
    const doneBtn=this.md.body.querySelector('#plDone');
    const paintDone=()=>{doneBtn.innerHTML=(ep.status===2?(I('rotate')+' 取消完成'):(I('check')+' 标记完成'));
      doneBtn.classList.toggle('btn-primary',ep.status!==2);};
    paintDone();
    doneBtn.onclick=async()=>{await setEpStatus(ep,ep.status===2?0:2);paintDone();
      if(ep.status===2){this.finalize();toast('已完成本集，辛苦了','ok');}};
  },
  togglePiP(){
    const stage=(this.md&&this.md.body.querySelector('#plStage'))||document.querySelector('#plStage');
    if(!stage)return;
    if(stage.classList.contains('pip-active')){
      stage.classList.remove('pip-active'); stage.style.cssText='';
      const bar=stage.querySelector('.pip-bar'), rz=stage.querySelector('.pip-resize');
      if(bar)bar.remove(); if(rz)rz.remove();
      const body=this.md&&this.md.body;
      const panel=body&&body.querySelector('.player-panel');
      if(panel)panel.parentNode.insertBefore(stage,panel);
      else if(body)body.appendChild(stage);
      toast('已恢复播放窗口','ok');
      return;
    }
    document.body.appendChild(stage);
    stage.classList.add('pip-active');
    const w=Math.min(420,Math.max(280,window.innerWidth-40)), h=Math.round(w*9/16);
    stage.style.width=w+'px'; stage.style.height=h+'px';
    stage.style.left=(window.innerWidth-w-24)+'px'; stage.style.top='76px';
    const bar=Object.assign(el('div'),{className:'pip-bar'});
    bar.innerHTML='<span>拖动移动 · 右下角缩放</span><span class="pip-close" title="关闭小窗">'+I('x')+'</span>';
    stage.prepend(bar);
    const rz=Object.assign(el('div'),{className:'pip-resize'});
    stage.append(rz);
    let sx=/** @type {number|null} */ (null),sy=0,ox=0,oy=0,ow=0,oh=0;
    bar.addEventListener('pointerdown',(/** @type {any} */ e)=>{if(e.button!==0)return;if(e.target.closest&&e.target.closest('.pip-close'))return;sx=e.clientX;sy=e.clientY;ox=stage.offsetLeft;oy=stage.offsetTop;e.preventDefault();bar.setPointerCapture(e.pointerId);});
    bar.addEventListener('pointermove',(/** @type {any} */ e)=>{if(sx===null)return;stage.style.left=Math.max(8,ox+e.clientX-sx)+'px';stage.style.top=Math.max(8,oy+e.clientY-sy)+'px';});
    const endD=(/** @type {any} */ e)=>{sx=null;try{bar.releasePointerCapture(e.pointerId);}catch(err){}};
    bar.addEventListener('pointerup',endD); bar.addEventListener('pointercancel',endD);
    const close=bar.querySelector('.pip-close'); if(close)close.onclick=(/** @type {any} */ e)=>{e.stopPropagation();this.togglePiP();};
    rz.addEventListener('pointerdown',(/** @type {any} */ e)=>{if(e.button!==0)return;e.preventDefault();e.stopPropagation();sx=e.clientX;sy=e.clientY;ow=stage.offsetWidth;oh=stage.offsetHeight;rz.setPointerCapture(e.pointerId);});
    rz.addEventListener('pointermove',(/** @type {any} */ e)=>{if(sx===null)return;stage.style.width=Math.max(280,ow+e.clientX-sx)+'px';stage.style.height=Math.max(158,oh+e.clientY-sy)+'px';});
    const endR=(/** @type {any} */ e)=>{sx=null;try{rz.releasePointerCapture(e.pointerId);}catch(err){}};
    rz.addEventListener('pointerup',endR); rz.addEventListener('pointercancel',endR);
    toast('已开启浮动小窗：拖顶部移动、拖右下角缩放','ok');
  },
  /** @param {import('./types.js').Episode} ep */
  mountStage(ep){
    const stage=this.md.body.querySelector('#plStage');
    if(ep.src==='bili'&&parseBili(ep.url)){
      const bm=S.settings.biliMode||'embed';
      if(bm==='external') this.mountBiliExternal(stage,ep);
      else if(bm==='direct'||(bm==='auto'&&S.proxy)) this.mountBiliDirect(stage,ep);
      else this.mountBiliEmbed(stage,ep);
    }else if(ep.src==='local'){
      stage.innerHTML='<div class="player-fallback" id="plLocal"></div>';
      this.mountLocal(ep);
    }else if(ep.src==='local-media'){
      stage.innerHTML='<div class="player-fallback" id="plLocalMedia"></div>';
      this.mountLocalMedia(stage,ep);
    }else{
      stage.innerHTML='<div class="player-fallback">'+I('globe','')+
        '<div style="font-size:14px">外部网页视频</div>'+
        '<div class="tiny" style="color:rgba(255,255,255,.55);max-width:480px">该平台不支持内嵌播放，请在新标签页打开学习，用下方计时器记录学习时长</div>'+
        (ep.url?'<a class="btn btn-primary" target="_blank" rel="noopener" href="'+esc(ep.url)+'">'+I('external')+' 打开课程页面</a>':'<div class="tiny" style="color:rgba(255,255,255,.55)">该分集尚未挂链接，可在分集编辑中补充</div>')+'</div>';
      const a=stage.querySelector('a'); if(a)a.onclick=()=>this.start();
    }
  },
  /** @param {import('./types.js').Episode} ep */
  openBiliExternal(ep){ if(ep&&ep.url)window.open(ep.url,'_blank','noopener'); },
  /** @param {HTMLElement} stage @param {import('./types.js').Episode} ep */
  mountBiliEmbed(stage,ep){
    stage.innerHTML='<div class="player-loading">正在加载 B 站播放器…</div><iframe title="bili" src="'+biliEmbed(ep)+'" allow="autoplay; fullscreen" referrerpolicy="no-referrer" onload="var l=this.parentNode.querySelector(\'.player-loading\');if(l)l.style.display=\'none\'"></iframe>';
    this.start(); // 内嵌无法监听播放事件，打开即计时，可手动暂停
  },
  /** @param {HTMLElement} stage @param {import('./types.js').Episode} ep */
  mountBiliExternal(stage,ep){
    this.openBiliExternal(ep);
    stage.innerHTML='<div class="player-fallback">'+I('globe','')+
      '<div style="font-size:15px;font-weight:650;color:#fff">已在新标签页打开 B 站</div>'+
      '<div class="tiny" style="color:rgba(255,255,255,.62);max-width:500px;line-height:1.75">高清 1080P / 高码率需要 B 站登录态，仅在 B 站站内页面可用。计时器已同步开始，看完回到这里暂停即可，笔记也能照常记录。</div>'+
      '<div style="display:flex;gap:9px;flex-wrap:wrap;justify-content:center"><button class="btn btn-primary" id="plReopen">'+I('external')+' 再次打开 B 站</button><button class="btn" id="plEmbedInstead" style="color:#fff;border-color:rgba(255,255,255,.4);background:transparent">改用应用内嵌播放</button></div></div>';
    $('#plReopen', stage).onclick=()=>this.openBiliExternal(ep);
    $('#plEmbedInstead', stage).onclick=()=>this.mountBiliEmbed(stage,ep);
    this.start();
  },
  QN_LABEL:{16:'360P',32:'480P',64:'720P',80:'1080P',112:'1080P+',120:'4K',125:'HDR',126:'杜比'},
  /** @param {string} u @returns {string} */
  cdnUrl(u){return S.proxy?('/api/bili/cdn?u='+encodeURIComponent(u)):u;},
  /** @param {import('./types.js').Episode} ep @param {number} qn @param {string} [fmt] @param {boolean} [refresh] @returns {Promise<any>} */
  async fetchBiliUrl(ep,qn,fmt,refresh){
    fmt=fmt||'durl';
    const b=parseBili(ep.url); if(!b)throw new Error('B 站链接解析失败');
    const id=b.ep?('ep='+b.ep):(b.bvid?('bvid='+b.bvid):('aid='+b.avid));
    if(this._fetchCtrl)try{this._fetchCtrl.abort();}catch(e){}
    const ctrl=new AbortController();this._fetchCtrl=ctrl;
    const killer=setTimeout(()=>ctrl.abort(),25000);
    let r;
    try{
      r=await fetch('/api/bili/playurl?'+id+'&p='+(b.page||1)+'&qn='+qn+'&fmt='+fmt+(refresh?'&refresh=1':''),{signal:ctrl.signal,headers:{'X-Sessdata':S.settings.sessdata||''}});
    }catch(e){throw new Error((/** @type {any} */ (e)).name==='AbortError'?'取链超时（超过 25 秒），请检查网络后点重试':'本地服务连接失败，请确认高清服务窗口仍在运行');}
    clearTimeout(killer);this._fetchCtrl=null;
    if(!r.ok)throw new Error('本地服务无响应（HTTP '+r.status+'）');
    const j=await r.json();
    if(j.code!==0)throw new Error(j.message||('接口返回码 '+j.code));
    if(!j.data||(fmt==='durl'&&(!j.data.durl||!j.data.durl.length)))throw new Error('没有拿到可播放地址');
    if(j._proxy)j.data._proxy=j._proxy;
    return j.data;
  },
  /** @param {HTMLElement} stage @param {import('./types.js').Episode} ep @param {number} [qn] */
  mountBiliDirect(stage,ep,qn){
    const wantQn=qn||S.settings.biliQn||80;
    stage.innerHTML='<div class="player-fallback"><div class="spin"></div>'+
      '<div style="font-size:14px;color:#fff;margin-top:14px">正在获取 B 站高清直链…</div>'+
      '<div class="tiny" style="color:rgba(255,255,255,.55);margin-top:6px">视频流直连 B 站官方 CDN，正常 1~2 秒完成</div>'+
      '<div style="display:flex;gap:9px;margin-top:14px"><button class="btn" id="plLoadEmbed" style="color:#fff;border-color:rgba(255,255,255,.4);background:transparent">改用内嵌</button><button class="btn" id="plLoadExt" style="color:#fff;border-color:rgba(255,255,255,.4);background:transparent">新标签打开</button></div></div>';
    $('#plLoadEmbed', stage).onclick=()=>this.mountBiliEmbed(stage,ep);
    $('#plLoadExt', stage).onclick=()=>this.mountBiliExternal(stage,ep);
    const bInfo=parseBili(ep.url);
    // 番剧（ep 格式）的 durl 已被 B 站废弃（返回空），无论是否登录都必须走 dash；
    // 普通视频有登录态才用 dash 拿高画质，游客回退 durl 720P。
    const canDash=!!S.proxy&&(!!(S.settings.sessdata||S.serverSess)||!!(bInfo&&bInfo.ep));
    const useDash=canDash?this.fetchBiliUrl(ep,wantQn,'dash'):Promise.reject(new Error('guest'));
    useDash.then((/** @type {any} */ data)=>{
      if(this.epId!==ep.id)return;
      if(data&&data.dash&&(data.dash.video||[]).length){this.mountBiliMse(stage,ep,data,wantQn);}
      else{return this.fetchBiliUrl(ep,wantQn,'durl').then((/** @type {any} */ d2)=>this.mountBiliDurl(stage,ep,d2,wantQn));}
    }).catch(()=>{
      if(this.epId!==ep.id)return;
      this.fetchBiliUrl(ep,wantQn,'durl').then((/** @type {any} */ d2)=>this.mountBiliDurl(stage,ep,d2,wantQn))
        .catch((/** @type {any} */ err)=>this.directFail(stage,ep,(err&&err.message)||'获取失败'));
    });
  },
  /** @param {number} realQn @param {number[]} accept @param {boolean} logged @returns {string} */
  directBarHtml(realQn,accept,logged){
    return '<div class="direct-bar"><span class="db-label">直连 '+esc(this.QN_LABEL[realQn]||(realQn+'P'))+'</span>'+
      '<select class="db-sel" id="plQn" title="切换清晰度">'+accept.map(q=>'<option value="'+q+'"'+(q===realQn?' selected':'')+'>'+(this.QN_LABEL[q]||q+'P')+'</option>').join('')+'</select>'+
      (logged?'':'<button class="db-btn db-login" id="plLoginTip" title="游客最高 720P，填登录凭证后解锁 1080P">登录解锁1080P</button>')+
      '<span class="tiny" id="plNet" style="color:#ffd99a;align-self:center"></span>'+
      '<button class="db-btn" id="plToEmbed">内嵌</button>'+
      '<button class="db-btn" id="plToExt">'+I('external')+'新标签</button></div>';
  },
  /** @param {HTMLElement} stage @param {import('./types.js').Episode} ep */
  bindDirectBar(stage,ep){
    const sel=$('#plQn', stage);
    if(sel)sel.onchange=()=>{S.settings.biliQn=+sel.value;saveSettings();this.mountBiliDirect(stage,ep,+sel.value);};
    const e1=$('#plToEmbed', stage);if(e1)e1.onclick=()=>this.mountBiliEmbed(stage,ep);
    const e2=$('#plToExt', stage);if(e2)e2.onclick=()=>this.openBiliExternal(ep);
    const lt=$('#plLoginTip', stage);
    if(lt)lt.onclick=()=>{this.close();location.hash='#/settings';setTimeout(()=>toast('在「B 站高清直连服务」填入 SESSDATA 即解锁 1080P','ok'),300);};
  },
  /** @param {HTMLElement} stage @param {import('./types.js').Episode} ep */
  bindFsNav(stage,ep){
    const video=stage.querySelector('video');if(!video||video.closest('.pl-video-wrap'))return;
    /** @type {any} */
    const vwrap=video.parentNode;
    const wrap=el('div');wrap.className='pl-video-wrap';
    vwrap.insertBefore(wrap,video);wrap.appendChild(video);
    const list=epsOf(ep.courseId),idx=list.findIndex(x=>x.id===ep.id);
    const prev=list[idx-1],next=list[idx+1];
    const nav=el('div');nav.className='pl-fs-nav';
    nav.innerHTML='<button class="fs-nav-btn" id="fsPrev"'+(prev?'':' disabled')+'>'+I('chevrL')+'<span>上一集</span></button>'+
      '<button class="fs-nav-btn" id="fsNext"'+(next?'':' disabled')+'><span>下一集</span>'+I('chevR')+'</button>';
    const fsBtn=el('button');fsBtn.className='pl-fs-btn';fsBtn.title='全屏 / 退出全屏 (Esc)';
    fsBtn.innerHTML='<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/></svg>';
    wrap.append(nav,fsBtn);
    nav.querySelector('#fsPrev').onclick=()=>prev&&this.open(prev.id);
    nav.querySelector('#fsNext').onclick=()=>next&&this.open(next.id);
    fsBtn.onclick=()=>{const fe=document.fullscreenElement;if(fe===wrap)document.exitFullscreen();else if(!fe&&wrap.requestFullscreen)wrap.requestFullscreen();};
    /** @type {number|null} */
    let hideT=null;
    const showNav=()=>{if(document.fullscreenElement!==wrap)return;wrap.classList.add('nav-show');if(hideT)clearTimeout(hideT);hideT=setTimeout(()=>wrap.classList.remove('nav-show'),2600);};
    wrap.addEventListener('mousemove',showNav);
    wrap.addEventListener('mouseleave',()=>wrap.classList.remove('nav-show'));
    if(this._fsHandler)document.removeEventListener('fullscreenchange',this._fsHandler);
    const h=()=>{const fe=document.fullscreenElement;
      if(fe===video){document.exitFullscreen().then(()=>wrap.requestFullscreen&&wrap.requestFullscreen()).catch(()=>{});}
      if(fe===wrap)showNav();};
    this._fsHandler=h;document.addEventListener('fullscreenchange',h);
  },
  /** @param {HTMLElement} stage @param {import('./types.js').Episode} ep @param {any} data @param {number} wantQn */
  mountBiliDurl(stage,ep,data,wantQn){
    const urls=data.durl.map((/** @type {any} */ d)=>this.cdnUrl(d.url));
    const accept=(data.accept_quality||[16,32,64,80]).slice().sort((/** @type {number} */ a,/** @type {number} */ b)=>b-a);
    const qnEcho=data.quality||wantQn;
    const realQn=accept.includes(qnEcho)?qnEcho:(accept[0]||qnEcho);
    const logged=!!(data._proxy&&data._proxy.logged);
    let segRetries=0;
    /** @param {number} i */
    const loadSeg=i=>{
      stage.innerHTML='<video controls autoplay playsinline referrerpolicy="no-referrer" src="'+urls[i]+'"></video>'+this.directBarHtml(realQn,accept,logged);
      const v=stage.querySelector('video');
      this.bindVideoTimer(v,ep,()=>{ if(i+1<urls.length){loadSeg(i+1);return;} this.onEpEnded(ep); });
      /** @type {any} */ (v).addEventListener('error',()=>{
        if(segRetries++<2){this.mountBiliDirect(stage,ep,realQn);}
        else this.directFail(stage,ep,'视频流加载失败，直链有时效，点「重试」即可重新获取');
      });
      this.bindDirectBar(stage,ep);
      this.bindFsNav(stage,ep);
    };
    loadSeg(0);
  },
  /** @param {HTMLElement} stage @param {import('./types.js').Episode} ep @param {any} data @param {number} wantQn */
  mountBiliMse(stage,ep,data,wantQn){
    const dash=data.dash;
    const accept=(data.accept_quality||[80,64,32,16]).slice().sort((/** @type {number} */ a,/** @type {number} */ b)=>b-a);
    let realQn=accept.includes(wantQn)?wantQn:(accept[0]||wantQn);
    /** @param {string} mt @param {string} c @returns {boolean} */
    const mimeOk=(mt,c)=>{try{return MediaSource.isTypeSupported(mt+'; codecs="'+c+'"');}catch(e){return false;}};
    let vcand=dash.video.filter((/** @type {any} */ v)=>v.id===realQn);
    if(!vcand.length){vcand=dash.video.slice();realQn=vcand[0]?vcand[0].id:realQn;}
    const vt=vcand.find((/** @type {any} */ v)=>/^avc1/i.test(v.codecs)&&mimeOk(v.mimeType||'video/mp4',v.codecs))||
             vcand.find((/** @type {any} */ v)=>mimeOk(v.mimeType||'video/mp4',v.codecs))||vcand[0];
    const aud=(dash.audio||[]).slice().sort((/** @type {any} */ a,/** @type {any} */ b)=>b.bandwidth-a.bandwidth);
    const at=aud.find((/** @type {any} */ a)=>mimeOk(a.mimeType||'audio/mp4',a.codecs))||aud[0]||null;
    const logged=!!(data._proxy&&data._proxy.logged);
    if(this._dashCtrl)try{this._dashCtrl.abort();}catch(e){}
    stage.innerHTML='<video controls autoplay playsinline></video>'+this.directBarHtml(realQn,accept,logged);
    const video=/** @type {any} */ (stage.querySelector('video'));
    this.bindVideoTimer(video,ep,()=>this.onEpEnded(ep));
    this.bindDirectBar(stage,ep);
    this.bindFsNav(stage,ep);
    const ctrl=new AbortController();this._dashCtrl=ctrl;
    const ms=new MediaSource();
    if(this._dashUrl)URL.revokeObjectURL(this._dashUrl);
    this._dashUrl=URL.createObjectURL(ms);video.src=this._dashUrl;
    /** @param {number} ms0 @returns {Promise<void>} */
    const wait=ms0=>new Promise(r=>setTimeout(r,ms0));
    // SourceBuffer 操作串行队列（append/remove 不能并发）
    const pend=/** @type {any[]} */ ([]);let busy=false;
    const pump=()=>{
      if(busy)return;const task=pend.shift();if(!task)return;busy=true;const sb=task.sb;
      const onUpd=()=>{sb.removeEventListener('updateend',onUpd);sb.removeEventListener('error',onErr);busy=false;task.res();pump();};
      const onErr=()=>{sb.removeEventListener('updateend',onUpd);sb.removeEventListener('error',onErr);busy=false;task.rej(new Error('MSE 缓冲错误'));pump();};
      const go=()=>{if(sb.updating){sb.addEventListener('updateend',go,{once:true});return;}
        sb.addEventListener('updateend',onUpd);sb.addEventListener('error',onErr);
        try{
          if(task.op==='remove')sb.remove(task.a,task.b);
          else sb.appendBuffer(task.buf);
        }catch(e){
          sb.removeEventListener('updateend',onUpd);sb.removeEventListener('error',onErr);
          if(task.op!=='remove'&&e&&(/** @type {any} */ (e)).name==='QuotaExceededError'){
            pend.unshift(task);
            try{pend.unshift({sb,op:'remove',a:0,b:Math.max(0,video.currentTime-60),res(){},rej(){}});}catch(_){}
            busy=false;pump();
          }else{busy=false;task.rej(e);pump();}
        }};
      go();
    };
    const enq=(/** @type {any} */ sb,/** @type {any} */ buf)=>new Promise((res,rej)=>{pend.push({sb,op:'append',buf,res,rej});pump();});
    const enqRm=(/** @type {any} */ sb,/** @type {number} */ a,/** @type {number} */ b)=>new Promise((res,rej)=>{pend.push({sb,op:'remove',a,b,res,rej});pump();});
    const idle=()=>new Promise((/** @type {any} */ res)=>{const t=setInterval(()=>{if(!busy&&!pend.length){clearInterval(t);res();}},120);});
    /** @param {string} msg */
    const setNet=msg=>{const el=stage.querySelector('#plNet');if(el)el.textContent=msg;};
    /** @param {any} tk @returns {string[]} */
    const trackUrls=tk=>[tk.baseUrl||tk.base_url].concat(tk.backupUrl||tk.backup_url||[]).filter(Boolean).map(u=>this.cdnUrl(u));
    let refreshing=false;
    const refreshTracks=async()=>{
      if(refreshing)return;refreshing=true;setNet('直链续期…');
      try{
        const nd=await this.fetchBiliUrl(ep,realQn,'dash',true);
        const nv=(nd.dash.video||[]).find((/** @type {any} */ v)=>v.id===vt.id&&v.codecs===vt.codecs)||(nd.dash.video||[]).find((/** @type {any} */ v)=>v.id===vt.id);
        if(nv){vt.baseUrl=nv.baseUrl||nv.base_url;vt.backupUrl=nv.backupUrl||nv.backup_url;}
        const na=(nd.dash.audio||[]).slice().sort((/** @type {any} */ x,/** @type {any} */ y)=>y.bandwidth-x.bandwidth)[0];
        if(na&&at){at.baseUrl=na.baseUrl||na.base_url;at.backupUrl=na.backupUrl||na.backup_url;}
      }catch(e){}
      refreshing=false;
    };
    // 主+备份 CDN 轮换，单块失败无限重连，不中途判死整场播放
    /** @param {any} track @param {number} a @param {number} b @param {AbortSignal} [sig] @returns {Promise<{buf:Uint8Array,total:number}>} */
    const rangeFetch=async(track,a,b,sig)=>{
      sig=sig||ctrl.signal;
      let attempt=0,last;
      while(!ctrl.signal.aborted){
        if(sig.aborted)throw new Error('relocate');
        const urls=trackUrls(track);
        const url=urls[attempt%urls.length];
        try{
          const r=await fetch(url,{headers:{Range:'bytes='+a+'-'+b},signal:sig});
          if(!r.ok&&r.status!==206)throw new Error('HTTP '+r.status);
          const buf=new Uint8Array(await r.arrayBuffer());
          if(!buf.length)throw new Error('empty chunk');
          const m=(r.headers.get('Content-Range')||'').match(/\/(\d+)$/);
          return{buf,total:m?+m[1]:0};
        }catch(e){
          last=e;
          if(ctrl.signal.aborted)throw e;
          if(sig.aborted)throw new Error('relocate');
          attempt++;
          const fatal=/HTTP (403|404)/.test((/** @type {any} */ (e)).message||'');
          if(!fatal)setNet('网络抖动，重连中…');
          if(attempt%(urls.length*2)===0){try{await refreshTracks();}catch(_){}}
          if(fatal){await wait(120);continue;}
          await wait(Math.min(4000,500*Math.pow(1.4,attempt)));
        }
      }
      throw last;
    };
    /** @param {any} sb @returns {number} */
    const bufEnd=sb=>{try{if(!sb.buffered.length)return 0;return sb.buffered.end(sb.buffered.length-1);}catch(e){return 0;}};
    /** @param {any} tk @returns {{initEnd:number,idxEnd:number}} */
    const segBase=tk=>{
      const s=tk.SegmentBase||tk.segment_base||{};
      let initEnd=-1,idxEnd=-1;
      const ini=s.Initialization||s.initialization,ix=s.indexRange||s.index_range;
      if(ini){const a=(''+ini).split('-');initEnd=+(a[1]);}
      if(ix){const a=(''+ix).split('-');idxEnd=+(a[1]);}
      return{initEnd,idxEnd};
    };
    /** @param {any} sb @param {number} t @returns {boolean} */
    const timeReady=(sb,t)=>{try{for(let i=0;i<sb.buffered.length;i++){if(t>=sb.buffered.start(i)&&t<sb.buffered.end(i)-0.25)return true;}}catch(e){}return false;};
    /** 注意：本函数返回的是**分片数组**，不是 BiliSidx 对象（BiliSidx 描述的是整个索引，
     *  这里只负责把 sidx 解析成 refs）。之前的注解写成 BiliSidx 是错的，导致调用方
     *  `refs.length` / `refs[i]` 全部报错。
     *  @param {Uint8Array} buf
     *  @returns {{off:number,size:number,tStart:number,durSec:number}[]|null} */
    const parseSidx=buf=>{
      try{
        const dv=new DataView(buf.buffer,buf.byteOffset,buf.byteLength);
        let o=8,ver=dv.getUint8(o);o+=4;let timescale;
        if(ver===1){o+=4;timescale=dv.getUint32(o);o+=4;o+=16;}
        else{o+=4;timescale=dv.getUint32(o);o+=4;o+=8;}
        o+=2;const cnt=dv.getUint16(o);o+=2;
        const refs=[];let cum=0,t=0;
        for(let i=0;i<cnt;i++){
          const x=dv.getUint32(o);o+=4;const size=x&0x7fffffff;
          const dur=dv.getUint32(o);o+=4;o+=4;
          const durSec=dur/timescale;
          refs.push({off:cum,size,tStart:t,durSec});          cum+=size;t+=durSec;
        }
        return refs;
      }catch(e){return null;}
    };
    /** @type {Record<string, AbortController>} */
    const subs={};
    /** @param {string} k @returns {AbortSignal} */
    const sigOf=k=>{ if(!subs[k]||subs[k].signal.aborted){ const s=new AbortController();subs[k]=s;
      ctrl.signal.addEventListener('abort',()=>{try{s.abort();}catch(e){}},{once:true}); } return subs[k].signal; };
    // 顺序退化加载（无 sidx 信息时）
    /** @param {any} track @param {any} sb @param {number} chunk @param {number} mediaStart @returns {Promise<boolean>} */
    const legacyLoader=async(track,sb,chunk,mediaStart)=>{
      let pos=mediaStart;
      while(!ctrl.signal.aborted){
        if(bufEnd(sb)-video.currentTime>300){await wait(900);continue;}
        let rr;
        try{rr=await rangeFetch(track,pos,pos+chunk-1,sigOf(sb===sbV?'v':'a'));}
        catch(e){if((/** @type {any} */ (e)).message==='relocate')continue;throw e;}
        await enq(sb,rr.buf);pos+=rr.buf.length;setNet('');
        if(rr.buf.length<chunk)break;
      }
      return true;
    };
    // 按 sidx 分段围绕播放头加载：向后预载 300s，向前回填 20s，seek 即时重定位
    /** @param {any} track @param {any} sb @param {number} chunk @param {string} key @returns {Promise<boolean>} */
    const makeLoader=async(track,sb,chunk,key)=>{
      const{initEnd,idxEnd}=segBase(track);
      if(initEnd>=0){const r0=await rangeFetch(track,0,initEnd,ctrl.signal);await enq(sb,r0.buf);}
      const mediaStart=Math.max(initEnd+1,idxEnd+1,0);
      /** @type {{off:number,size:number,tStart:number,durSec:number}[]|null} refs */
      let refs=null;
      if(idxEnd>initEnd&&initEnd>=0){
        /* parseSidx 直接返回分片数组（见它的注解）。 */
        try{const rs=await rangeFetch(track,initEnd+1,idxEnd,ctrl.signal);refs=parseSidx(rs.buf);}catch(e){refs=null;}
      }
      if(!refs)return legacyLoader(track,sb,chunk,mediaStart);
      while(!ctrl.signal.aborted){
        const ct=video.currentTime||0, lo=Math.max(0,ct-20), hi=ct+300;
        let pick=-1;
        for(let i=0;i<refs.length;i++){const r=refs[i];
          if(r.tStart+r.durSec<=lo||r.tStart>=hi)continue;
          if(!timeReady(sb,r.tStart+Math.min(r.durSec/2,1))){pick=i;break;}
        }
        if(pick<0){
          const tail=refs[refs.length-1];
          if(timeReady(sb,Math.max(0,tail.tStart+tail.durSec-0.5)))return true;
          await wait(350);continue;
        }
        let end=pick,bytes=0;
        while(end<refs.length){
          const r=refs[end];
          if(r.tStart>=hi)break;
          if(timeReady(sb,r.tStart+Math.min(r.durSec/2,1))){if(bytes>0)break;end++;continue;}
          bytes+=r.size;end++;
          if(bytes>=chunk)break;
        }
        const a=mediaStart+refs[pick].off,b=a+bytes-1;
        try{
          const rr=await rangeFetch(track,a,b,sigOf(key));
          await enq(sb,rr.buf);setNet('');
        }catch(e){ if((/** @type {any} */ (e)).message==='relocate')continue; throw e; }
      }
      return false;
    };
    video.addEventListener('error',()=>{
      if(ctrl.signal.aborted)return;
      const ve=video.error;
      this.directFail(stage,ep,(ve?('视频解码错误 code='+ve.code):'视频元素错误')+'，点重试可重新获取直链');
    });
    // sourceopen 在 endOfStream 后若再 remove 会重复触发，只允许初始化一次
    let opened=false;
    const dashDur=data.timelength?data.timelength/1000:(dash.duration?(dash.duration>10000?dash.duration/1000:dash.duration):0);
    /* 视频 SourceBuffer：legacyLoader 里要用它判断"当前是视频轨还是音频轨"（sb===sbV），
       而它原本在下面 sourceopen 回调里才 const 声明 —— 那是 TDZ 引用（能跑只因调用时机晚）。
       提到这里声明，跨作用域可见且不改变行为。 */
    /** @type {any} */
    let sbV=null;
    ms.addEventListener('sourceopen',async()=>{
      if(opened)return;opened=true;
      /** @type {number|null} */
      let iv=null;
      try{
        sbV=ms.addSourceBuffer((vt.mimeType||'video/mp4')+'; codecs="'+vt.codecs+'"');sbV.mode='segments';
        let sbA=null;
        if(at){sbA=ms.addSourceBuffer((at.mimeType||'audio/mp4')+'; codecs="'+at.codecs+'"');sbA.mode='segments';}
        if(dashDur){try{ms.duration=dashDur;}catch(e){}}
        const jobs=/** @type {Promise<any>[]} */ ([makeLoader(vt,sbV,6*1024*1024,'v').catch((/** @type {any} */ e)=>({vErr:e}))]);
        if(sbA)jobs.push(makeLoader(at,sbA,2*1024*1024,'a').catch((/** @type {any} */ e)=>({aErr:e})));
        Promise.all(jobs).then(async(rs)=>{
          const rsx=/** @type {any[]} */ (rs);
          const vErr=rsx[0]&&rsx[0].vErr, aErr=sbA?rsx[1]&&rsx[1].aErr:null;
          if(vErr)throw vErr;
          await idle();
          if(iv){clearInterval(/** @type {any} */ (iv));iv=null;}
          if(aErr){try{ms.removeSourceBuffer(/** @type {any} */ (sbA));}catch(_){} setNet('音频轨不可用，静音播放中');}
          if(!ctrl.signal.aborted&&ms.readyState==='open'){try{ms.endOfStream();}catch(e){}}
        }).catch((/** @type {any} */ e)=>{if(!ctrl.signal.aborted)this.directFail(stage,ep,'高清流传输中断，点重试即可：'+(e.message||e));});
        // seek：立即中止在途请求，加载循环按新位置重定位（往回拖也能快速回填）
        video.addEventListener('seeking',()=>{
          ['v','a'].forEach(k=>{if(subs[k]&&!subs[k].signal.aborted){try{subs[k].abort();}catch(e){}}});
          setNet('定位中…');
        });
        let everStarted=false;
        video.addEventListener('playing',()=>{everStarted=true;setNet('');});
        let lastTrim=0;
        iv=setInterval(()=>{
          if(ctrl.signal.aborted){clearInterval(/** @type {any} */ (iv));return;}
          if(!everStarted&&video.paused&&bufEnd(sbV)>0.3)video.play().catch(()=>{}); // 仅首次自动播放
          if(ms.readyState==='ended')return;
          const now=Date.now();if(now-lastTrim<20000)return;
          const ct=video.currentTime;
          if(ct>330){lastTrim=now; // 只清理 5 分钟前的数据，给回看留余量
            enqRm(sbV,0,ct-300).catch(()=>{});
            if(sbA)enqRm(sbA,0,ct-300).catch(()=>{});
          }
        },1000);
        ctrl.signal.addEventListener('abort',()=>{if(iv)clearInterval(iv);});
      }catch(e){if(!ctrl.signal.aborted)this.directFail(stage,ep,'浏览器不支持该视频编码：'+((/** @type {any} */ (e)).message||e));}
    });
  },
  /** @param {HTMLElement} stage @param {import('./types.js').Episode} ep @param {string} msg */
  directFail(stage,ep,msg){
    if(this.epId!==ep.id)return;
    const offline=!S.proxy;
    stage.innerHTML='<div class="player-fallback">'+
      '<div style="font-size:14.5px;color:#fff;font-weight:650">高清直连暂不可用</div>'+
      '<div class="tiny" style="color:rgba(255,255,255,.62);max-width:520px;line-height:1.75;margin:4px 0">'+esc(msg)+
      (offline?'<br>本地高清服务未运行：关闭页面后双击目录里的「启动课业（B站高清）.bat」，从自动打开的页面进入即可':'')+'</div>'+
      '<div style="display:flex;gap:9px;flex-wrap:wrap;justify-content:center;margin-top:8px">'+
      '<button class="btn btn-primary" id="plRetry">重试</button>'+
      '<button class="btn" id="plEmbed2" style="color:#fff;border-color:rgba(255,255,255,.4);background:transparent">改用应用内嵌</button>'+
      '<button class="btn" id="plExt2" style="color:#fff;border-color:rgba(255,255,255,.4);background:transparent">新标签打开</button></div></div>';
    $('#plRetry', stage).onclick=()=>this.mountBiliDirect(stage,ep);
    $('#plEmbed2', stage).onclick=()=>this.mountBiliEmbed(stage,ep);
    $('#plExt2', stage).onclick=()=>this.mountBiliExternal(stage,ep);
  },
  /** @param {import('./types.js').Episode} ep @returns {Promise<void>} */
  async mountLocal(ep){
    const box=this.md.body.querySelector('#plLocal');
    const stage=box.parentElement;
    // 浏览器 <video> 原生可解的容器走 objectURL；MKV/AVI 等走「上传缓存→ffmpeg 转码」通道。
    const NATIVE_LOCAL_EXTS=['.mp4','.m4v','.webm','.ogg','.ogv','.mov'];
    const play=(/** @type {any} */ file)=>{
      const nm=file.name||ep.fileName||'';
      const ext=('.'+(nm.split('.').pop()||'')).toLowerCase();
      if(NATIVE_LOCAL_EXTS.indexOf(ext)>=0){
        if(this.objectUrl)URL.revokeObjectURL(this.objectUrl);
        this.objectUrl=URL.createObjectURL(file);
        stage.innerHTML='<video controls autoplay src="'+this.objectUrl+'"></video>';
        const v=/** @type {any} */ (stage.querySelector('video'));
        this.bindVideoTimer(v,ep,()=>this.onEpEnded(ep));
        v.addEventListener('error',()=>{stage.innerHTML='<div class="player-fallback"><div style="font-size:14px">浏览器无法解码该视频</div><div class="tiny" style="color:rgba(255,255,255,.55)">请用系统播放器打开文件，学习时长可用下方计时器记录</div></div>';});
        this.bindFsNav(stage,ep);
      }else{
        this.playLocalTranscode(stage,ep,file,nm);
      }
    };
    /* FileSystemFileHandle 的 queryPermission/getFile/requestPermission 目前不在 TS 的
       DOM lib 里（非标准 API），所以按 any 用 —— 代码本身有 capabilities 检测。 */
    const h=/** @type {any} */ (ep.fileHandle);
    if(h){
      try{
        let perm=h.queryPermission?await h.queryPermission({mode:'read'}):'granted';
        if(perm==='granted'){play(await h.getFile());return;}
        box.innerHTML=I('folder')+'<div style="font-size:14px">需要授权读取文件</div><div class="tiny" style="color:rgba(255,255,255,.55)">'+esc(ep.fileName||'')+'</div><button class="btn btn-primary" id="plGrant">点击加载视频</button>';
        box.querySelector('#plGrant').onclick=async()=>{
          const p=await h.requestPermission({mode:'read'});
          if(p==='granted')play(await h.getFile());else toast('未获得文件读取权限','err');
        };
        return;
      }catch(e){/* 引用失效，走重新选择 */}
    }
    box.innerHTML=I('folder')+'<div style="font-size:14px">'+(ep.fileName?'找不到原文件：'+esc(ep.fileName):'选择本地视频文件')+'</div>'+
      '<div class="tiny" style="color:rgba(255,255,255,.55)">文件可能被移动或重命名，重新选择后会记住新位置</div><button class="btn btn-primary" id="plPick">选择视频文件</button>';
    box.querySelector('#plPick').onclick=async()=>{
      try{
        if(HAS_FS){
          /* showOpenFilePicker 也是非标准 API（不在 DOM lib 里）。 */
          const [fh]=await (/** @type {any} */ (window)).showOpenFilePicker({types:[{description:'视频',accept:{'video/*':['.mp4','.mkv','.webm','.mov','.m4v','.avi']}}]});
          ep.fileHandle=fh;ep.fileName=fh.name;await safePutEp(ep);play(await fh.getFile());
        }else{
          const inp=document.createElement('input');inp.type='file';inp.accept='video/*';
          inp.onchange=()=>{const f=(/** @type {any} */ (inp.files)||[])[0];if(f){ep.fileName=f.name;safePutEp(ep);play(f);}};
          inp.click();
        }
      }catch(e){if((/** @type {any} */ (e)).name!=='AbortError')toast('打开失败','err');}
    };
  },
  /** 浏览器解不了的「本地视频」(MKV/AVI 等)：先上传到后端缓存目录，再用 ffmpeg 转 fMP4 流播放。
   *  同一文件按「名称+大小+修改时间」指纹去重，只上传一次，之后直接走缓存并支持拖动进度条。
   *  @param {HTMLElement} stage @param {any} ep @param {File|Blob} file @param {string} name */
  async playLocalTranscode(stage,ep,file,name){
    const ext=('.'+(name.split('.').pop()||'')).toLowerCase();
    // cyrb53 指纹（64 位 → 16 位 hex），与后端 [0-9a-f]{16} 校验对应
    const cyrb53=(s)=>{let h1=0xdeadbeef,h2=0x41c6ce57;for(let i=0;i<s.length;i++){const ch=s.charCodeAt(i);h1=Math.imul(h1^ch,2654435761);h2=Math.imul(h2^ch,1597334677);}h1=Math.imul(h1^(h1>>>16),2246822507)^Math.imul(h2^(h2>>>13),3266489909);h2=Math.imul(h2^(h2>>>16),2246822507)^Math.imul(h1^(h1>>>13),3266489909);return (BigInt(h1>>>0)*4294967296n+BigInt(h2>>>0)).toString(16).padStart(16,'0');};
    const key=cyrb53(name+'|'+file.size+'|'+((/** @type {any} */(file).lastModified)||0));
    const enc=encodeURIComponent(name);
    const baseUrl='/api/media/cached/'+key+'/'+enc;
    const fmtSize=(n)=>n>=1073741824?(n/1073741824).toFixed(2)+' GB':n>=1048576?(n/1048576).toFixed(1)+' MB':Math.round(n/1024)+' KB';
    const renderProgress=(pct,label,sub)=>{stage.innerHTML='<div class="player-fallback"><div style="font-size:14px;margin-bottom:12px">'+esc(label)+'</div>'+
      '<div style="width:min(440px,82%);height:6px;background:rgba(255,255,255,.14);border-radius:3px;overflow:hidden"><div style="width:'+Math.max(0,Math.min(100,pct)).toFixed(1)+'%;height:100%;background:#1f8a70;transition:width .2s"></div></div>'+
      '<div class="tiny" style="color:rgba(255,255,255,.6);margin-top:8px">'+esc(sub||(Math.round(pct)+'%'))+'</div></div>';};
    const fail=(title,detail)=>{stage.innerHTML='<div class="player-fallback"><div style="font-size:14px">'+esc(title)+'</div><div class="tiny" style="color:rgba(255,255,255,.55);max-width:460px;margin-top:6px">'+esc(detail)+'</div></div>';};
    // 1) 是否已缓存
    let needUpload=true;
    try{
      const r=await fetch('/api/media/cache-status?key='+key+'&name='+enc);
      const o=await r.json();
      if(o&&o.code===0&&o.exists)needUpload=false;
    }catch(e){/* 状态查询失败则按需要上传处理，后端还有大小一致性兜底 */}
    // 2) 需要上传：先确认 ffmpeg 可用，再带进度上传
    if(needUpload){
      try{
        const cfg=await (await fetch('/api/media/config')).json();
        if(cfg&&cfg.code===0&&!cfg.hasFfmpeg){
          return fail('播放 '+ext+' 需要转码组件 ffmpeg','请运行程序目录里的「安装ffmpeg.bat」，或把 ffmpeg.exe 放到程序目录后重新打开该视频。');
        }
      }catch(e){}
      renderProgress(0,'正在缓存视频到本地（仅首次，之后直接打开）',fmtSize(file.size));
      let ok=true;
      await new Promise((resolve,reject)=>{
        const xhr=new XMLHttpRequest();
        xhr.open('POST','/api/media/upload?key='+key+'&name='+enc,true);
        xhr.upload.onprogress=(ev)=>{if(ev.lengthComputable)renderProgress(ev.loaded/ev.total*100,'正在缓存视频到本地（仅首次，之后直接打开）',fmtSize(ev.loaded)+' / '+fmtSize(ev.total));};
        xhr.onload=()=>{try{const o=JSON.parse(xhr.responseText);if(xhr.status===200&&o&&o.code===0)resolve();else reject(new Error((o&&o.message)||('HTTP '+xhr.status)));}catch(e){reject(new Error('响应解析失败'));}};
        xhr.onerror=()=>reject(new Error('本地服务连接失败（请确认代理程序正在运行）'));
        xhr.send(file);
      }).catch((err)=>{ok=false;fail('视频缓存失败',String((err&&err.message)||err)+'。也可在「设置」里配置媒体库文件夹后，用「媒体库视频」方式添加。');});
      if(!ok)return;
    }
    // 3) 播放转码流（不支持 Range，拖动进度条时用 ?t= 重新转码）
    stage.innerHTML='<video controls autoplay src="'+baseUrl+'"></video>';
    const v=/** @type {any} */ (stage.querySelector('video'));
    this.bindVideoTimer(v,ep,()=>this.onEpEnded(ep));
    let manual=false;
    v.addEventListener('seeking',()=>{
      if(manual)return;
      const t=v.currentTime||0;
      manual=true;
      v.src=baseUrl+'?t='+t;
      v.load();
      const p=v.play(); if(p&&p.catch)p.catch(()=>{});
      setTimeout(()=>{manual=false;},2000);
    });
    v.addEventListener('error',()=>{fail('转码播放失败','请确认 ffmpeg 已安装且文件未损坏；若原文件被移动或删除，可重新选择视频。');});
    this.bindFsNav(stage,ep);
  },
  /** 媒体库视频：后端直接伺服（浏览器支持的格式）或 ffmpeg 实时转码流（MKV/AVI 等）。
   * @param {HTMLElement} stage @param {import('./types.js').Episode} ep */
  mountLocalMedia(stage,ep){
    const rel=ep.url||'';
    if(!rel){stage.innerHTML='<div class="player-fallback"><div style="font-size:14px">该分集未关联媒体库文件</div><div class="tiny" style="color:rgba(255,255,255,.55)">请编辑分集，从媒体库中选择视频</div></div>';return;}
    const baseUrl='/api/media/play/'+rel;
    // 需要转码的格式（后端会转码为 fMP4 流，不支持 Range，需手动处理 seek）
    const transcodeExts=['.mkv','.avi','.flv','.wmv','.rmvb','.rm','.ts','.m2ts','.mts','.vob','.3gp','.3g2','.f4v','.divx','.xvid'];
    const ext=('.'+(rel.split('.').pop()||'')).toLowerCase();
    const needTranscode=transcodeExts.indexOf(ext)>=0;
    stage.innerHTML='<video controls autoplay src="'+baseUrl+'"></video>';
    const v=/** @type {any} */ (stage.querySelector('video'));
    this.bindVideoTimer(v,ep,()=>this.onEpEnded(ep));
    if(needTranscode){
      // 转码流不支持原生 seek：用户拖动进度条时，用 ?t= 重新从该位置转码
      let manual=false;
      v.addEventListener('seeking',()=>{
        if(manual)return;
        const t=v.currentTime||0;
        manual=true;
        v.src=baseUrl+'?t='+t;
        v.load();
        const p=v.play(); if(p&&p.catch)p.catch(()=>{});
        setTimeout(()=>{manual=false;},2000);
      });
    }
    v.addEventListener('error',()=>{
      stage.innerHTML='<div class="player-fallback"><div style="font-size:14px">播放失败</div>'+
        '<div class="tiny" style="color:rgba(255,255,255,.55);max-width:480px">'+
        (needTranscode?'该格式需要转码，请确认系统已安装 ffmpeg（放入程序目录或系统 PATH）。':'文件可能被移动或删除，请检查媒体库目录。')+
        '</div></div>';
    });
    this.bindFsNav(stage,ep);
  },
  /** @param {import('./types.js').Episode} ep */
  renderNotes(ep){
    const box=this.md.body.querySelector('#plNotes');
    const ns=notesOfEp(ep.id);
    box.innerHTML='<div style="display:flex;align-items:center;gap:8px;margin-bottom:7px"><span style="font-size:12px;font-weight:650">本集笔记 ('+ns.length+')</span>'+
      '<button class="btn btn-sm" id="plNewNote" style="margin-left:auto">'+I('plus')+' 记笔记</button></div>'+
      ns.map(n=>'<div class="pn-row" data-id="'+n.id+'"><div class="pn-title"><span>'+esc(n.title||'无标题笔记')+'</span><span class="dim tiny">'+humanAgo(n.updatedAt)+'</span></div><div class="pn-text">'+esc((n.text||'').slice(0,120))+'</div></div>').join('')+
      (ns.length?'':'<div class="tiny dim" style="padding:2px 2px 6px">还没有笔记，边学边记吧</div>');
    box.querySelector('#plNewNote').onclick=()=>noteForm({courseId:ep.courseId,epIds:[ep.id]});
    box.querySelectorAll('.pn-row').forEach((/** @type {any} */ r)=>r.onclick=()=>{const n=S.notes.find(x=>x.id===r.dataset.id);noteForm({note:n});});
  },
  /** @param {any} video @param {import('./types.js').Episode} ep @param {()=>void} onEnded */
  bindVideoTimer(video,ep,onEnded){
    let _lastPosSave=0;
    const saveNow=()=>{
      const t=video.currentTime||0;
      if(t>3&&video.duration&&t<video.duration-3){ // 有效进度：非开头、非结尾
        const fl=Math.floor(t);
        if((ep.playPos||0)!==fl){ep.playPos=fl;safePutEp(ep);}
      }
    };
    video.addEventListener('loadedmetadata',()=>{
      const pos=+(ep.playPos||0)||0;
      if(pos>3&&video.duration&&pos<video.duration-3){try{video.currentTime=pos;}catch(e){}}
    });
    video.addEventListener('play',()=>{
      if(this._pendFin){clearTimeout(this._pendFin);this._pendFin=null;}
      if(S.settings.autoLocal)this.start();
    });
    video.addEventListener('timeupdate',()=>{
      if(Date.now()-_lastPosSave>5000){_lastPosSave=Date.now();saveNow();}
    });
    video.addEventListener('pause',()=>{
      saveNow();
      if(video.ended)return;
      if(this._pendFin)clearTimeout(this._pendFin);
      this._pendFin=setTimeout(()=>{this._pendFin=null;this.finalize();},600); // seek 等瞬时暂停不结算
    });
    video.addEventListener('ended',()=>{
      saveNow();
      if(this._pendFin){clearTimeout(this._pendFin);this._pendFin=null;}
      this.finalize(); if(onEnded)onEnded();
    });
  },
  /** @param {import('./types.js').Episode} ep @returns {Promise<void>} */
  async onEpEnded(ep){
    if(ep.status!==2){await setEpStatus(ep,2);}
    const list=epsOf(ep.courseId);
    const i=list.findIndex(x=>x.id===ep.id),next=list[i+1];
    if(next&&S.settings.autoNext){
      toast('本集完成，2 秒后自动播放下一集','ok');
      this._nextTimer=setTimeout(()=>{if(this.epId===ep.id)this.open(next.id);},2000);
    }else{
      toast('本集播放完成，已自动标记','ok');
    }
  },
  checkpoint(){
    if(!this.timer||!this.timer.running||!this.curSess)return;
    this.curSess.sec+=(Date.now()-this.timer.startedAt)/1000;
    this.curSess.end=Date.now();
    this.timer.startedAt=Date.now();
    dbPut('sessions',this.curSess);this.upsert(this.curSess);this.refreshLearned();
  },
  start(){
    /* timer 在 open() 里初始化；这里加显式守卫（原先靠"调用顺序保证非空"）。 */
    if(!this.timer)return;
    if(this.timer.running)return;
    const ep=S.episodes.find(x=>x.id===this.epId);
    if(!ep)return;
    this.curSess={id:uid(),courseId:ep.courseId,epId:ep.id,start:Date.now(),end:Date.now(),sec:0,kind:'auto'};
    this.timer.running=true;this.timer.startedAt=Date.now();
    dbPut('sessions',this.curSess);this.upsert(this.curSess);
    if(this._chkTimer){clearInterval(this._chkTimer);}
    this._chkTimer=setInterval(()=>this.checkpoint(),30000);
    if(ep.status===0){ep.status=1;dbPut('episodes',ep);}
    const btn=this.md&&this.md.body.querySelector('#plStart');if(btn)btn.classList.remove('go'),btn.innerHTML=I('pause');
    const tb=this.md&&this.md.body.querySelector('#plTimer');if(tb)tb.classList.add('running');
  },
  finalize(){
    if(!this.timer)return;
    if(this._chkTimer){clearInterval(this._chkTimer);this._chkTimer=null;}
    if(this.timer.running&&this.curSess){
      this.curSess.sec+=(Date.now()-this.timer.startedAt)/1000;
      this.curSess.end=Date.now();
      if(this.curSess.sec>=2){dbPut('sessions',this.curSess);this.upsert(this.curSess);}
      this.timer.base+=this.curSess.sec;
      this.refreshLearned();
    }
    this.timer.running=false;this.curSess=null;
    const btn=this.md&&this.md.body.querySelector('#plStart');if(btn){btn.classList.add('go');btn.innerHTML=I('play');}
    const tb=this.md&&this.md.body.querySelector('#plTimer');if(tb){tb.classList.remove('running');tb.textContent=fmtTime(this.timer.base);}
  },
  pause(){this.finalize();},
  toggle(){const v=/** @type {any} */ (this.md&&this.md.body.querySelector('#plStage video'));
    if(this.timer&&this.timer.running){this.pause();if(v&&!v.paused)v.pause();}
    else{this.start();if(v&&v.paused)v.play().catch(()=>{});}},
  /** @param {number} sec */
  addManual(sec){
    const ep=S.episodes.find(x=>x.id===this.epId);
    if(!ep)return;
    const s={id:uid(),courseId:ep.courseId,epId:ep.id,start:Date.now(),end:Date.now(),sec,kind:'manual'};
    dbPut('sessions',s);this.upsert(s);this.refreshLearned();toast('已补记 '+Math.round(sec/60)+' 分钟','ok');
  },
  refreshLearned(){const l=/** @type {any} */ (this.md&&this.md.body.querySelector('#plLearned'));if(l)l.textContent=fmtDur(epSec(String(this.epId||'')));},
  tick(){
    if(!this.timer||!this.timer.running)return;
    const sec=this.timer.base+(this.curSess?this.curSess.sec:0)+(Date.now()-this.timer.startedAt)/1000;
    const tb=this.md.body.querySelector('#plTimer');if(tb)tb.textContent=fmtTime(sec);
  },
  close(){
    if(this._nextTimer){clearTimeout(this._nextTimer);this._nextTimer=null;}
    if(this._pendFin){clearTimeout(this._pendFin);this._pendFin=null;}
    if(this._fsHandler){document.removeEventListener('fullscreenchange',this._fsHandler);this._fsHandler=null;}
    if(document.fullscreenElement&&document.fullscreenElement.classList&&document.fullscreenElement.classList.contains('pl-video-wrap')){try{document.exitFullscreen();}catch(e){}}
    if(this._docKey){document.removeEventListener('keydown',this._docKey);this._docKey=null;}
    this.teardownPlayback();
    this.finalize();
    if(this._fetchCtrl)try{this._fetchCtrl.abort();}catch(e){this._fetchCtrl=null;}
    if(this._dashCtrl)try{this._dashCtrl.abort();}catch(e){this._dashCtrl=null;}
    if(this._dashUrl){try{URL.revokeObjectURL(this._dashUrl);}catch(e){}this._dashUrl=null;}
    if(this.tickTimer)clearInterval(this.tickTimer);
    if(this.objectUrl){URL.revokeObjectURL(this.objectUrl);this.objectUrl=null;}
    if(this.md){this.md.close();this.md=null;}
    this.epId=null;
    if(location.hash.startsWith('#/course/')){if(location.hash.indexOf('/play/')>-1)location.hash=location.hash.replace(/\/play\/[^/]*$/,'');else render();}
  }
};

/* 计时崩溃兜底：切走页面/刷新/关闭前立即结算，避免整段时长丢失 */
window.addEventListener('pagehide',()=>{try{if(Player.timer&&Player.timer.running&&Player.curSess)Player.finalize();}catch(e){}});
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden'){try{if(Player.timer&&Player.timer.running&&Player.curSess)Player.finalize();}catch(e){}}});

/* 多标签同步：回到前台时重新读取，避免后保存的标签用旧数据覆盖写回 */

/** @type {number|null} */
let _tabSyncTimer=null;
document.addEventListener('visibilitychange',()=>{
  if(document.visibilityState==='visible'){
    if(_tabSyncTimer)clearTimeout(_tabSyncTimer);
    _tabSyncTimer=setTimeout(()=>{try{loadAll().then(()=>{if(!document.querySelector('#modalRoot .modal')&&!((Player||{}).timer||{}).running)render();}).catch(e=>{});}catch(e){}},400);
  }
});

/* ================================================================
 * 笔记模块（Markdown + 附件）
 * ================================================================ */

/* 把播放器引用交给 forms.js（笔记表单要读 Player.epId）。
   放在 Player 定义之后，此时引用已就绪。 */
bindPlayer(Player);

export { Player, courseForm, drawEps, noteForm, viewCourseDetail };
