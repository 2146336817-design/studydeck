// @ts-check
// 数据模型 schema（**运行期**部分）：每张表的主键写死在一处。
//
// 字段形状的 JSDoc 类型定义在 js/types.js（那里带 @ts-check，是编译器真正读取的类型）。
// 本文件只保留运行期要用到的值，这样 db.js / test 可以直接 import。
//
// 为什么需要它：tasklog 的主键是 `key` 而不是 `id`（唯一一张这样设计的表），
// 而它曾经在一处按 `id` 过滤，导致打卡记录在恢复时被静默丢光 —— 测试全绿也没发现。
// 如果当时有这份 schema，那个 bug 根本写不出来。
//
// 用法：
//   · 运行时：db.js 建表时读 STORE_KEYS，避免"建表主键"和"过滤字段"两处各写一遍；
//   · 测试：断言真实 keyPath 与这里一致（test/run.mjs 的 schema 断言）；
//   · 类型：`@type {import('./types.js').Course}` 等，见 js/types.js。
//
// 约定：字段**缺失**通常应当容忍（旧备份少个可选字段不该丢数据），
//       字段**存在但类型错**才应当拒绝。见 app.js 导入时的形状校验。

/** 每张表的**主键字段名**。改这里就等于改建表语句（db.js 读它）。 */
export const STORE_KEYS = {
  courses: 'id',
  episodes: 'id',
  notes: 'id',
  attachments: 'id',
  blobs: 'id',
  sessions: 'id',
  mistakes: 'id',
  tasks: 'id',
  /** ⚠️ 唯一主键不是 id 的表：打卡记录，键是 `模板id@日期` */
  tasklog: 'key',
  /** 键值对存储，键也是 `key` */
  kv: 'key',
  resources: 'id',
};

/** 供测试与文档引用：主键不是 `id` 的表。 */
export const NON_ID_STORES = ['tasklog', 'kv'];

/**
 * 课程。
 * @typedef {Object} Course
 * @property {string} id
 * @property {string} name
 * @property {string} [subject]
 * @property {string} [color]      形如 #rrggbb；渲染前一律过 safeColor()
 * @property {string} [desc]
 * @property {number} [createdAt]
 * @property {number} [sort]
 */

/**
 * 分集。
 * @typedef {Object} Episode
 * @property {string} id
 * @property {string} courseId
 * @property {number} [order]
 * @property {string} [title]
 * @property {'bili'|'local'|string} [src]
 * @property {string} [url]
 * @property {number} [status]      0 未开始 / 1 进行中 / 2 已完成
 * @property {number|null} [completedAt]
 * @property {number} [updatedAt]
 * @property {string} [fileName]    本地视频文件名（渲染前必须 esc()）
 */

/**
 * 笔记。epIds 可能缺失（旧备份），读取处必须容忍。
 * @typedef {Object} Note
 * @property {string} id
 * @property {string} [courseId]
 * @property {string[]} [epIds]
 * @property {string} [title]
 * @property {string} [text]
 */

/**
 * 附件元数据。二进制本体在 blobs 表（或 _autobackup/blobs/）。
 * @typedef {Object} Attachment
 * @property {string} id
 * @property {string} [noteId]
 * @property {string} [name]
 * @property {string} [type]        MIME；可能缺失，读取处必须给默认值
 * @property {number} [size]
 * @property {boolean} [missing]    备份时被跳过 / 本机没有二进制
 */

/**
 * 附件二进制。
 * @typedef {Object} BlobRec
 * @property {string} id
 * @property {Blob} blob
 */

/**
 * 学习计时会话。
 * @typedef {Object} Session
 * @property {string} id
 * @property {string} [epId]
 * @property {number} [start]
 * @property {number} [end]
 * @property {number} [sec]
 */

/**
 * 错题。
 * @typedef {Object} Mistake
 * @property {string} id
 * @property {string} [subject]
 * @property {string} [chapter]
 * @property {string[]} [points]
 * @property {string} [stem]
 * @property {number} [status]
 */

/**
 * 任务 / 目标。
 * @typedef {Object} Task
 * @property {string} id
 * @property {'day'|'tpl'|'goal'|string} [kind]
 */

/**
 * 打卡记录。**主键是 key，不是 id** —— 结构为 `${taskId}@${date}`。
 * @typedef {Object} TaskLog
 * @property {string} key           `${tplId}@${date}`，见 views-task.js 的 logKey()
 * @property {string} [tplId]
 * @property {string} [date]        YYYY-MM-DD
 * @property {number} [doneAt]
 */

/**
 * 资料库条目（文件或文件夹）。
 * @typedef {Object} Resource
 * @property {string} id
 * @property {string} [name]
 * @property {string} [kind]        'folder' | 'folder-item' | 其他
 * @property {{id:string}[]} [files] kind 为 folder-item 时的子文件（删除时要一并清 blobs）
 */

/**
 * 应用设置。凭证 SESSDATA 不进备份。
 * @typedef {Object} Settings
 * @property {string} [theme]
 * @property {number} [dailyGoal]
 * @property {boolean} [autoLocal]
 * @property {boolean} [autoBackup]
 * @property {string} [sessdata]
 */

/**
 * 备份文件的形状（v3：files[] 只存清单，二进制走独立通道）。
 * @typedef {Object} BackupFile
 * @property {'studydeck'} app
 * @property {number} version
 * @property {number} [exportedAt]
 * @property {Course[]} [courses]
 * @property {Episode[]} [episodes]
 * @property {Note[]} [notes]
 * @property {Attachment[]} [attachments]
 * @property {Session[]} [sessions]
 * @property {Mistake[]} [mistakes]
 * @property {Task[]} [tasks]
 * @property {TaskLog[]} [tasklog]
 * @property {Resource[]} [resources]
 * @property {Settings} [settings]
 * @property {{id:string,size?:number,type?:string,name?:string,data?:string}[]} [files]
 * @property {number} [_skippedBlobs]
 * @property {number} [_blobBytes]
 */
