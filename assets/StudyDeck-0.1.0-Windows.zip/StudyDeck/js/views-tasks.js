// @ts-check
// 任务与目标视图：日视图 / 月视图 / 任务表单。
// （从 views-task.js 拆出。）
import { I } from './icons.js';
import { S, dbDel, dbPut } from './db.js';
import { confirmDialog, openModal, toast } from './ui.js';
import { el, esc, fmtSize, openAttachment, pad2, todayKey, uid } from './util.js';
import { render, viewHead } from './viewkit.js';
import { catTag, taskCats, dkAdd, dkWeekday, dkLabel, curMonthKey, monthLabel, monthDays, weekStart, weekOf, repText, logOn, dayItems, toggleDay, monthGoals, goalPct, setGoalDone, goalStep, LINK_ICON, LINK_TEXT, openTaskLink, linkEditorHTML, bindLinkEditor } from './task-utils.js';
import { importTimetable, buildTimetableSheets, downloadTimetable } from './task-timetable.js';

function viewTasks(main){
  const u=S.ui.task;
  main.innerHTML=
    viewHead('任务','每日课程表与待办、月度目标；可关联课程 / 笔记 / 错题 / 链接，数据保存在本机',
      '<div class="task-tabs"><button class="tt '+(u.tab==='daily'?'on':'')+'" data-tab="daily">每日任务</button><button class="tt '+(u.tab==='monthly'?'on':'')+'" data-tab="monthly">月度目标</button></div>')+
    '<div id="taskBody"></div>';
  main.querySelectorAll('.task-tabs .tt').forEach(b=>b.onclick=()=>{u.tab=b.dataset.tab;render();});
  if(u.tab==='monthly')drawMonthly(main.querySelector('#taskBody'));else drawDaily(main.querySelector('#taskBody'));
}

/* ---------- 每日任务 ---------- */

function drawDaily(box){
  const u=S.ui.task,dk=u.day||todayKey();
  const days=weekOf(dk),ws=weekStart(dk);
  let h='<div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-top:4px">'+
    '<button class="btn btn-sm" id="wkPrev">'+I('chevrL')+' 上周</button>'+
    '<button class="btn btn-sm" id="wkToday">今天</button>'+
    '<button class="btn btn-sm" id="wkNext">下周 '+I('chevR')+'</button>'+
    '<span class="small dim" style="margin-left:4px">'+(function(){const a=days[0],b=days[6];return a.slice(5).replace('-','/')+' — '+b.slice(5).replace('-','/');})()+'</span></div>';
  h+='<div class="weekstrip">'+days.map(d=>{
    const items=dayItems(d),done=items.filter(x=>x.done).length,pct=items.length?Math.round(done/items.length*100):0;
    return '<div class="wday '+(d===dk?'on':'')+'" data-d="'+d+'"><div class="wd-d">周'+'日一二三四五六'[dkWeekday(d)]+'</div><div class="wd-n">'+(+d.slice(8))+'</div>'+
      (items.length?'<div class="wd-bar"><div style="height:100%;border-radius:99px;background:'+(d===dk?'rgba(255,255,255,.9)':'var(--accent)')+';width:'+pct+'%"></div></div>':'<div class="wd-bar"></div>')+'</div>';
  }).join('')+'</div>';
  const items=dayItems(dk),done=items.filter(x=>x.done).length,pct=items.length?Math.round(done/items.length*100):0;
  const C=2*Math.PI*18;
  h+='<div class="day-summary"><div class="day-ring"><svg width="44" height="44"><circle cx="22" cy="22" r="18" fill="none" stroke="var(--surface-2)" stroke-width="4"/><circle cx="22" cy="22" r="18" fill="none" stroke="var(--accent)" stroke-width="4" stroke-linecap="round" stroke-dasharray="'+C.toFixed(1)+'" stroke-dashoffset="'+(C*(1-pct/100)).toFixed(1)+'"/></svg><div class="dr-t">'+done+'/'+items.length+'</div></div>'+
    '<div><div style="font-weight:650;font-size:15px">'+(dk===todayKey()?'今天 · ':'')+dkLabel(dk)+'</div><div class="small dim">'+(items.length?(pct===100?'全部完成，做得好':'已完成 '+done+' 项，还有 '+(items.length-done)+' 项'):'这一天还没有安排')+'</div></div>'+
    '<span style="flex:1"></span><button class="btn btn-sm" id="dayTpl">'+I('download')+' 空白模板</button><button class="btn btn-sm" id="dayExp">'+I('save')+' 导出</button><button class="btn btn-sm" id="dayImport">'+I('upload')+' 导入弹性课程表</button><button class="btn btn-sm" id="dayAddTpl">'+I('rotate')+' 管理重复课程表</button></div>';
  h+='<div class="quickadd"><input class="input" id="qaTitle" placeholder="添加任务，如：08:00 数学课 / 交物理作业 / 跑步 30 分钟，回车快速创建"><select class="select" id="qaCat" style="width:110px">'+taskCats().map(c=>'<option>'+esc(c)+'</option>').join('')+'</select><input class="input" id="qaTime" type="time" style="width:120px"><button class="btn btn-primary" id="qaBtn">'+I('plus')+' 添加</button></div>';
  h+='<div id="dayList"></div>';
  box.innerHTML=h;
  box.querySelector('#wkPrev').onclick=()=>{u.day=dkAdd(ws,-7);render();};
  box.querySelector('#wkNext').onclick=()=>{u.day=dkAdd(ws,7);render();};
  box.querySelector('#wkToday').onclick=()=>{u.day=todayKey();render();};
  box.querySelectorAll('.wday').forEach(w=>w.onclick=()=>{u.day=w.dataset.d;render();});
  box.querySelector('#dayAddTpl').onclick=()=>taskForm({kind:'tpl',date:dk});
  box.querySelector('#dayImport').onclick=importTimetable;
  box.querySelector('#dayTpl').onclick=()=>downloadTimetable('/api/timetable/template',null,'在家自学弹性课程表-空白模板.xlsx');
  box.querySelector('#dayExp').onclick=()=>downloadTimetable('/api/timetable/export',{sheets:buildTimetableSheets()},'在家自学弹性课程表-导出.xlsx');
  async function submitQuick(){
    const inp=box.querySelector('#qaTitle');let title=inp.value.trim();if(!title)return;
    let time=box.querySelector('#qaTime').value,cat=box.querySelector('#qaCat').value;
    const m=title.match(/^(\d{1,2})[:：](\d{2})\s+/);
    if(m&&!time){time=pad2(+m[1])+':'+m[2];title=title.slice(m[0].length);}
    const task={id:uid(),kind:'day',date:dk,time:time||'',title,note:'',cat:cat||'学习',link:{type:'none'},repeat:'none',done:false,doneAt:0,order:Date.now(),createdAt:Date.now(),updatedAt:Date.now()};
    await dbPut('tasks',task);S.tasks.push(task);inp.value='';box.querySelector('#qaTime').value='';drawDaily(box);
  }
  box.querySelector('#qaBtn').onclick=submitQuick;
  box.querySelector('#qaTitle').onkeydown=e=>{if(e.key==='Enter')submitQuick();};
  const list=box.querySelector('#dayList');
  if(!items.length){
    list.innerHTML='<div class="empty">'+I('calendar')+'<div class="empty-title">这一天还没有任务</div><div>上方输入框回车即可添加；固定课程表可用「管理重复课程表」设置每周自动出现</div></div>';
    return;
  }
  list.innerHTML=items.map(it=>taskRowHTML(it,dk)).join('');
  bindTaskRows(list,dk,()=>drawDaily(box));
}

function taskAtts(t){return S.attachments.filter(a=>a.noteId===t.id);}

function taskRowHTML(it,dk){
  const t=it.t,atts=taskAtts(t),l=t.link||{type:'none'};
  return '<div class="card task-row" data-id="'+t.id+'"><div class="t-check '+(it.done?'done':'')+'" data-check="'+t.id+'">'+I('check')+'</div>'+
    '<div class="task-main" data-edit="'+t.id+'"><div class="t-title '+(it.done?'done':'')+'">'+esc(t.title)+'</div>'+
    '<div class="t-meta">'+(t.time?'<span class="t-time">'+I('clock')+' '+t.time+'</span>':'')+catTag(t.cat)+
    (it.tpl?'<span class="t-rep">'+I('rotate')+' '+repText(t)+'</span>':'')+
    (atts.length?'<span class="t-att-chip">'+I('file')+' '+atts.length+' 个附件</span>':'')+'</div></div>'+
    '<div class="task-side">'+(l.type!=='none'?'<button class="icon-btn" data-go="'+t.id+'" title="'+LINK_TEXT[l.type]+'">'+I(LINK_ICON[l.type]||'link')+'</button>':'')+
    '<button class="icon-btn" data-editb="'+t.id+'" title="编辑">'+I('edit')+'</button></div></div>';
}

function bindTaskRows(container,dk,after){
  container.querySelectorAll('[data-check]').forEach(b=>b.onclick=async()=>{
    const t=S.tasks.find(x=>x.id===b.dataset.check);
    const it={t,tpl:t.kind==='tpl',done:t.kind==='tpl'?logOn(t.id,dk):t.done};
    await toggleDay(it,dk);after();
  });
  const openEdit=id=>taskForm({task:S.tasks.find(x=>x.id===id),date:dk});
  container.querySelectorAll('[data-edit]').forEach(b=>b.onclick=()=>{const t=S.tasks.find(x=>x.id===b.dataset.edit);if(t&&t.link&&t.link.type!=='none')openTaskLink(t.link);else openEdit(b.dataset.edit);});
  container.querySelectorAll('[data-editb]').forEach(b=>b.onclick=()=>openEdit(b.dataset.editb));
  container.querySelectorAll('[data-go]').forEach(b=>b.onclick=e=>{e.stopPropagation();const t=S.tasks.find(x=>x.id===b.dataset.go);openTaskLink(t.link);});
}

/* ---------- 月度目标 ---------- */

function drawMonthly(box){
  const u=S.ui.task,m=u.month||curMonthKey();
  const goals=monthGoals(m);
  let h='<div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-top:4px">'+
    '<button class="btn btn-sm" id="moPrev">'+I('chevrL')+' 上月</button>'+
    '<button class="btn btn-sm" id="moToday">本月</button>'+
    '<button class="btn btn-sm" id="moNext">下月 '+I('chevR')+'</button>'+
    '<span style="font-weight:650;font-size:15px;margin-left:6px">'+monthLabel(m)+'</span>'+
    '<span style="flex:1"></span><button class="btn btn-primary btn-sm" id="moAdd">'+I('plus')+' 添加目标</button></div>';
  const gdone=goals.filter(g=>g.done||goalPct(g)===100).length;
  h+='<div class="small dim" style="margin:10px 0 12px">本月目标 '+(goals.length?(' '+gdone+' / '+goals.length+' 已完成'):'还没有目标，点击右上角添加')+'</div>';
  h+='<div class="goal-grid" id="goalGrid"></div>';
  h+='<div class="card card-pad" style="margin-top:16px"><div class="section-title">'+I('calendar')+' 本月每日任务完成情况 <span class="tiny" style="font-weight:400">点击日期可跳转安排 / 查看</span></div><div class="cal-grid">'+
    ['一','二','三','四','五','六','日'].map(x=>'<div class="cal-h">'+x+'</div>').join('')+
    '<div id="calCells" style="display:contents"></div></div></div>';
  box.innerHTML=h;
  box.querySelector('#moPrev').onclick=()=>{const [y,mo]=m.split('-').map(Number);const d=new Date(y,mo-2,1);u.month=d.getFullYear()+'-'+pad2(d.getMonth()+1);render();};
  box.querySelector('#moNext').onclick=()=>{const [y,mo]=m.split('-').map(Number);const d=new Date(y,mo,1);u.month=d.getFullYear()+'-'+pad2(d.getMonth()+1);render();};
  box.querySelector('#moToday').onclick=()=>{u.month=curMonthKey();render();};
  box.querySelector('#moAdd').onclick=()=>taskForm({kind:'month',month:m});
  const grid=box.querySelector('#goalGrid');
  if(!goals.length)grid.outerHTML='<div class="empty" id="goalGrid" style="grid-column:1/-1">'+I('flag')+'<div class="empty-title">本月还没有目标</div><div>例如：刷完 30 道错题、背 20 篇课文、跑步 15 次；可量化也可纯待办</div></div>';
  else{
    grid.innerHTML=goals.map(g=>{
      const pct=goalPct(g),atts=taskAtts(g),l=g.link||{type:'none'};
      return '<div class="card goal-card" data-id="'+g.id+'">'+
        '<div class="g-title '+(g.done?'done':'')+'"><div class="t-check '+(g.done?'done':'')+'" style="margin-top:0" data-gcheck="'+g.id+'">'+I('check')+'</div>'+
        '<span style="flex:1">'+esc(g.title)+'</span>'+(l.type!=='none'?'<button class="icon-btn" data-ggo="'+g.id+'" title="'+LINK_TEXT[l.type]+'">'+I(LINK_ICON[l.type]||'link')+'</button>':'')+
        '<button class="icon-btn" data-gedit="'+g.id+'">'+I('edit')+'</button></div>'+
        (g.cat?'<div>'+catTag(g.cat)+'</div>':'')+
        (g.note?'<div class="g-note">'+esc(g.note)+'</div>':'')+
        (g.target?(
          '<div class="gprog"><i style="width:'+pct+'%"></i></div>'+
          '<div class="g-num"><button data-gdec="'+g.id+'">−</button><span class="g-val">'+(g.current||0)+' / '+g.target+' '+esc(g.unit||'')+'</span><button data-ginc="'+g.id+'">+</button></div>'
        ):('<div class="small dim" style="margin-top:4px">'+(g.done?'已完成':'待完成')+'</div>'))+
        (atts.length?'<div class="t-att-strip"><span class="t-att-chip">'+I('file')+' '+atts.length+' 个附件</span></div>':'')+'</div>';
    }).join('');
    grid.querySelectorAll('[data-gcheck]').forEach(b=>b.onclick=async()=>{const g=S.tasks.find(x=>x.id===b.dataset.gcheck);await setGoalDone(g);drawMonthly(box);});
    grid.querySelectorAll('[data-ginc]').forEach(b=>b.onclick=async()=>{const g=S.tasks.find(x=>x.id===b.dataset.ginc);await goalStep(g,+1);drawMonthly(box);});
    grid.querySelectorAll('[data-gdec]').forEach(b=>b.onclick=async()=>{const g=S.tasks.find(x=>x.id===b.dataset.gdec);await goalStep(g,-1);drawMonthly(box);});
    grid.querySelectorAll('[data-gedit]').forEach(b=>b.onclick=()=>taskForm({task:S.tasks.find(x=>x.id===b.dataset.gedit)}));
    grid.querySelectorAll('[data-ggo]').forEach(b=>b.onclick=()=>{const g=S.tasks.find(x=>x.id===b.dataset.ggo);openTaskLink(g.link);});
    grid.querySelectorAll('.goal-card').forEach(c=>{ /* 卡片空白处点击：有关联跳转，无关联编辑 */ c.onclick=e=>{if(e.target.closest('button'))return;const g=S.tasks.find(x=>x.id===c.dataset.id);if(g&&g.link&&g.link.type!=='none')openTaskLink(g.link);else taskForm({task:g});};});
  }
  /* 月历 */
  const cells=box.querySelector('#calCells');
  const first=monthDays(m)[0],lead=(dkWeekday(first)+6)%7; // 周一领先
  let ch='';
  for(let i=0;i<lead;i++)ch+='<div class="cal-cell muted"></div>';
  monthDays(m).forEach(d=>{
    const items=dayItems(d),dn=items.filter(x=>x.done).length,pct=items.length?dn/items.length:0;
    const bg=items.length?('rgba(15,107,84,'+(0.06+0.2*pct).toFixed(2)+')'):'var(--surface)';
    ch+='<div class="cal-cell '+(d===todayKey()?'today':'')+'" data-d="'+d+'" style="background:'+bg+'"><div class="cal-n">'+(+d.slice(8))+'</div>'+
      (items.length?'<div class="cal-r '+(pct===1?'full':'')+'">'+(pct===1?'✓':dn+'/'+items.length)+'</div>':'<div class="cal-r" style="opacity:0">·</div>')+'</div>';
  });
  cells.innerHTML=ch;
  cells.querySelectorAll('.cal-cell[data-d]').forEach(c=>c.onclick=()=>{S.ui.task.tab='daily';S.ui.task.day=c.dataset.d;render();});
}

/* ---------- 任务 / 目标表单 ---------- */

function taskForm(opt){
  const isNew=!opt.task;
  const task=opt.task||{id:uid(),kind:opt.kind||'day',date:opt.date||todayKey(),month:opt.month||curMonthKey(),time:'',title:'',note:'',cat:'学习',link:{type:'none'},repeat:'none',weekdays:[],target:0,unit:'',current:0,done:false,doneAt:0,order:Date.now(),createdAt:Date.now(),updatedAt:Date.now()};
  const isMonth=task.kind==='month';
  const wrap=el('div');
  let h='<div class="field"><input class="input" id="tfTitle" style="font-size:15px;font-weight:650" placeholder="'+(isMonth?'目标名称，如：刷完 30 道函数错题':'任务名称，如：听数学第 3 集 / 交英语作业 / 跑步')+'" value="'+esc(task.title)+'"></div>';
  h+='<div class="field"><div style="display:flex;gap:9px;flex-wrap:wrap">'+
    '<div style="flex:1;min-width:130px"><label class="field-label">分类</label><input class="input" id="tfCat" list="dlTaskCat" value="'+esc(task.cat||'学习')+'"><datalist id="dlTaskCat">'+taskCats().map(c=>'<option value="'+esc(c)+'">').join('')+'</datalist></div>';
  if(isMonth){
    h+='<div style="flex:1;min-width:130px"><label class="field-label">所属月份</label><input class="input" id="tfMonth" type="month" value="'+task.month+'"></div>';
  }else{
    h+='<div style="width:130px"><label class="field-label">时间（可选）</label><input class="input" id="tfTime" type="time" value="'+esc(task.time||'')+'"></div>'+
      '<div style="flex:1;min-width:150px"><label class="field-label">日期</label><input class="input" id="tfDate" type="date" value="'+task.date+'"></div>';
  }
  h+='</div></div>';
  if(!isMonth){
    const rep=task.kind==='tpl'?(task.repeat||'weekly'):'none';
    h+='<div class="field"><label class="field-label">重复（课程表 / 习惯）</label><select class="select" id="tfRep" style="width:auto;min-width:170px">'+
      [['none','不重复，仅此一次'],['daily','每天'],['weekdays','工作日（周一至周五）'],['weekly','每周指定几天']].map(([v,n])=>'<option value="'+v+'"'+(rep===v?' selected':'')+'>'+n+'</option>').join('')+'</select>'+
      '<div id="tfWk" style="display:none;margin-top:8px;gap:6px;display:flex;flex-wrap:wrap">'+[1,2,3,4,5,6,0].map(w=>'<label style="display:inline-flex;gap:4px;align-items:center;font-size:12.5px;cursor:pointer"><input type="checkbox" data-w="'+w+'" '+(task.weekdays&&task.weekdays.includes(w)?'checked':'')+'> 周'+'一二三四五六日'[w===0?6:w-1]+'</label>').join('')+'</div>'+
      '<div class="field-hint">重复任务会自动出现在对应日期，勾选完成只记录当天；适合固定课程表与每日习惯</div></div>';
  }else{
    h+='<div class="field"><label class="field-label">量化目标（不填就是纯待办）</label><div style="display:flex;gap:9px"><div style="flex:1"><div class="field-hint" style="margin:0 0 4px">目标值</div><input class="input" id="tfTarget" type="number" min="0" step="1" value="'+(task.target||'')+'" placeholder="如 30"></div>'+
      '<div style="flex:1"><div class="field-hint" style="margin:0 0 4px">当前进度</div><input class="input" id="tfCurrent" type="number" min="0" step="1" value="'+(task.current||0)+'"></div>'+
      '<div style="flex:1"><div class="field-hint" style="margin:0 0 4px">单位</div><input class="input" id="tfUnit" placeholder="题 / 次 / 小时" value="'+esc(task.unit||'')+'"></div></div></div>';
  }
  h+='<div class="field"><label class="field-label">备注 / 作业要求</label><textarea class="textarea" id="tfNote" style="min-height:70px" placeholder="可写作业要求、提交方式、提醒事项…">'+esc(task.note||'')+'</textarea></div>';
  h+='<div class="field"><label class="field-label">关联（点击任务即可跳转）</label><div id="tfLink"></div></div>';
  h+='<div class="field" style="margin-bottom:0"><label class="field-label">附件：作业文档、试卷、照片等，保存在本机</label>'+
    '<div class="drop-zone" id="tfDrop">'+I('upload')+'<div style="margin-top:5px">点击选择，或把文件拖到这里</div></div><div id="tfAtts" style="margin-top:9px"></div></div>';
  wrap.innerHTML=h;
  const $s=id=>wrap.querySelector(id);
  /* 重复 */
  let wkBox=null;
  if(!isMonth){
    const repSel=$s('#tfRep');wkBox=$s('#tfWk');
    function repDraw(){wkBox.style.display=repSel.value==='weekly'?'flex':'none';}
    repSel.onchange=repDraw;repDraw();
    if(repSel.value==='weekly'&&!(task.weekdays||[]).length){const w=dkWeekday(task.date);wkBox.querySelector('[data-w="'+w+'"]').checked=true;}
  }
  /* 关联 */
  const link=Object.assign({type:'none',id:'',url:''},task.link||{});
  $s('#tfLink').innerHTML=linkEditorHTML(link);
  bindLinkEditor(wrap,link);
  /* 附件 */
  const attIds=S.attachments.filter(a=>a.noteId===task.id).map(a=>a.id);
  async function addFiles(files){
    for(const f of files){const id=uid();await dbPut('blobs',{id,blob:f});
      const att={id,noteId:task.id,kind:'task',name:f.name,type:f.type||'application/octet-stream',size:f.size,createdAt:Date.now()};
      await dbPut('attachments',att);S.attachments.push(att);attIds.push(id);}
    drawAtts();
  }
  async function removeAtt(id){await dbDel('blobs',id);await dbDel('attachments',id);
    const i=S.attachments.findIndex(a=>a.id===id);if(i>=0)S.attachments.splice(i,1);
    const j=attIds.indexOf(id);if(j>=0)attIds.splice(j,1);drawAtts();}
  function drawAtts(){
    const list=attIds.map(id=>S.attachments.find(a=>a.id===id)).filter(Boolean);
    $s('#tfAtts').innerHTML=list.map(a=>{const isImg=(a.type||'').startsWith('image/');
      return '<div class="att-list-row" data-id="'+a.id+'"><div class="att-thumb">'+(isImg?I('image'):(a.type==='application/pdf'?I('pdf'):I('file')))+'</div>'+
      '<div class="att-main"><div class="att-name">'+esc(a.name)+'</div><div class="att-size">'+fmtSize(a.size)+'</div></div>'+
      '<button class="icon-btn" data-open>'+I('eye')+'</button><button class="icon-btn danger" data-del>'+I('trash')+'</button></div>';}).join('');
    $s('#tfAtts').querySelectorAll('.att-list-row').forEach(r=>{
      r.querySelector('[data-open]').onclick=()=>openAttachment(S.attachments.find(a=>a.id===r.dataset.id));
      r.querySelector('[data-del]').onclick=()=>removeAtt(r.dataset.id);});
  }
  drawAtts();
  const dz=$s('#tfDrop');
  dz.onclick=()=>{const inp=document.createElement('input');inp.type='file';inp.multiple=true;inp.onchange=()=>addFiles([...inp.files]);inp.click();};
  ['dragover','dragenter'].forEach(ev=>dz.addEventListener(ev,e=>{e.preventDefault();dz.classList.add('drag');}));
  ['dragleave','drop'].forEach(ev=>dz.addEventListener(ev,e=>{e.preventDefault();dz.classList.remove('drag');}));
  dz.addEventListener('drop',e=>addFiles([...e.dataTransfer.files]));

  const foot=document.createDocumentFragment();
  let delBtn;
  if(!isNew){delBtn=el('button','btn btn-danger',I('trash')+' 删除');delBtn.type='button';delBtn.style.marginRight='auto';foot.appendChild(delBtn);}
  const cancel=el('button','btn','取消');cancel.type='button';
  const ok=el('button','btn btn-primary',I('save')+' 保存');ok.type='button';
  foot.append(cancel,ok);
  const md=openModal({title:isNew?(isMonth?'添加月度目标':'新建任务'):(isMonth?'编辑目标':'编辑任务'),body:wrap,footer:foot,wide:true});
  cancel.onclick=async()=>{if(isNew){for(const id of attIds){await dbDel('blobs',id);await dbDel('attachments',id);}}md.close();};
  ok.onclick=async()=>{
    task.title=$s('#tfTitle').value.trim();
    if(!task.title){toast('请填写名称','err');return;}
    task.cat=$s('#tfCat').value.trim()||'学习';
    task.note=$s('#tfNote').value;
    task.link=link.type==='url'?{type:'url',url:(link.url||'').trim()}:{type:link.type,id:link.id||''};
    if(link.type==='url'&&task.link.url&&!/^https?:\/\//.test(task.link.url))task.link.url='https://'+task.link.url;
    task.updatedAt=Date.now();
    if(isMonth){
      task.kind='month';task.month=$s('#tfMonth').value||curMonthKey();
      task.target=Math.max(0,parseInt($s('#tfTarget').value||'0',10)||0);
      task.current=Math.max(0,parseFloat($s('#tfCurrent').value||'0')||0);
      task.unit=$s('#tfUnit').value.trim();
      if(task.target&&task.current>=task.target){task.done=true;task.doneAt=task.doneAt||Date.now();}
    }else{
      task.time=$s('#tfTime').value||'';task.date=$s('#tfDate').value||todayKey();
      const rep=$s('#tfRep').value;
      if(rep==='none'){task.kind='day';task.repeat='none';}
      else{task.kind='tpl';task.repeat=rep;
        task.weekdays=[...wkBox.querySelectorAll('input[data-w]')].filter(c=>c.checked).map(c=>+c.dataset.w);
        if(rep==='weekly'&&!task.weekdays.length){toast('请选择每周重复的星期','err');return;}
      }
    }
    await dbPut('tasks',task);
    const i=S.tasks.findIndex(x=>x.id===task.id);if(i>=0)S.tasks[i]=task;else S.tasks.push(task);
    md.close();render();toast('已保存','ok');
  };
  if(delBtn)delBtn.onclick=async()=>{
    let msg='确定删除这个任务吗？';
    if(task.kind==='tpl')msg='这是重复任务（课程表），删除后所有日期都不再出现，已有的完成记录也会清除。确定删除？';
    const okd=await confirmDialog('删除',msg,'删除');if(!okd)return;
    for(const id of attIds){await dbDel('blobs',id);await dbDel('attachments',id);}
    if(task.kind==='tpl'){const ls=S.tasklog.filter(l=>l.tplId===task.id);for(const l of ls)await dbDel('tasklog',l.key);S.tasklog=S.tasklog.filter(l=>l.tplId!==task.id);}
    await dbDel('tasks',task.id);const i=S.tasks.findIndex(x=>x.id===task.id);if(i>=0)S.tasks.splice(i,1);
    md.close();render();toast('已删除','ok');
  };
}

/* ================================================================
 * 概览 + 统计
 * ================================================================ */


export { viewTasks, drawDaily, taskAtts, taskRowHTML, bindTaskRows, drawMonthly, taskForm };
