// @ts-check
// 课表（在校自学弹性课程表）的导入与导出。
// （从 views-task.js 拆出。）
import { S, dbPut } from './db.js';
import { toast } from './ui.js';
import { todayKey, uid } from './util.js';
import { render } from './viewkit.js';

function applyTimetableTasks(sheets){
  const WD={周一:1,周二:2,周三:3,周四:4,周五:5,周六:6};
  const KEEP={'学习':1,'刷题整理':1,'俄语课':1,'俄语':1};
  const made=[];
  const existing=new Set(S.tasks.filter(t=>t.kind==='tpl').map(t=>[t.title,t.repeat||'',(t.weekdays||[]).join(','),t.time||''].join('|')));
  for(const sh of sheets){
    const wd=WD[sh.name]; if(!wd)continue;
    const rows=sh.rows||[];
    for(let i=3;i<rows.length;i++){
      const r=rows[i]; if(!r||r.length<5)continue;
      const start=String(r[0]||'').trim(), title=String(r[3]||'').trim(), type=String(r[4]||'').trim();
      if(!start||!title||!/^\d{1,2}:\d{2}$/.test(start)||!KEEP[type])continue;
      const m=title.match(/(数学|物理|化学|生物|语文|俄语)/);
      const cat=m?m[1]:'学习';
      const key=[title,'weekly',String(wd),start].join('|');
      if(existing.has(key))continue;
      const task={id:uid(),kind:'tpl',date:todayKey(),repeat:'weekly',weekdays:[wd],time:start,title,note:'',cat,link:{type:'none'},done:false,doneAt:0,order:Date.now(),createdAt:Date.now(),updatedAt:Date.now()};
      S.tasks.push(task);existing.add(key);made.push(task);
    }
  }
  return (async()=>{for(const t of made)await dbPut('tasks',t);return made.length;})();
}

function importTimetable(){
  const inp=document.createElement('input');inp.type='file';inp.accept='.xlsx';
  inp.onchange=async()=>{
    const f=inp.files[0];if(!f)return;
    try{
      const bytes=new Uint8Array(await f.arrayBuffer());let bin='';
      for(let i=0;i<bytes.length;i++)bin+=String.fromCharCode(bytes[i]);
      const res=await fetch('/api/import/timetable',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({file_b64:btoa(bin),name:f.name})});
      const j=await res.json();
      if(j.code!==0)return toast('解析失败：'+(j.message||'未知错误'),'err');
      const n=await applyTimetableTasks(j.data||[]);
      toast('已导入 '+n+' 个每周重复任务（可继续导入同一文件，不会重复）','ok');render();
    }catch(e){toast('导入失败：'+e.message,'err');}
  };
  inp.click();
}

function buildTimetableSheets(){
  const WD={1:'周一',2:'周二',3:'周三',4:'周四',5:'周五',6:'周六'};
  const sheets=[];
  for(const wd of [1,2,3,4,5,6]){
    const tasks=S.tasks.filter(t=>t.kind==='tpl'&&t.repeat==='weekly'&&(t.weekdays||[]).includes(wd)).sort((a,b)=>(a.time||'').localeCompare(b.time||''));
    const rows=[];
    rows.push([WD[wd]+' · 弹性课程表（导出）']);
    rows.push(['类型可选：学习 / 刷题整理 / 俄语课；可再导入任务板块']);
    rows.push([]);
    rows.push(['开始','结束','时长(分)','学习安排','类型','弹性说明 / 备注']);
    for(const t of tasks)rows.push([t.time||'','','',t.title,(/俄语课/.test(t.title)?'俄语课':/刷题|整理|专题/.test(t.title)?'刷题整理':'学习'),'']);
    sheets.push({name:WD[wd],rows});
  }
  return sheets;
}

function downloadTimetable(url,body,filename){
  const opts=body?{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}:{};
  fetch(url,opts).then(r=>{if(!r.ok)throw new Error('HTTP '+r.status);return r.blob();}).then(blob=>{
    const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),1500);
  }).catch(e=>toast('下载失败：'+e.message,'err'));
}


export { applyTimetableTasks, importTimetable, buildTimetableSheets, downloadTimetable };
