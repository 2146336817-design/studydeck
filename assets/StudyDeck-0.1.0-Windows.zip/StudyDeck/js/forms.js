// 各种表单：课程 / 分集 / 批量添加分集 / 笔记，以及分集拖拽排序。
//
// 从 player.js 拆出来：它们都是"界面上的一张表单"，与播放器内核没有关系。
// 依赖方向是单向的：player.js → forms.js → video-files.js。
//
// 注意 bindPlayer()：笔记表单要读 _player.epId（判断是否给当前播放的分集挂笔记），
// 若直接 import Player 就会形成 forms ⇄ player 的 import 环。
// 改为由 player.js 在求值后注入，环就断了。
import { I } from './icons.js';
import { S, attsOfNote, courseOf, dbDel, dbPut, dbPutMany, epsOf, loadAll, notesOfEp } from './db.js';
import { confirmDialog, openModal, toast } from './ui.js';
import { render } from './viewkit.js';
import { $, COURSE_COLORS, biliMeta, el, epNumberOf, esc, fmtSize, md2html, openAttachment, parseBili, parseCollection, rangeText, safeColor, uid } from './util.js';
import { HAS_FS, pickVideoFiles, safePutEp } from './video-files.js';
import { aiConfigured, aiGenerateNotes, bvidOfEpisode, isBiliEpisode, showAiResult } from './ai.js';

/* 由 player.js 注入播放器引用（避免 import 环）。绑好之前用到它会抛错，属于编程错误。
   名字用 _player 而不是 Player：打包时所有模块在同一个作用域里，
   player.js 也有一个 const Player，重名会被打包器的重复声明检查拦下。 */
/** @type {any} */
let _player = null;
/** @param {any} p */
function bindPlayer(p) { _player = p; }

/** @param {import('./types.js').Course} [course] */
function courseForm(course){
  const c=course||{name:'',subject:'',color:COURSE_COLORS[S.courses.length%COURSE_COLORS.length],desc:''};
  const wrap=el('div');
  wrap.innerHTML=
    '<div class="field"><label class="field-label">课程名称 *</label><input class="input" id="cfName" value="'+esc(c.name)+'" placeholder="例如：线性代数 / Python 入门"></div>'+
    '<div class="form-row"><div class="field"><label class="field-label">学科 / 分类</label><input class="input" id="cfSubject" value="'+esc(c.subject||'')+'" placeholder="数学、编程…"></div>'+
    '<div class="field"><label class="field-label">标识色</label><div class="color-row" id="cfColors"></div></div></div>'+
    '<div class="field"><label class="field-label">简介（可选）</label><textarea class="textarea" id="cfDesc" style="min-height:70px" placeholder="教材、老师、学习目标…">'+esc(c.desc||'')+'</textarea></div>';
  let chosen=c.color;
  const row=wrap.querySelector('#cfColors');
  COURSE_COLORS.forEach(col=>{
    const d=el('button','color-dot'+(col===chosen?' on':''), I('check'));
    d.style.background=col; d.type='button';
    d.onclick=()=>{chosen=col; row.querySelectorAll('.color-dot').forEach((/** @type {any} */ x)=>x.classList.toggle('on',x===d));};
    row.appendChild(d);
  });
  const foot=document.createDocumentFragment();
  const cancel=el('button','btn','取消'); cancel.type='button';
  const ok=el('button','btn btn-primary',I('save')+' 保存'); ok.type='button';
  foot.append(cancel,ok);
  const md=openModal({title:course?'编辑课程':'新建课程',body:wrap,footer:foot});
  cancel.onclick=()=>md.close();
  wrap.querySelector('#cfName').focus();
  ok.onclick=async()=>{
    const name=wrap.querySelector('#cfName').value.trim();
    if(!name){toast('请填写课程名称','err');return;}
    /** @type {any} Object.assign 会在下面补上 id/createdAt/sort */
    const data={name, subject:wrap.querySelector('#cfSubject').value.trim(), color:safeColor(chosen),
      desc:wrap.querySelector('#cfDesc').value.trim()};
    if(course){Object.assign(course,data);await dbPut('courses',course);}
    else{Object.assign(data,{id:uid(),createdAt:Date.now(),sort:Date.now()});await dbPut('courses',data);S.courses.push(data);}
    md.close(); render(); toast(course?'已保存':'课程已创建','ok');
  };
}


/** @param {import('./types.js').Course} course @param {import('./types.js').Episode|null} [ep] */
function episodeForm(course, ep){
  const e=ep||{title:'',src:'bili',url:'',fileName:'',estMin:''};
  const wrap=el('div');
  wrap.innerHTML=
    '<div class="field"><label class="field-label">分集标题 *</label><input class="input" id="efTitle" value="'+esc(e.title)+'" placeholder="第 1 集 / 导论"></div>'+
    '<div class="field"><label class="field-label">来源类型</label><div style="display:flex;gap:7px;flex-wrap:wrap" id="efSrc">'+
      ['bili','local','local-media','web'].map(s=>'<button type="button" class="filter-chip '+(e.src===s?'on':'')+'" data-s="'+s+'">'+({bili:'B站视频',local:'本地视频','local-media':'媒体库视频',web:'其他网页链接'})[s]+'</button>').join('')+'</div></div>'+
    '<div class="field" id="efUrlBox"><label class="field-label">链接</label><input class="input" id="efUrl" value="'+esc(e.url||'')+'" placeholder="粘贴 B 站视频地址，支持 ?p= 分 P"><div class="field-hint" id="efUrlHint"></div></div>'+
    '<div class="field" id="efLocalBox" style="display:none"><div class="drop-zone" id="efLocal">'+I('folder')+'<div style="margin-top:6px" id="efLocalName">'+(e.fileName?esc(e.fileName):'点击选择本地视频文件（可在播放器中直接播放）')+'</div></div>'+
      '<div class="field-hint">'+(HAS_FS?'浏览器会记住文件引用，不会复制视频本身；若移动了文件位置，播放时重新选择即可。':'当前浏览器不支持文件引用记忆，每次播放时需要重新选择文件。推荐使用 Edge 或 Chrome。')+'</div></div>'+
    '<div class="field" id="efMediaBox" style="display:none"><label class="field-label">选择媒体库中的视频</label><select class="input" id="efMediaSel" style="width:100%"><option value="">加载中…</option></select>'+
      '<div class="field-hint" id="efMediaHint">从设置里指定的媒体库目录中选择。MKV/AVI 等浏览器不支持的格式会自动转码播放。</div></div>'+
    '<div class="field"><label class="field-label">单集时长（分钟，可选，用于计划统计）</label><input class="input" id="efEst" type="number" min="0" value="'+(e.estMin||'')+'" style="width:140px"></div>';
  /* Episode.fileHandle 在类型上是 unknown（浏览器句柄，无法结构化克隆），所以按 any 读。 */
  const efh=/** @type {any} */ (e).fileHandle;
  let src=e.src, picked=efh?{handle:efh}:null, pickedName=e.fileName||'';
  let mediaPath=e.src==='local-media'?(e.url||''):'';
  let mediaLoaded=false;
  /** @param {string} s */
function switchSrc(s){src=s; wrap.querySelectorAll('#efSrc .filter-chip').forEach((/** @type {any} */ b)=>b.classList.toggle('on',b.dataset.s===s));
    wrap.querySelector('#efUrlBox').style.display=(s==='local'||s==='local-media')?'none':'';
    wrap.querySelector('#efLocalBox').style.display=s==='local'?'':'none';
    wrap.querySelector('#efMediaBox').style.display=s==='local-media'?'':'none';
    const hint=wrap.querySelector('#efUrlHint');
    hint.textContent = s==='bili'?'支持 BV 号链接与分 P 参数 p，播放时在应用内嵌入播放器。':'其他平台（网易云课堂、腾讯课堂等）将在新标签页打开。';
    if(s==='local-media'&&!mediaLoaded){loadMediaList();}
  }
  async function loadMediaList(){
    mediaLoaded=true;
    const sel=/** @type {any} */ (wrap.querySelector('#efMediaSel'));
    const hint=wrap.querySelector('#efMediaHint');
    try{
      const r=await fetch('/api/media/list');const j=await r.json();
      if(j.code!==0||!j.files||!j.files.length){
        sel.innerHTML='<option value="">（媒体库为空或未设置）</option>';
        hint.textContent='请先在「设置」里指定媒体库目录，并把视频放入该目录。';
        return;
      }
      sel.innerHTML='<option value="">请选择视频…</option>'+j.files.map((/** @type {any} */ f)=>'<option value="'+esc(f.path)+'"'+(f.path===mediaPath?' selected':'')+'>'+esc(f.path)+' ('+(f.size?Math.round(f.size/1048576)+'MB':'?')+')</option>').join('');
      hint.textContent='共 '+j.files.length+' 个视频。MKV/AVI 等格式会自动转码播放。';
    }catch(err){sel.innerHTML='<option value="">（加载失败）</option>';hint.textContent='加载媒体库列表失败，请确认本地服务已启动。';}
  }
  wrap.querySelectorAll('#efSrc .filter-chip').forEach((/** @type {any} */ b)=>b.onclick=()=>switchSrc(b.dataset.s));
  wrap.querySelector('#efLocal').onclick=async()=>{
    try{
      const r=await pickVideoFiles(); if(!r.length)return;
      picked=/** @type {any} */ (r[0]); pickedName=r[0].name;
      wrap.querySelector('#efLocalName').textContent=pickedName;
    }catch(err){if((/** @type {any} */ (err)).name!=='AbortError')toast('选择文件失败','err');}
  };
  switchSrc(String(src||''));
  wrap.querySelector('#efUrl').oninput=(/** @type {any} */ ev)=>{
    if(src!=='bili')return; const b=parseBili(ev.target.value);
    wrap.querySelector('#efUrlHint').textContent = b?('已识别：'+(b.bvid||'av'+b.avid)+(b.page>1?' · 分 P'+b.page:'')):'';
  };
  const foot=document.createDocumentFragment();
  const cancel=el('button','btn','取消');cancel.type='button';
  const ok=el('button','btn btn-primary',I('save')+' 保存');ok.type='button';
  foot.append(cancel,ok);
  const md=openModal({title:ep?'编辑分集':'添加分集',body:wrap,footer:foot});
  cancel.onclick=()=>md.close(); wrap.querySelector('#efTitle').focus();
  ok.onclick=async()=>{
    const title=wrap.querySelector('#efTitle').value.trim();
    if(!title){toast('请填写分集标题','err');return;}
    const url=wrap.querySelector('#efUrl').value.trim();
    if(src==='bili'&&(!url||!parseBili(url))){toast('未识别到有效的 B 站 BV 链接','err');return;}
    const list=epsOf(course.id);
    /** @type {any} 这个对象下面会被 Object.assign 补上 fileName/fileHandle 等字段 */
    const data={title,src,url:(src==='local'||src==='local-media')?'':url,estMin:+wrap.querySelector('#efEst').value||0};
    if(src==='local'){data.fileName=pickedName; if(picked&&picked.handle)data.fileHandle=picked.handle;}
    if(src==='local-media'){
      const sel=/** @type {any} */ (wrap.querySelector('#efMediaSel'));
      const mp=sel.value||'';
      if(!mp){toast('请从媒体库中选择一个视频','err');return;}
      data.url=mp; data.fileName=mp.split('/').pop()||mp;
    }
    if(ep){Object.assign(ep,data);if(src!=='local'&&src!=='local-media'){delete ep.fileHandle;ep.fileName='';}if(src!=='local-media'){/* 保留 url 字段逻辑已在 data 里处理 */}await safePutEp(ep);}
    else{Object.assign(data,{id:uid(),courseId:course.id,order:list.length?(list[list.length-1].order||0)+1:0,
      status:0,completedAt:null});await safePutEp(data);}
    md.close();await loadAll();render();toast('已保存','ok');
  };
}


/** @param {import('./types.js').Course} course */
function batchEpisodeForm(course){
  const wrap=el('div');
  wrap.innerHTML=
    '<div style="display:flex;gap:7px;margin-bottom:15px" id="bfTabs">'+
      ['<button type="button" class="filter-chip on" data-t="links">粘贴多个链接</button>',
       '<button type="button" class="filter-chip" data-t="seq">按序号生成</button>',
       '<button type="button" class="filter-chip" data-t="files">选择本地视频</button>',
       '<button type="button" class="filter-chip" data-t="col">合集网址</button>'].join('')+'</div>'+
    '<div id="bfLinks"><div class="field"><label class="field-label">每行一个视频链接（支持 B 站 BV / 分 P）</label>'+
      '<textarea class="textarea" id="bfLinksText" style="min-height:140px" placeholder="https://www.bilibili.com/video/BVxxxx?p=1&#10;https://www.bilibili.com/video/BVxxxx?p=2&#10;…"></textarea></div>'+
      '<div class="form-row"><div class="field"><label class="field-label">标题前缀</label><input class="input" id="bfPre" value="第"></div>'+
      '<div class="field"><label class="field-label">标题后缀</label><input class="input" id="bfSuf" value="集"></div>'+
      '<div class="field"><label class="field-label">起始编号</label><input class="input" id="bfStart" type="number" value="1"></div></div>'+
      '<div class="field-hint">B站分 P 链接会自动识别 P 号作为编号；其他链接按行号顺序编号，作为网页链接处理。</div></div>'+
    '<div id="bfStatus" class="field-hint" style="min-height:18px;color:var(--accent);margin-top:2px"></div>'+
    '<div id="bfSeq" style="display:none"><div class="form-row"><div class="field" style="flex:2"><label class="field-label">标题前缀</label><input class="input" id="sqPre" value="第"></div>'+
      '<div class="field"><label class="field-label">起始</label><input class="input" id="sqStart" type="number" value="1"></div>'+
      '<div class="field"><label class="field-label">结束</label><input class="input" id="sqEnd" type="number" value="12"></div>'+
      '<div class="field" style="flex:2"><label class="field-label">后缀</label><input class="input" id="sqSuf" value="集"></div></div>'+
      '<div class="field-hint">生成没有链接的占位分集，之后可以逐个编辑挂上视频。</div></div>'+
    '<div id="bfFiles" style="display:none"><div class="drop-zone" id="bfPick">'+I('video')+'<div style="margin-top:6px">点击选择一个或多个视频，或直接把多个视频拖入这里</div><div class="field-hint" style="margin-top:4px">将按文件名排序，每个视频成为一集</div></div><div id="bfFileList" style="margin-top:10px"></div></div>'+
    '<div id="bfCol" style="display:none"><div class="field"><label class="field-label">B站合集网址</label>'+
      '<input class="input" id="bfColUrl" placeholder="合集/收藏夹/番剧/UP主：合集 …/lists/123?type=season、收藏夹 …/favlist?fid=123、番剧 …/bangumi/play/ss123、UP主 …/space.bilibili.com/123"></div>'+
      '<div style="display:flex;gap:7px;margin-top:9px;align-items:center"><button type="button" class="btn" id="bfColFetch">解析合集</button>'+
      '<span id="bfColInfo" class="field-hint" style="margin:0;color:var(--accent)"></span></div>'+
      '<div class="field-hint" style="margin-top:4px">解析后会把合集内全部视频按原顺序导入，每集自动带上视频标题。</div>'+
      '<div id="bfColList" style="margin-top:10px;max-height:220px;overflow:auto"></div></div>';
  let tab='links', pickedFiles=/** @type {any[]} */ ([]);
  const tabs=wrap.querySelectorAll('#bfTabs .filter-chip');
  tabs.forEach((/** @type {any} */ b)=>b.onclick=()=>{tab=b.dataset.t;tabs.forEach((/** @type {any} */ x)=>x.classList.toggle('on',x===b));
    wrap.querySelector('#bfLinks').style.display=tab==='links'?'':'none';
    wrap.querySelector('#bfSeq').style.display=tab==='seq'?'':'none';
    wrap.querySelector('#bfFiles').style.display=tab==='files'?'':'none';
    wrap.querySelector('#bfCol').style.display=tab==='col'?'':'none';
  });
  wrap.querySelector('#bfPick').onclick=async()=>{
    try{const r=await pickVideoFiles();if(!r.length)return;
      const seen=new Set(pickedFiles.map(f=>f.name));
      for(const f of r){ if(!seen.has(f.name)){pickedFiles.push(f);seen.add(f.name);} }
      wrap.querySelector('#bfFileList').innerHTML=pickedFiles.map(f=>'<div class="att-list-row"><div class="att-thumb">'+I('video')+'</div><div class="att-main"><div class="att-name">'+esc(f.name)+'</div></div></div>').join('');
      toast('当前共 '+pickedFiles.length+' 个视频','ok');
    }catch(e){if((/** @type {any} */ (e)).name!=='AbortError')toast('选择失败','err');}
  };
  const foot=document.createDocumentFragment();
  const cancel=el('button','btn','取消');cancel.type='button';
  const ok=el('button','btn btn-primary',I('plus')+' 添加');ok.type='button';
  foot.append(cancel,ok);
  const pickZone=wrap.querySelector('#bfPick');
  pickZone.ondragover=(/** @type {any} */ e)=>{e.preventDefault();pickZone.classList.add('drag');};
  pickZone.ondragleave=()=>pickZone.classList.remove('drag');
  pickZone.ondrop=(/** @type {any} */ e)=>{
    e.preventDefault(); pickZone.classList.remove('drag');
    const items=[...e.dataTransfer.items].filter(i=>i.kind==='file');
    if(!items.length){toast('请拖入视频文件','err');return;}
    Promise.all(items.map(it=>{
      if(it.getAsFileSystemHandle){return it.getAsFileSystemHandle().then((/** @type {any} */ h)=>h?{name:h.name,handle:h}:null).catch(()=>{const f=it.getAsFile();return f?{name:f.name,file:f}:null;});}
      const f=it.getAsFile(); return f?{name:f.name,file:f}:null;
    })).then(res=>{
      const seen=new Set(pickedFiles.map(f=>f.name));
      for(const f of res){ if(f&&!seen.has(f.name)){pickedFiles.push(f);seen.add(f.name);} }
      wrap.querySelector('#bfFileList').innerHTML=pickedFiles.map(f=>'<div class="att-list-row"><div class="att-thumb">'+I('video')+'</div><div class="att-main"><div class="att-name">'+esc(f.name)+'</div></div></div>').join('');
      if(!pickedFiles.length)toast('没有可导入的视频文件','err');
      else toast('已选择 '+pickedFiles.length+' 个视频','ok');
    });
  };
  wrap.querySelector('#bfColFetch').onclick=async()=>{
    const url=wrap.querySelector('#bfColUrl').value.trim();
    const pc=parseCollection(url);
    if(!pc){toast('无法识别合集/收藏夹网址（支持合集 collectiondetail/lists、收藏夹 favlist/medialist）','err');return;}
    const info=wrap.querySelector('#bfColInfo'), list=wrap.querySelector('#bfColList');
    info.textContent='正在获取'+(pc.type==='fav'?'收藏夹':pc.type==='pgc'?'番剧':pc.type==='up'?'UP主':'合集')+'…'; list.innerHTML='';
    try{
      const api=pc.type==='fav'
        ? '/api/bili/favlist?fid='+encodeURIComponent(pc.fid)
        : pc.type==='pgc'
        ? '/api/bili/pgc?'+(pc.ep?('ep='+encodeURIComponent(pc.ep)):('ssid='+encodeURIComponent(pc.ssid)))
        : pc.type==='up'
        ? '/api/bili/up?mid='+encodeURIComponent(pc.mid)
        : '/api/bili/collection?sid='+encodeURIComponent(pc.sid);
      const _ac=new AbortController();const _killer=setTimeout(()=>_ac.abort(),60000);
      let r;
      try{r=await fetch(api,{headers:{'X-Sessdata':S.settings.sessdata||''},signal:_ac.signal});}
      finally{clearTimeout(_killer);}
      const j=await r.json();
      if(j.code!==0)throw new Error(j.message||('接口返回码 '+j.code));
      wrap._bfColVideos=j.data.videos;
      info.textContent=(j.data.name?'「'+j.data.name+'」：':'合集：')+'共 '+j.data.total+' 个视频';
      list.innerHTML=j.data.videos.map((/** @type {any} */ v,/** @type {number} */ i)=>
        '<div class="att-list-row"><div class="att-main"><div class="att-name">'+(i+1)+'. '+esc(v.title)+'</div>'+
        '<div class="att-size">BV'+(v.bvid||'')+'</div></div></div>').join('');
    }catch(e){wrap._bfColVideos=null;info.textContent='';toast((/** @type {any} */ (e)).name==='AbortError'?'解析超时（超过60秒），请检查网络或稍后重试':'解析合集失败：'+((/** @type {any} */ (e)).message||''),'err');}
  };
  const md=openModal({title:'批量添加分集',body:wrap,footer:foot,wide:true});
  cancel.onclick=()=>md.close();
  ok.onclick=async()=>{
    const exist=epsOf(course.id); let order=exist.length?(exist[exist.length-1].order||0)+1:0; const adds=[];
    if(tab==='links'){
      const pre=wrap.querySelector('#bfPre').value, suf=wrap.querySelector('#bfSuf').value;
      let n=(+wrap.querySelector('#bfStart').value)||1; const start=n;
      const lines=wrap.querySelector('#bfLinksText').value.split('\n').map((/** @type {string} */ x)=>x.trim()).filter(Boolean);
      if(!lines.length){toast('请先粘贴链接','err');return;}
      for(const line of lines){
        const b=parseBili(line);
        const hasP=/[?&]p=(\d+)/.test(line);
        const num = b&&hasP ? (b.page + start - 1) : n;
        adds.push({id:uid(),courseId:course.id,order:order++,title:pre+num+suf,
          src:b?'bili':'web',url:line,fileName:'',estMin:0,status:0,completedAt:null});
        n++;
      }
    const status=wrap.querySelector('#bfStatus');
    const bili=adds.filter(a=>a.src==='bili'&&parseBili(a.url)&&!(/** @type {any} */ (parseBili(a.url))).ep);
    if(status&&bili.length){
      ok.disabled=true; ok.textContent='识别标题中…';
      let done=0;
      for(const a of bili){
        if(status)status.textContent='正在自动识别标题… '+done+'/'+bili.length;
        try{
          const b=/** @type {any} */ (parseBili(a.url)), info=await biliMeta(b);
          if(info){
            const pg=(info.pages||[]).find((/** @type {any} */ p)=>p.page===((b.page||1))) || (info.pages||[])[0];
            const t=(pg&&pg.part?pg.part:info.title)||'';
            if(t)a.title=t;
          }
        }catch(e){}
        done++;
        if(status)status.textContent='正在自动识别标题… '+done+'/'+bili.length;
      }
      ok.disabled=false; ok.textContent=I('plus')+' 添加';
      if(status)status.textContent='已自动识别 '+done+' 个 B 站标题；识别不到的保留“第 N 集”式编号';
    }
    }else if(tab==='col'){
      const col=wrap._bfColVideos;
      if(!col||!col.length){toast('请先解析合集','err');return;}
      for(const v of col){
        const isPgc=(v.ep!=null&&v.ep!=='');
        adds.push({id:uid(),courseId:course.id,order:order++,title:(v.title||('第'+(adds.length+1)+'集')),
          src:'bili',url:isPgc?('https://www.bilibili.com/bangumi/play/ep'+v.ep):('https://www.bilibili.com/video/'+(v.bvid||'')),fileName:'',estMin:0,status:0,completedAt:null});
      }
    }else if(tab==='seq'){
      const pre=wrap.querySelector('#sqPre').value,suf=wrap.querySelector('#sqSuf').value;
      const st=+wrap.querySelector('#sqStart').value||1, en=+wrap.querySelector('#sqEnd').value||st;
      if(en<st){toast('结束编号需不小于起始','err');return;}
      for(let i=st;i<=en;i++)adds.push({id:uid(),courseId:course.id,order:order++,title:pre+i+suf,src:'web',url:'',fileName:'',estMin:0,status:0,completedAt:null});
    }else{
      if(!pickedFiles.length){toast('请先选择视频文件','err');return;}
      pickedFiles.sort((a,b)=>a.name.localeCompare(b.name,'zh',{numeric:true}));
      for(const f of pickedFiles){const ep={id:uid(),courseId:course.id,order:order++,title:f.name.replace(/\.[^.]+$/,''),src:'local',url:'',fileName:f.name,estMin:0,status:0,completedAt:null};
        if(f.handle)/** @type {any} */ (ep).fileHandle=f.handle; try{await safePutEp(ep);adds.push(ep);}catch(e){}}
      await loadAll();md.close();render();toast('已添加 '+adds.length+' 个本地分集','ok');return;
    }
    for(const a of adds)await dbPut('episodes',a);
    md.close();await loadAll();render();toast('已添加 '+adds.length+' 集','ok');
  };
}

/* 课程详情视图 */
/* 分集手动排序：拖拽调整某一集顺序（仅“全部”筛选下启用） */


/** @param {HTMLElement} box */
function enableEpDrag(box){
  /** @type {string|null} */
  let dragId=null, dragging=false, startY=0, suppressClick=false;
  const clear=()=>{
    box.querySelectorAll('.ep-row').forEach((/** @type {any} */ r)=>r.classList.remove('dragging','drop-before','drop-after'));
    document.removeEventListener('pointermove',onMove);
    document.removeEventListener('pointerup',onUp);
  };
  function orderIds(){return [...box.querySelectorAll('.ep-row')].map((/** @type {any} */ r)=>r.dataset.id);}
  function onMove(/** @type {any} */ e){
    if(!dragId)return;
    if(!dragging&&Math.abs(e.clientY-startY)<8)return;
    dragging=true;
    const src=/** @type {any} */ (box.querySelector('.ep-row[data-id="'+dragId+'"]'));
    if(src)src.classList.add('dragging');
    box.querySelectorAll('.ep-row').forEach((/** @type {any} */ r)=>{
      const rect=r.getBoundingClientRect();
      if(e.clientY>=rect.top&&e.clientY<=rect.bottom&&r.dataset.id!==dragId){
        const after=(e.clientY-rect.top)>(rect.height/2);
        r.classList.toggle('drop-after',after); r.classList.toggle('drop-before',!after);
        if(after)r.after(src); else r.before(src);
      }else{r.classList.remove('drop-before','drop-after');}
    });
  }
  function onUp(){
    if(dragId&&dragging){
      const ids=orderIds();
      const cid=(S.episodes.find(x=>x.id===dragId)||{}).courseId;
      const all=S.episodes.filter(e=>e.courseId===cid);
      all.forEach(e=>{e.order=ids.indexOf(e.id);});
      suppressClick=true; setTimeout(()=>suppressClick=false,0);
      dbPutMany('episodes',all).then(()=>{render();toast('已调整分集顺序','ok');});
    }
    dragId=null; dragging=false; clear();
  }
  box.querySelectorAll('.ep-row').forEach(row=>{
    row.classList.add('sortable');
    row.addEventListener('pointerdown',(/** @type {any} */ e)=>{
      if(e.target.closest('button'))return;
      dragId=/** @type {any} */ (row).dataset.id; startY=e.clientY; dragging=false;
      document.addEventListener('pointermove',onMove);
      document.addEventListener('pointerup',onUp);
    });
    const main=/** @type {any} */ (row.querySelector('.ep-main'));
    if(main){const orig=main.onclick; main.onclick=(/** @type {any} */ e)=>{if(suppressClick){e.preventDefault();e.stopPropagation();return;}if(orig)orig(e);};}
  });
}


/** @param {any} opt 笔记表单选项（courseId / epIds / note 等） */
function noteForm(opt){
  const isNew=!opt.note;
  const note=opt.note||{id:uid(),courseId:opt.courseId||(S.courses[0]&&S.courses[0].id)||'',epIds:opt.epIds||[],title:'',text:'',createdAt:Date.now(),updatedAt:Date.now()};
  if(!note.courseId&&S.courses[0])note.courseId=S.courses[0].id;
  const wrap=el('div');
  wrap.innerHTML=
    '<div class="field"><input class="input" id="nfTitle" style="font-size:15px;font-weight:650" placeholder="笔记标题（可留空）" value="'+esc(note.title)+'"></div>'+
    '<div class="field"><div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">'+
      '<select class="select" id="nfCourse" style="width:auto;min-width:150px">'+S.courses.map(c=>'<option value="'+c.id+'">'+esc(c.name)+'</option>').join('')+'</select>'+
      '<button class="btn btn-sm" id="nfRange" type="button">'+I('list')+' <span id="nfRangeText"></span></button>'+
      '<button class="btn btn-sm" id="nfAi" type="button" style="display:none">'+I('sparkles')+' AI 生成笔记</button>'+
      '<span style="flex:1"></span>'+
      '<div class="filter-chip on" data-mode="edit" id="nfTabEdit">编辑</div><div class="filter-chip" data-mode="prev" id="nfTabPrev">预览</div></div>'+
      '<div id="nfEpBox" class="card" style="padding:11px;margin-top:9px;display:none;max-height:210px;overflow-y:auto"></div></div>'+
    '<div class="field" id="nfEditBox"><textarea class="textarea" id="nfText" style="min-height:200px" placeholder="支持简单 Markdown：# 标题、- 列表、**加粗**、`代码`、[链接](url)"></textarea></div>'+
    '<div class="field" id="nfPrevBox" style="display:none"><div class="card md-preview" id="nfPreview" style="padding:14px;min-height:200px"></div></div>'+
    '<div class="field"><label class="field-label">附件（图片、PDF、文档等，保存在本机）</label>'+
      '<div class="drop-zone" id="nfDrop">'+I('upload')+'<div style="margin-top:5px">点击选择，或直接把文件拖到这里</div></div>'+
      '<div id="nfAtts" style="margin-top:9px"></div></div>';
  const $s=(/** @type {string} */ id)=>wrap.querySelector(id);
  $s('#nfCourse').value=note.courseId; $s('#nfText').value=note.text;
  let epSel=new Set(note.epIds), epBoxOpen=false, mode='edit';
  function rangeRefresh(){$s('#nfRangeText').textContent=rangeText([...epSel],note.courseId);
    /* AI 生成笔记按钮：只在选中了 B 站分集且已配置 AI Key 时显示 */
    const aiBtn=$s('#nfAi');
    if(aiBtn){
      const hasBili=[...epSel].some(id=>{const e=S.episodes.find(x=>x.id===id);return isBiliEpisode(e);});
      aiBtn.style.display=(hasBili&&aiConfigured())?'':'none';
    }
  }
  function drawEpBox(){
    const eps=epsOf(note.courseId);
    $s('#nfEpBox').innerHTML = eps.length?
      ('<div style="margin-bottom:7px;display:flex;gap:7px"><button class="btn btn-sm" type="button" id="epAll">全选</button><button class="btn btn-sm" type="button" id="epNone">清空（整门课笔记）</button></div>'+
      eps.map(e=>'<label style="display:flex;gap:8px;align-items:center;padding:3px 2px;font-size:12.5px;cursor:pointer"><input type="checkbox" data-id="'+e.id+'" '+ (epSel.has(e.id)?'checked':'')+'> <span class="status-dot s'+e.status+'"></span>第 '+epNumberOf(e)+' 集 · '+esc(e.title)+'</label>').join(''))
      :'<div class="small dim">这门课还没有分集，笔记将关联到整门课</div>';
    $s('#nfEpBox').querySelectorAll('input[data-id]').forEach((/** @type {any} */ cb)=>cb.onchange=()=>{
      if(cb.checked)epSel.add(cb.dataset.id);else epSel.delete(cb.dataset.id);rangeRefresh();});
    const ea=$s('#epAll');if(ea)ea.onclick=()=>{eps.forEach(e=>epSel.add(e.id));drawEpBox();rangeRefresh();};
    const en=$s('#epNone');if(en)en.onclick=()=>{epSel.clear();drawEpBox();rangeRefresh();};
  }
  $s('#nfCourse').onchange=(/** @type {any} */ e)=>{note.courseId=e.target.value;epSel=new Set([...epSel].filter(id=>S.episodes.find(x=>x.id===id&&x.courseId===note.courseId)));drawEpBox();rangeRefresh();};
  $s('#nfRange').onclick=()=>{epBoxOpen=!epBoxOpen;$s('#nfEpBox').style.display=epBoxOpen?'':'none';if(epBoxOpen)drawEpBox();};
  rangeRefresh();
  $s('#nfTabEdit').onclick=()=>{mode='edit';$s('#nfEditBox').style.display='';$s('#nfPrevBox').style.display='none';$s('#nfTabEdit').classList.add('on');$s('#nfTabPrev').classList.remove('on');};
  $s('#nfTabPrev').onclick=()=>{mode='prev';$s('#nfEditBox').style.display='none';$s('#nfPrevBox').style.display='';$s('#nfTabPrev').classList.add('on');$s('#nfTabEdit').classList.remove('on');$s('#nfPreview').innerHTML=md2html($s('#nfText').value)||'<span class="dim">暂无内容</span>';};
  /* AI 生成笔记：取选中的第一个 B 站分集的字幕 → 调大模型整理 → 可插入到文本框 */
  const nfAiBtn=$s('#nfAi');
  if(nfAiBtn)nfAiBtn.onclick=async()=>{
    const biliEp=[...epSel].map(id=>S.episodes.find(e=>e.id===id)).find(e=>isBiliEpisode(e));
    if(!biliEp){toast('请先选择一个 B 站分集','err');return;}
    nfAiBtn.disabled=true;const oldHtml=nfAiBtn.innerHTML;nfAiBtn.innerHTML='生成中…';
    const res=await aiGenerateNotes(biliEp);
    nfAiBtn.disabled=false;nfAiBtn.innerHTML=oldHtml;
    if(!res.ok){toast(res.error,'err');return;}
    showAiResult('AI 笔记 · '+esc(biliEp.title||''), res.notes||'', (text)=>{
      const ta=/** @type {any} */ ($s('#nfText'));
      ta.value = ta.value ? (ta.value+'\n\n'+text) : text;
      ta.dispatchEvent(new Event('input'));
    });
  };
  /* 附件 */
  const attIds=attsOfNote(note.id).map(a=>a.id);
  /** @param {any} files */
  async function addFiles(files){
    for(const f of files){
      const id=uid();
      await dbPut('blobs',{id,blob:f});
      const att={id,noteId:note.id,name:f.name,type:f.type||'application/octet-stream',size:f.size,createdAt:Date.now()};
      await dbPut('attachments',att);S.attachments.push(att);attIds.push(id);
    }
    drawAtts();
  }
  /** @param {string} id */
  async function removeAtt(id){
    await dbDel('blobs',id);await dbDel('attachments',id);
    const i=S.attachments.findIndex(a=>a.id===id);if(i>=0)S.attachments.splice(i,1);
    const j=attIds.indexOf(id);if(j>=0)attIds.splice(j,1);drawAtts();
  }
  function drawAtts(){
    /* 用 any 让 tsc 认定 a 一定存在（上面已 filter(Boolean)）：
       否则 a.type / a.name 这一串都是 "possibly undefined"。 */
    const list=/** @type {any[]} */ (attIds.map(id=>S.attachments.find(a=>a.id===id)).filter(Boolean));
    $s('#nfAtts').innerHTML=list.map((/** @type {any} */ a)=>{
      const isImg=(a.type||'').startsWith('image/');
      return '<div class="att-list-row" data-id="'+a.id+'"><div class="att-thumb">'+(isImg?I('image'):I('file'))+'</div>'+
        '<div class="att-main"><div class="att-name">'+esc(a.name)+'</div><div class="att-size">'+fmtSize(a.size)+'</div></div>'+
        '<button class="icon-btn" data-open title="预览/下载">'+I('eye')+'</button><button class="icon-btn danger" data-del title="移除">'+I('trash')+'</button></div>';
    }).join('');
    $s('#nfAtts').querySelectorAll('.att-list-row').forEach((/** @type {any} */ r)=>{
      r.querySelector('[data-open]').onclick=()=>openAttachment(/** @type {any} */ (S.attachments.find(a=>a.id===r.dataset.id)));
      r.querySelector('[data-del]').onclick=()=>removeAtt(r.dataset.id);
    });
  }
  drawAtts();
  const dz=$s('#nfDrop');
  dz.onclick=()=>{const inp=document.createElement('input');inp.type='file';inp.multiple=true;inp.onchange=()=>addFiles([...(/** @type {any} */ (inp.files)||[])]);inp.click();};
  ['dragover','dragenter'].forEach(ev=>dz.addEventListener(ev,(/** @type {any} */ e)=>{e.preventDefault();dz.classList.add('drag');}));
  ['dragleave','drop'].forEach(ev=>dz.addEventListener(ev,(/** @type {any} */ e)=>{e.preventDefault();dz.classList.remove('drag');}));
  dz.addEventListener('drop',(/** @type {any} */ e)=>addFiles([...e.dataTransfer.files]));

  const foot=document.createDocumentFragment();
  let delBtn;
  if(!isNew){delBtn=el('button','btn btn-danger',I('trash')+' 删除');delBtn.type='button';delBtn.style.marginRight='auto';foot.appendChild(delBtn);}
  const cancel=el('button','btn','取消');cancel.type='button';
  const ok=el('button','btn btn-primary',I('save')+' 保存笔记');ok.type='button';
  foot.append(cancel,ok);
  const md=openModal({title:isNew?'新建笔记':'编辑笔记',body:wrap,footer:foot,wide:true});
  cancel.onclick=async()=>{if(isNew){for(const id of attIds){await dbDel('blobs',id);await dbDel('attachments',id);}}md.close();};
  ok.onclick=async()=>{
    if(!note.courseId){toast('请先创建一门课程','err');return;}
    note.title=$s('#nfTitle').value.trim();note.text=$s('#nfText').value;note.epIds=[...epSel];
    note.updatedAt=Date.now();
    if(!note.title&&!note.text.trim()&&!attIds.length){toast('笔记内容为空','err');return;}
    if(!note.title)note.title=(note.text.split('\n')[0].slice(0,24))||'无标题笔记';
    await dbPut('notes',note);
    const i=S.notes.findIndex(n=>n.id===note.id);
    if(i>=0)S.notes[i]=note;else S.notes.push(note);
    S.notes.sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0));
    md.close();
    /* _player 由 player.js 注入；没注入时（例如只加载了表单模块）跳过刷新，别抛异常。
       这里原来是 Player.renderNotes(...) —— 拆分后 forms.js 里没有 Player 这个符号，
       打包成单作用域时它会变成"自由变量"而侥幸指到 player.js 的 const Player，
       真实 ESM 下则会抛 ReferenceError。 */
    if(_player&&_player.epId&&notesOfEp(_player.epId).some(n=>Array.isArray(n.epIds)&&n.epIds.includes(_player.epId))){const ep=S.episodes.find(x=>x.id===_player.epId);_player.renderNotes(ep);}
    render();toast('笔记已保存','ok');
  };
  if(delBtn)delBtn.onclick=async()=>{
    const okd=await confirmDialog('删除笔记','确定删除这条笔记及其全部附件吗？','删除');if(!okd)return;
    for(const id of attIds){await dbDel('blobs',id);await dbDel('attachments',id);}
    await dbDel('notes',note.id);await loadAll();md.close();render();toast('已删除','ok');
  };
}


export { bindPlayer, batchEpisodeForm, courseForm, enableEpDrag, episodeForm, noteForm };
