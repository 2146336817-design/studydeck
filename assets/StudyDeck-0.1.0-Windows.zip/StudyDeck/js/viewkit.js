import { I } from './icons.js';
import { S, courseOf } from './db.js';
import { openModal } from './ui.js';
import { $, el, esc } from './core.js';

const NAV_DEFS=[
  {name:'dashboard',icon:'home',label:'概览'},
  {name:'courses',icon:'book',label:'课程'},
  {name:'notes',icon:'note',label:'笔记'},
  {name:'mistakes',icon:'target',label:'错题'},
  {name:'tasks',icon:'calendar',label:'任务'},
  {name:'stats',icon:'chart',label:'统计'},
  {name:'resources',icon:'folder',label:'资料库'},
  {name:'history',icon:'clock',label:'历史'},
  {sep:true},
  {name:'settings',icon:'cog',label:'设置'}
];

function renderNav(){
  const nav=$('#nav'); nav.innerHTML='';
  NAV_DEFS.forEach(d=>{
    if(d.sep){nav.appendChild(el('div','nav-sep'));return;}
    const it=el('div','nav-item'+(S.route.name===d.name||(d.name==='courses'&&S.route.name==='course')?' active':''),I(/** @type {any} */ (d).icon)+'<span>'+d.label+'</span>');
    it.onclick=()=>{location.hash='#/'+d.name; $('#sidebar').classList.remove('open');};
    nav.appendChild(it);
  });
}

function parseRoute(){
  const h=location.hash.replace(/^#\/?/,'');
  const parts=h.split('/');
  if(!parts[0]||parts[0]==='dashboard') return {name:'dashboard'};
  if(parts[0]==='courses') return {name:'courses'};
  if(parts[0]==='course'&&parts[1]) return {name:'course',id:parts[1],play:parts[2]==='play'?parts[3]:null};
  if(parts[0]==='notes') return {name:'notes',note:parts[1]};
  if(parts[0]==='mistakes') return {name:'mistakes',mId:parts[1]||null};
  if(parts[0]==='tasks') return {name:'tasks'};
  if(parts[0]==='stats') return {name:'stats'};
  if(parts[0]==='resources') return {name:'resources',rId:parts[1]||null};
  if(parts[0]==='history') return {name:'history'};
  if(parts[0]==='settings') return {name:'settings'};
  if(parts[0]==='search'&&parts[1]) return {name:'search',q:decodeURIComponent(parts.slice(1).join('/'))};
  return {name:'dashboard'};
}

const ROUTE_TITLE={dashboard:'概览',courses:'课程',notes:'笔记',mistakes:'错题本',tasks:'任务',stats:'统计',resources:'资料库',history:'历史',settings:'设置',search:'搜索'};

function render(){
  S.route=/** @type {any} */ (parseRoute()); renderNav();
  const mt=$('#mTitle'); if(mt)mt.textContent=S.route.name==='course'?('课程 · '+(courseOf(String(S.route.id||''))?.name||'')):(/** @type {Record<string,string>} */ (ROUTE_TITLE))[S.route.name]||'概览';
  const gs=$('#gSearch'); if(gs){
    gs.value=S.route.name==='search'?(S.route.q||''):'';
    gs.onkeydown=(/** @type {any} */ e)=>{if(e.key==='Enter'){const v=gs.value.trim();if(v)location.hash='#/search/'+encodeURIComponent(v);}};
  }
  const main=$('#main'); main.scrollTop=0;
  main.innerHTML='<div class="view" id="viewRoot"></div>';
  const root=$('#viewRoot');
  /* 视图表由 views-dispatch.js 注册进来；直接引用视图模块会形成循环依赖 */
  (appViews[S.route.name]||appViews.dashboard||(()=>{}))(root);
}
window.addEventListener('hashchange',render);

function applyTheme(){
  let t=S.settings.theme;
  if(t==='auto') t=matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light';
  /* 只放行白名单值：`String(t||'light')` 会把任意值（对象 → "[object Object]"、
     畸形字符串 → 原样）写进 data-theme 属性，等于让 settings 里的值逃逸进 DOM。
     导入侧已经在白名单化 theme，这里再收一道（纵深防御），非白名单一律回落 light。 */
  if(t!=='dark'&&t!=='light') t='light';
  document.documentElement.setAttribute('data-theme',t);
}
matchMedia('(prefers-color-scheme: dark)').addEventListener('change',()=>{if(S.settings.theme==='auto')applyTheme();});

/* 通用：视图头部 */

/* 路由名 → 视图函数。由 views-dispatch.js 注册，避免 viewkit 反向依赖视图模块。 */
/** 视图注册表：按路由名存视图函数。用 Record 而不是 {}，
 *  否则 appViews[S.route.name] 会报「不能用 string 索引 {}」（TS7053）。
 *  @type {Record<string, (root:any)=>void>} */
const appViews={};
/** @param {Record<string, (root:any)=>void>} map */
function registerViews(map){ Object.assign(appViews,map); }

/** @param {string} title @param {string} desc @param {string} [actionsHtml] @returns {string} */
function viewHead(title, desc, actionsHtml){
  return '<div class="view-head"><div><div class="view-title">'+esc(title)+'</div>'+
    (desc?'<div class="view-desc">'+desc+'</div>':'')+'</div><div class="view-actions">'+(actionsHtml||'')+'</div></div>';
}

/* 单行文本输入弹窗（返回 Promise：确定给字符串，取消给 null）。
   注意：目前没有其他模块用到它，所以 generate.mjs 不会把它写进 export 块 ——
   这是「暂时没用上的现成能力」，不是坏代码。等真有模块引用它时，导出会自动出现。 */
/** @param {string} title @param {string} label @param {string} [def] @returns {Promise<string|null>} */
function promptText(title,label,def){
  return new Promise(res=>{
    const body='<div class="field"><label>'+esc(label)+'</label><input id="ptInput" class="input" value="'+esc(def||'')+'"></div>';
    const foot=document.createDocumentFragment();
    const cancel=el('button','btn','取消'); const ok=el('button','btn btn-primary','确定');
    foot.append(cancel,ok);
    const md=openModal({title,body,footer:foot,dismissable:true});
    cancel.onclick=()=>{md.close();res(null);};
    ok.onclick=()=>{const v=md.body.querySelector('#ptInput').value;md.close();res(v);};
    setTimeout(()=>{const i=md.body.querySelector('#ptInput');if(i){i.focus();i.select();}},60);
  });
}


export { applyTheme, registerViews, render, viewHead };
