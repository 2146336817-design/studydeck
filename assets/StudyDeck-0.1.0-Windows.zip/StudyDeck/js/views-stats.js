// @ts-check
// 统计与搜索视图。
// （从 views-task.js 拆出。）
import { I } from './icons.js';
import { S, courseOf, learnedBetween } from './db.js';
import { courseSec, dateKey, epNumberOf, esc, fmtDateTime, fmtDur, fmtDurShort, fmtSize, safeColor } from './util.js';
import { viewHead } from './viewkit.js';
import { bars30, heatmap, manualLogForm, statCard } from './views-home.js';

/** main 用 any 而不是 HTMLElement：本文件在 DOM 上用的是裸 querySelector，
 *  标成 HTMLElement 会让 main.querySelector(...) 返回 Element|null（无 .onclick/.dataset），
 *  反而多出一批错误。要标就得连 DOM 取值一起换成 core.js 的 $ / $$。
 *  @param {any} main */
function viewSearch(main){
  const q=(S.route.q||'').trim(), ql=q.toLowerCase();
  main.innerHTML=viewHead('搜索'+(q?' · '+esc(q):''),'跨视频 / 资料 / 错题 / 笔记搜索')+'<div id="srRoot"></div>';
  const root=main.querySelector('#srRoot');
  if(!ql){root.innerHTML='<div class="empty">'+I('search')+'<div class="empty-title">在左侧搜索框输入关键词</div></div>';return;}
  /** @param {any} s */
  const hit=s=>((s||'').toLowerCase()).includes(ql);
  /** @param {any} cid */
  const cname=cid=>(courseOf(cid)||{}).name||'';
  const vids=S.episodes.filter(e=>hit(e.title)||hit(cname(e.courseId)));
  const ress=S.resources.filter(r=>r.kind!=='folder'&&hit(r.name));
  const mks=S.mistakes.filter(m=>hit(m.subject)||hit(m.chapter)||hit(m.stem));
  const nts=S.notes.filter(n=>hit(n.title)||hit(n.text));
  const total=vids.length+ress.length+mks.length+nts.length;
  if(!total){root.innerHTML='<div class="empty">'+I('search')+'<div class="empty-title">没有找到与「'+esc(q)+'」相关的内容</div></div>';return;}
  /** @param {string} title @param {string} color @param {any[]} arr @param {(x:any)=>string} fmt @returns {string} */
  const block=(title,color,arr,fmt)=>!arr.length?'':
    '<div style="margin:14px 0 8px;font-weight:650;display:flex;align-items:center;gap:8px"><span style="width:8px;height:8px;border-radius:2px;background:'+color+'"></span>'+title+'<span class="small muted">'+arr.length+'</span></div>'+arr.map(fmt).join('');
  root.innerHTML=block('视频','#0f6b54',vids,(/** @type {any} */ e)=>'<div class="card" style="display:flex;align-items:center;gap:12px;padding:12px 16px;margin-bottom:8px;cursor:pointer" data-hash="'+e.courseId+'" data-ep="'+e.id+'">'+
      '<span class="pill">'+esc(cname(e.courseId)||'课程')+'</span><div class="ellipsis" style="flex:1;font-weight:600">'+esc(e.title)+'</div><span class="tiny dim">第 '+epNumberOf(e)+' 集</span></div>')+
    block('资料','#a86b2d',ress,(/** @type {any} */ r)=>'<div class="card" style="display:flex;align-items:center;gap:12px;padding:12px 16px;margin-bottom:8px;cursor:pointer" data-hash="resources">'+
      '<span class="pill">'+esc(r.type||'资料')+'</span><div class="ellipsis" style="flex:1;font-weight:600">'+esc(r.name)+'</div><span class="tiny dim">'+fmtSize(r.size||0)+'</span></div>')+
    block('错题','#b3412f',mks,(/** @type {any} */ m)=>'<div class="card" style="display:flex;align-items:center;gap:12px;padding:12px 16px;margin-bottom:8px;cursor:pointer" data-hash="mistakes">'+
      '<span class="pill">'+esc(m.subject||'错题')+'</span><div class="ellipsis" style="flex:1;font-weight:600">'+esc((m.stem||'').slice(0,60)||'（无题干）')+'</div></div>')+
    block('笔记','#2f5d8a',nts,(/** @type {any} */ n)=>'<div class="card" style="display:flex;align-items:center;gap:12px;padding:12px 16px;margin-bottom:8px;cursor:pointer" data-hash="notes">'+
      '<div class="ellipsis" style="flex:1;font-weight:600">'+esc(n.title||'无标题笔记')+'</div><span class="tiny dim">'+esc(cname(n.courseId)||'')+'</span></div>');
  root.querySelectorAll('[data-hash]').forEach((/** @type {any} */ c)=>c.onclick=()=>{
    const h=c.dataset.hash;
    if(h==='resources'||h==='mistakes'||h==='notes')location.hash='#/'+h;
    else location.hash='#/course/'+h+(c.dataset.ep?'/play/'+c.dataset.ep:'');
  });
}

/** @param {any} main */
function viewStats(main){
  const totalSec=S.sessions.reduce((s,x)=>s+x.sec,0);
  const done=S.episodes.filter(e=>e.status===2).length;
  const weekSec=learnedBetween(Date.now()-7*864e5,Date.now());
  const avgSec=Math.round(totalSec/Math.max(1,new Set(S.sessions.map(s=>dateKey(s.end||s.start))).size));
  // 课程分布
  const dist=S.courses.map(c=>({c,sec:courseSec(c.id)})).filter(x=>x.sec>0).sort((a,b)=>b.sec-a.sec);
  const distMax=Math.max(...dist.map(x=>x.sec),1);
  // 星期分布
  const wd=[0,0,0,0,0,0,0];S.sessions.forEach(s=>{wd[new Date(s.end||s.start).getDay()]+=s.sec;});
  const wdMax=Math.max(...wd,1);
  const wdName=['日','一','二','三','四','五','六'];
  main.innerHTML=
    viewHead('学习统计','所有时长来自播放器计时与手动补记',
      '<button class="btn" id="manualLog">'+I('clock')+' 补记时长</button>')+
    '<div class="stat-row">'+
      statCard('clock','累计学习',fmtDur(totalSec),'共 '+S.sessions.length+' 次')+
      statCard('flame','近 7 天',fmtDur(weekSec),'日均 '+fmtDur(Math.round(weekSec/7)))+
      statCard('check','完成分集',done+'<span class="stat-unit">/ '+S.episodes.length+'</span>','笔记 '+S.notes.length+' 篇')+
    '</div>'+
    '<div class="card card-pad" style="margin-bottom:14px"><div class="section-title">'+I('calendar')+' 学习热力（近 12 周，颜色越深学得越久）</div>'+
      heatmap(12)+
      '<div style="display:flex;gap:5px;align-items:center;margin-top:10px;font-size:11px;color:var(--text-3)"><span>少</span><span class="heat"></span><span class="heat l1"></span><span class="heat l2"></span><span class="heat l3"></span><span class="heat l4"></span><span>多</span><span style="margin-left:14px">学习日平均 '+fmtDur(avgSec)+'</span></div></div>'+
    '<div class="dash-grid"><div class="card card-pad"><div class="section-title">'+I('chart')+' 近 30 天趋势</div>'+bars30()+'</div>'+
      '<div class="card card-pad"><div class="section-title">'+I('layers')+' 课程时长分布</div><div id="distBox"></div></div></div>'+
    '<div class="dash-grid" style="margin-top:14px"><div class="card card-pad"><div class="section-title">'+I('calendar')+' 星期分布</div>'+
      '<div style="display:flex;align-items:flex-end;gap:10px;height:140px;padding:10px 4px 0">'+
        wd.map((v,i)=>'<div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:6px;height:100%;justify-content:flex-end">'+
          '<span class="tiny dim">'+fmtDurShort(v)+'</span><div style="width:100%;max-width:34px;height:'+Math.max(2,v/wdMax*100)+'%;background:var(--accent);border-radius:4px 4px 0;opacity:.85"></div><span class="tiny dim">周'+wdName[i]+'</span></div>').join('')+'</div></div>'+
      '<div class="card card-pad"><div class="section-title">'+I('clock')+' 最近学习记录</div><div id="sessBox" style="max-height:280px;overflow-y:auto"></div></div></div>';
  main.querySelector('#manualLog').onclick=manualLogForm;
  const db=main.querySelector('#distBox');
  db.innerHTML=dist.length?dist.map(x=>
    '<div class="dist-row"><span class="dist-name">'+esc(x.c.name)+'</span><div class="dist-track"><div class="dist-fill" style="width:'+Math.round(x.sec/distMax*100)+'%;background:'+safeColor(x.c.color)+'"></div></div><span class="dist-val">'+fmtDurShort(x.sec)+'</span></div>').join('')
    :'<div class="small dim">暂无学习记录</div>';
  const sb=main.querySelector('#sessBox');
  const recent=S.sessions.slice(0,30);
  sb.innerHTML=recent.length?recent.map(s=>{const c=courseOf(String(s.courseId||'')),ep=S.episodes.find(e=>e.id===s.epId);
    return '<div class="sess-row"><span class="sess-time">'+fmtDateTime(s.end||s.start)+'</span><div class="sess-main ellipsis">'+esc(c?c.name:'未知课程')+(ep?' · '+esc(ep.title):'')+'</div>'+
      '<span class="badge '+(s.kind==='manual'?'badge-todo':'badge-done')+'">'+(s.kind==='manual'?'补记':'计时')+'</span><span class="sess-sec">'+fmtDurShort(s.sec)+'</span></div>';}).join('')
    :'<div class="small dim">还没有学习记录，打开播放器开始计时吧</div>';
}

/* ================================================================
 * 设置 / 备份 / 初始化
 * ================================================================ */


export { viewSearch, viewStats };
