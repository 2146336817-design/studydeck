import { I } from './icons.js';
import { S, saveSettings } from './db.js';
import { confirmDialog, scanSession, toast } from './ui.js';
import { $, esc, fmtSize, renderStorageInfo } from './util.js';
import { applyTheme, registerViews, render, viewHead } from './viewkit.js';
import { viewCourseDetail } from './player.js';
import { bindCloudBackup, cloudBackupCard, exportData, importData, wipeAll } from './settings-backup.js';
import { viewCourses } from './views-course.js';
import { viewMistakes, viewNotes } from './views-note.js';
import { viewHistory, viewResources, viewSearch, viewStats, viewTasks } from './views-task.js';
import { viewDashboard } from './views-home.js';
import { aiTestConnection } from './ai.js';

/** @param {string} name @param {string} desc @param {string} controlHtml @returns {string} */
function switchRow(name,desc,controlHtml){
  return '<div class="set-row"><div><div class="set-name">'+name+'</div><div class="set-desc">'+desc+'</div></div><div>'+controlHtml+'</div></div>';
}

/* 注意：这里**不要**给 main 标 HTMLElement。
   标了之后 main.querySelector 会返回 Element|null（没有 .onclick/.dataset/.value），
   这个模块立刻从 6 个错误涨到 44 个 —— 本文件在 DOM 上用的是裸 querySelector，
   标注参数等于把整片 DOM 代码变成待修的错误，收益是负的。
   要标就得连同整个 DOM 取值一起改成 core.js 的 $ / $$（见 views-note.js 的说明）。 */
/** @param {any} main */
function viewSettings(main){
  const counts='课程 '+S.courses.length+' · 分集 '+S.episodes.length+' · 笔记 '+S.notes.length+' · 错题 '+S.mistakes.length+' · 任务/目标 '+S.tasks.length+' · 附件 '+S.attachments.length+' · 学习记录 '+S.sessions.length;
  main.innerHTML=
    viewHead('设置','数据全部保存在本机浏览器（IndexedDB），不上传云端')+
    '<div class="card card-pad" style="margin-bottom:14px"><div class="section-title">偏好</div>'+
      switchRow('外观主题','切换浅色 / 深色，或跟随系统',
        '<div class="theme-sw">'+[['light','浅色'],['dark','深色'],['auto','跟随系统']].map(([k,v])=>'<button class="theme-opt '+(S.settings.theme===k?'on':'')+'" data-theme="'+k+'">'+v+'</button>').join('')+'</div>')+
      /* dailyGoal 必须是数字再拼进属性：原来直接拼裸值，一个 `"><img onerror=...>`
         就能从 settings 逃逸并自动执行（邻居 setCountDate/sessdata 都过了 esc()，这里是漏的）。
         用 Number.isFinite 收口比 esc() 更彻底 —— 数字类型下没有可注入的字符。 */
      switchRow('每日学习目标','概览页目标环按此计算','<div style="display:flex;align-items:center;gap:6px"><input class="input" id="setGoal" type="number" min="5" step="5" value="'+(Number.isFinite(Number(S.settings.dailyGoal))?Number(S.settings.dailyGoal):60)+'" style="width:90px"><span class="small muted">分钟 / 天</span></div>')+
      switchRow('概览倒计时','显示距考试日期的倒计时卡片（留空为高考 6 月 7 日）','<div style="display:flex;align-items:center;gap:6px"><div class="switch '+(S.settings.showCountdown?'on':'')+'" id="swCount"></div><input class="input" id="setCountDate" placeholder="如 2026-12-25" value="'+esc(S.settings.countdownDate||'')+'" style="width:150px"></div>')+
      switchRow('本地视频自动计时','本地视频播放时自动开始计时，暂停时自动结算','<div class="switch '+(S.settings.autoLocal?'on':'')+'" id="swAuto"></div>')+
      switchRow('自动连播下一集','当前分集播放结束后，自动打开同一课程的下一集','<div class="switch '+(S.settings.autoNext?'on':'')+'" id="swNext"></div>')+
      switchRow('B 站播放方式','智能高清：本地服务在线时应用内直连 1080P，离线自动回退内嵌；高清直连：始终走本地服务；应用内嵌：不切窗口但通常仅 480P；新标签高清：跳到 B 站站内播放',
        '<div class="theme-sw">'+[['auto','智能高清'],['direct','高清直连'],['embed','应用内嵌'],['external','新标签高清']].map(k=>'<button class="theme-opt '+(S.settings.biliMode===k[0]?'on':'')+'" data-bm="'+k[0]+'">'+k[1]+'</button>').join('')+'</div>')+
    '</div>'+
    '<div class="card card-pad" style="margin-bottom:14px"><div class="section-title">本地媒体库 <span class="tiny" style="font-weight:400">MKV / AVI 自动转码播放</span></div>'+
      '<p class="small muted" style="margin-bottom:10px">指定一个存放网课视频的文件夹（如 <code>D:\\网课视频</code>），应用可直接读取其中的视频。浏览器原生支持的格式（MP4/WebM）直接播放；不支持的格式（MKV/AVI/FLV/WMV 等）会自动用 <b>ffmpeg 实时转码</b>为可播放格式。视频文件不会被复制或上传。</p>'+
      '<div style="display:flex;gap:7px;align-items:center;flex-wrap:wrap"><input class="input" id="mediaLibPath" placeholder="粘贴视频文件夹的完整路径，如 D:\\网课视频" style="flex:1;min-width:240px"><button class="btn btn-primary" id="mediaLibSave">保存</button><button class="btn" id="mediaLibClear">清除</button></div>'+
      '<div class="tiny" id="mediaLibState" style="margin-top:8px">正在读取配置…</div></div>'+
    '<div class="card card-pad" style="margin-bottom:14px"><div class="section-title">B 站高清直连服务 <span class="tiny" style="font-weight:400">应用内 1080P，不跳站</span></div>'+
      '<div class="set-row" style="border-top:none;padding-top:6px"><div><div class="set-name">本地服务状态</div><div class="set-desc">'+
        (S.proxy?'<span style="color:#0f6b54;font-weight:650">运行中，高清直连已就绪</span>':'未运行。关闭本页后双击同目录的「启动课业（B站高清）.bat」，从自动打开的 127.0.0.1 页面进入即可；该服务只负责向 B 站取播放地址，视频流仍由浏览器直连 B 站官方 CDN')+
      '</div></div><div><span class="pill '+(S.proxy?'pill-ok':'pill-off')+'">'+(S.proxy?'在线':'离线')+'</span></div></div>'+
      '<div class="set-row"><div><div class="set-name">登录凭证 SESSDATA <span class="tiny">看 1080P 必填</span></div><div class="set-desc">B 站对游客限制最高 720P，填写后解锁 1080P（大会员可达 1080P+/4K）。获取：浏览器登录 bilibili.com 后按 F12 → 应用(Application) → Cookie → 复制 SESSDATA 的值。<b>保存后会存在两处：本页所在的浏览器 IndexedDB，以及程序目录下的明文文件 sessdata.txt</b>（扫码登录时自动写入）。它等同于你的 B 站登录态，只随请求发往 B 站官方接口，<b>不会进入备份导出</b>；但请不要把这个程序目录放进网盘同步、也不要连文件夹一起分享，分享前先点右侧「删除本地凭证文件」。</div></div>'+
      '<div style="display:flex;gap:7px;flex-wrap:wrap;align-items:center"><input class="input" id="setSess" type="password" placeholder="粘贴 SESSDATA" value="'+esc(S.settings.sessdata||'')+'" style="width:210px"><button class="btn btn-primary" id="saveSess">保存</button><button class="btn" id="verifySess">验证登录态</button><button class="btn" id="scanSess">扫码获取</button><button class="btn btn-danger" id="delSessFile" title="删除程序目录下的 sessdata.txt">删除本地凭证文件</button><span class="tiny" id="sessState"></span></div></div>'+
      '<div class="tiny dim" style="line-height:1.75;border-top:1px solid var(--border);padding-top:10px">注意：127.0.0.1 服务页面与直接双击打开的 html 是两个独立存储空间，首次切换时用下方「备份与迁移」导出再导入一次即可。</div></div>'+
    '<div class="card card-pad" style="margin-bottom:14px"><div class="section-title">AI 助手 <span class="tiny" style="font-weight:400">自动笔记 · 错题解析</span></div>'+
      '<div class="set-row" style="border-top:none;padding-top:6px"><div><div class="set-name">API Key <span class="tiny">必填</span></div><div class="set-desc">大模型服务商的 API Key，默认 DeepSeek（中文好、约 1 元/百万 tokens）。兼容任何 OpenAI 格式接口（智谱 / 月之暗面 / 本地 Ollama 等）。<b>Key 只存在本机 IndexedDB，不进入备份导出</b>。</div></div>'+
      '<div style="display:flex;gap:7px;align-items:center;flex-wrap:wrap"><input class="input" id="aiKey" type="password" placeholder="sk-..." value="'+esc(S.settings.aiApiKey||'')+'" style="width:240px"><button class="btn btn-primary" id="aiSave">保存</button><button class="btn" id="aiTest">测试连接</button><span class="tiny" id="aiState"></span></div></div>'+
      '<div class="set-row"><div><div class="set-name">接口地址</div><div class="set-desc">API 根地址，默认 DeepSeek。用其他服务商时改成对应地址（如 Ollama 填 http://localhost:11434/v1）。</div></div>'+
      '<input class="input" id="aiBase" placeholder="https://api.deepseek.com" value="'+esc(S.settings.aiBaseUrl||'https://api.deepseek.com')+'" style="width:280px"></div>'+
      '<div class="set-row"><div><div class="set-name">模型名</div><div class="set-desc">要调用的模型，默认 deepseek-chat。</div></div>'+
      '<input class="input" id="aiModel" placeholder="deepseek-chat" value="'+esc(S.settings.aiModel||'deepseek-chat')+'" style="width:200px"></div>'+
      '<div class="set-row"><div><div class="set-name">AI 笔记提示词（可选）</div><div class="set-desc">自定义 AI 整理笔记时的系统提示词，留空使用默认提示词（结构化 Markdown 笔记 + 要点总结）。</div></div>'+
      '<textarea class="textarea" id="aiPrompt" style="min-height:70px;font-size:13px" placeholder="留空使用默认提示词">'+esc(S.settings.aiNotesPrompt||'')+'</textarea></div>'+
    cloudBackupCard()+
    '<div class="card card-pad" style="margin-bottom:14px"><div class="section-title">备份与迁移</div>'+
      '<p class="small muted" style="margin-bottom:12px"><b>导出的是「元数据备份」</b>：课程、分集、笔记正文、错题、任务、学习记录，以及附件的名称/大小/类型清单。<b>它不含附件文件本身</b>（v3 起附件走独立二进制通道，不再 Base64 内嵌）。本地视频同理，只记录文件名与引用。附件请靠下面两条路保存并在换机时一并带走：<b>自动云备份</b>（选一个网盘同步文件夹）或程序目录下的 <b>_autobackup/</b>。重装浏览器前务必备份。</p>'+
      '<div style="display:flex;gap:9px;flex-wrap:wrap"><button class="btn btn-primary" id="expBtn">'+I('download')+' 导出全部数据</button><button class="btn" id="impBtn">'+I('upload')+' 导入备份</button></div>'+
      '<div class="tiny dim" id="backupInfo" style="margin-top:10px">当前：'+counts+'，附件总大小 '+fmtSize(S.attachments.reduce((s,a)=>s+(a.size||0),0))+'</div>'+
      '<div class="tiny dim" id="storageInfo" style="margin-top:6px">正在读取本机存储占用…</div></div>'+
    '<div class="card card-pad" style="margin-bottom:14px"><div class="section-title">快捷键（播放器内）</div>'+
      '<div class="small muted" style="line-height:2">空格：开始 / 暂停计时　·　← →：切换上 / 下一集　·　Esc：关闭播放器<br>B 站高清请启动本地服务并选择「智能高清」；本地视频推荐使用 Edge / Chrome 以记住文件位置。</div></div>'+
    '<div class="card card-pad"><div class="section-title" style="color:var(--danger)">危险操作</div>'+
      '<button class="btn btn-danger" id="wipeBtn">'+I('trash')+' 清空全部数据</button></div>';
  main.querySelectorAll('.theme-opt').forEach((/** @type {any} */ b)=>b.onclick=async()=>{S.settings.theme=b.dataset.theme;await saveSettings();applyTheme();render();});
  const goal=main.querySelector('#setGoal');
  goal.onchange=async()=>{const v=+goal.value;if(v>=5){S.settings.dailyGoal=v;await saveSettings();toast('已保存','ok');}};
  main.querySelector('#swAuto').onclick=async function(){S.settings.autoLocal=!S.settings.autoLocal;this.classList.toggle('on',S.settings.autoLocal);await saveSettings();};
  const swCount=main.querySelector('#swCount');
  if(swCount)swCount.onclick=async function(){S.settings.showCountdown=!S.settings.showCountdown;this.classList.toggle('on',S.settings.showCountdown);await saveSettings();render();};
  const cd=main.querySelector('#setCountDate');
  if(cd)cd.onchange=async()=>{const v=cd.value.trim();S.settings.countdownDate=/^\d{4}-\d{1,2}-\d{1,2}$/.test(v)?v:'';await saveSettings();toast(S.settings.countdownDate?'已保存倒计时日期':'已清空（使用默认高考日期）','ok');};
  const swNext=main.querySelector('#swNext');
  if(swNext)swNext.onclick=async function(){S.settings.autoNext=!S.settings.autoNext;this.classList.toggle('on',S.settings.autoNext);await saveSettings();};
  main.querySelectorAll('[data-bm]').forEach((/** @type {any} */ b)=>b.onclick=async()=>{S.settings.biliMode=b.dataset.bm;await saveSettings();render();toast('已切换 B 站播放方式','ok');});
  const scBtn=main.querySelector('#scanSess'); if(scBtn)scBtn.onclick=scanSession;
  const dfBtn=main.querySelector('#delSessFile');
  if(dfBtn)dfBtn.onclick=async()=>{
    if(!S.proxy){toast('只有在用「启动课业（B站高清）.bat」打开时，才能删除程序目录里的 sessdata.txt','err');return;}
    const ok=await confirmDialog('删除本地凭证文件','将删除程序目录下的 sessdata.txt（B 站登录凭证的明文副本）。\n\n删除后本页保存的凭证仍可继续使用；如果连浏览器里那一份也要清掉，删完后把输入框清空再点「保存」。\n\n（这个操作只删凭证文件，不会动你的本地自动备份。）\n\n确定删除吗？','删除文件');
    if(!ok)return;
    try{
      /* 只删 sessdata.txt。注意别接到 /api/autobackup/delete —— 那会清空本地自动备份。 */
      const r=await fetch('/api/sessdata/delete',{method:'POST'});
      const j=await r.json();
      if(j&&j.code===0){
        S.serverSess=false;
        toast(j.deleted?'已删除程序目录下的 sessdata.txt':'程序目录下本来就没有 sessdata.txt','ok');
      }else toast('删除失败：'+((j&&j.message)||'未知错误'),'err');
    }catch(e){toast('删除失败：本地服务未运行','err');}
  };
  /* 本地媒体库配置 */
  const mlIn=/** @type {any} */ (main.querySelector('#mediaLibPath'));
  const mlState=main.querySelector('#mediaLibState');
  const mlSave=main.querySelector('#mediaLibSave');
  const mlClear=main.querySelector('#mediaLibClear');
  async function refreshMediaLib(){
    if(!S.proxy){if(mlState)mlState.innerHTML='<span style="color:var(--danger)">本地服务未运行</span>。请双击「启动课业（B站高清）.bat」后在此页面设置媒体库。';return;}
    try{
      const r=await fetch('/api/media/config');const j=await r.json();
      if(mlIn)mlIn.value=j.path||'';
      if(mlState){
        const ff=j.hasFfmpeg?'<span style="color:#0f6b54">ffmpeg 已就绪</span>':'<span style="color:var(--danger)">ffmpeg 未安装</span>（MKV/AVI 转码需要，下载后放入程序目录或系统 PATH）';
        mlState.innerHTML=(j.path?'当前媒体库：<b>'+esc(j.path)+'</b>　·　':'尚未设置媒体库目录　·　')+ff;
      }
    }catch(e){if(mlState)mlState.textContent='读取配置失败';}
  }
  if(mlSave)mlSave.onclick=async()=>{
    const p=(mlIn.value||'').trim();
    if(!p){toast('请输入目录路径','err');return;}
    try{
      const r=await fetch('/api/media/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({path:p})});
      const j=await r.json();
      if(j.code===0){toast('媒体库目录已保存','ok');refreshMediaLib();}
      else toast(j.message||'保存失败','err');
    }catch(e){toast('保存失败：本地服务未运行','err');}
  };
  if(mlClear)mlClear.onclick=async()=>{
    try{
      await fetch('/api/media/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({path:''})});
      if(mlIn)mlIn.value='';toast('已清除媒体库目录','ok');refreshMediaLib();
    }catch(e){toast('清除失败','err');}
  };
  refreshMediaLib();
  renderStorageInfo();
  const ssIn=main.querySelector('#setSess'),ssBtn=main.querySelector('#saveSess'),vsBtn=main.querySelector('#verifySess'),ssState=main.querySelector('#sessState');
  if(ssBtn)ssBtn.onclick=async()=>{S.settings.sessdata=(ssIn.value||'').trim();await saveSettings();toast('SESSDATA 已保存在本机','ok');if(ssState)ssState.textContent='';};
  if(vsBtn)vsBtn.onclick=async()=>{
    const v=(ssIn.value||'').trim(); if(v){S.settings.sessdata=v;await saveSettings();}
    if(!S.settings.sessdata){ssState.textContent='请先粘贴 SESSDATA';ssState.style.color='var(--danger)';return;}
    if(!S.proxy){ssState.textContent='请先双击 bat 启动本地高清服务';ssState.style.color='var(--danger)';return;}
    ssState.textContent='验证中…';ssState.style.color='var(--text-3)';
    try{
      const rr=await fetch('/api/bili/me',{headers:{'X-Sessdata':S.settings.sessdata||''}});
      const jj=await rr.json(),dd=jj.data||{};
      if(dd.isLogin){ssState.textContent='登录有效：'+dd.uname+(dd.vip?'（大会员）':'')+'，可看 1080P';ssState.style.color='#0f6b54';toast('登录态有效','ok');}
      else{ssState.textContent='凭证无效或已过期，请重新复制';ssState.style.color='var(--danger)';}
    }catch(e){ssState.textContent='验证失败：本地服务未运行';ssState.style.color='var(--danger)';}
  };
  if(ssState&&S.settings.sessdata&&S.proxy){(async()=>{try{
    const rr=await fetch('/api/bili/me',{headers:{'X-Sessdata':S.settings.sessdata||''}});
    const jj=await rr.json(),dd=jj.data||{};
    ssState.textContent=dd.isLogin?('登录有效：'+dd.uname+(dd.vip?'（大会员）':'')+'，可看 1080P'):'凭证无效或已过期，请重新复制';
    ssState.style.color=dd.isLogin?'#0f6b54':'var(--danger)';
  }catch(e){}})();}
  /* AI 助手设置 */
  const aiKeyIn=main.querySelector('#aiKey'),aiBaseIn=main.querySelector('#aiBase'),aiModelIn=main.querySelector('#aiModel'),aiPromptIn=main.querySelector('#aiPrompt');
  const aiSaveBtn=main.querySelector('#aiSave'),aiTestBtn=main.querySelector('#aiTest'),aiState=main.querySelector('#aiState');
  if(aiSaveBtn)aiSaveBtn.onclick=async()=>{
    S.settings.aiApiKey=(aiKeyIn.value||'').trim();
    S.settings.aiBaseUrl=(aiBaseIn.value||'').trim()||'https://api.deepseek.com';
    S.settings.aiModel=(aiModelIn.value||'').trim()||'deepseek-chat';
    S.settings.aiNotesPrompt=(aiPromptIn.value||'').trim();
    await saveSettings();toast('AI 配置已保存在本机','ok');if(aiState)aiState.textContent='';
  };
  if(aiTestBtn)aiTestBtn.onclick=async()=>{
    /* 测试前先保存当前输入，避免用户填了没保存就测 */
    S.settings.aiApiKey=(aiKeyIn.value||'').trim();
    S.settings.aiBaseUrl=(aiBaseIn.value||'').trim()||'https://api.deepseek.com';
    S.settings.aiModel=(aiModelIn.value||'').trim()||'deepseek-chat';
    await saveSettings();
    if(!S.settings.aiApiKey){aiState.textContent='请先填写 API Key';aiState.style.color='var(--danger)';return;}
    if(!S.proxy){aiState.textContent='请先双击 bat 启动本地服务';aiState.style.color='var(--danger)';return;}
    aiState.textContent='测试中…';aiState.style.color='var(--text-3)';
    const res=await aiTestConnection();
    aiState.textContent=res.ok?('连接正常：'+res.message):('连接失败：'+res.message);
    aiState.style.color=res.ok?'#0f6b54':'var(--danger)';
    if(res.ok)toast('AI 连接正常','ok');
  };
  bindCloudBackup(main);
  main.querySelector('#expBtn').onclick=exportData;
  main.querySelector('#impBtn').onclick=importData;
  main.querySelector('#wipeBtn').onclick=wipeAll;
}

/* 把「路由名 → 视图函数」注册给 viewkit 的分发器。放在文件末尾，此时视图函数都已定义。 */
registerViews({
  dashboard:viewDashboard, courses:viewCourses, course:viewCourseDetail, notes:viewNotes,
  mistakes:viewMistakes, tasks:viewTasks, stats:viewStats, resources:viewResources,
  history:viewHistory, settings:viewSettings, search:viewSearch
});