// @ts-check
// 桶文件：本文件已按职责拆成多个模块，这里只做**再导出**，保持对外 API 不变。
//   task-utils.js      共用小工具（日期 / 打卡 / 目标 / 链接编辑）
//   task-timetable.js  课表导入导出
//   views-tasks.js     任务与目标视图
//   views-resources.js 资料库
//   views-history.js   历史
//   views-stats.js     统计与搜索
// 调用方（views-dispatch.js / views-home.js）无需改动。

export { dayItems, logOn, repText, toggleDay } from './task-utils.js';
export { viewTasks } from './views-tasks.js';
export { viewResources } from './views-resources.js';
export { viewHistory } from './views-history.js';
export { viewSearch, viewStats } from './views-stats.js';
