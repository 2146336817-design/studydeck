// @ts-check
// 任务与目标模块的共用工具：日期、分类、打卡、目标进度、链接编辑。
// （从 views-task.js 拆出 —— 这些被任务/统计等多个视图共用。）
// 注意只 import 真正用到的符号：多出来的会让 tsc --noUnusedLocals 报警。
import { S, dbDel, dbPut, epsOf } from './db.js';
import { toast } from './ui.js';
import { dateKey, esc, pad2 } from './util.js';
import { Player, noteForm } from './player.js';
import { mistakeDetail } from './views-note.js';

const CAT_PAL=['#0f6b54','#2f5d8a','#a86b2d','#7c5cbf','#b3412f','#34506e','#7a8441','#945d76'];

function catColor(c){if(!c)return 'var(--text-3)';let h=0;for(const ch of c)h=(h*31+ch.charCodeAt(0))>>>0;return CAT_PAL[h%CAT_PAL.length];}

function catTag(c){if(!c)return '';const col=catColor(c);return '<span class="cat-tag" style="color:'+col+';background:'+col+'1f">'+esc(c)+'</span>';}

function taskCats(){const s=new Set(['学习','生活']);S.tasks.forEach(t=>t.cat&&s.add(t.cat));return [...s];}

function dkAdd(dk,n){const d=new Date(dk+'T00:00:00');d.setDate(d.getDate()+n);return dateKey(d.getTime());}

function dkWeekday(dk){return new Date(dk+'T00:00:00').getDay();}

function dkLabel(dk){const d=new Date(dk+'T00:00:00');return (d.getMonth()+1)+' 月 '+d.getDate()+' 日 · 周'+'日一二三四五六'[d.getDay()];}

function curMonthKey(){const d=new Date();return d.getFullYear()+'-'+pad2(d.getMonth()+1);}

function monthLabel(m){const [y,mo]=m.split('-');return y+' 年 '+mo+' 月';}

function monthDays(m){const [y,mo]=m.split('-').map(Number);const n=new Date(y,mo,0).getDate();return Array.from({length:n},(_,i)=>y+'-'+pad2(mo)+'-'+pad2(i+1));}

function weekStart(dk){const d=new Date(dk+'T00:00:00');let w=d.getDay();w=(w===0?6:w-1);d.setDate(d.getDate()-w);return dateKey(d.getTime());}

function weekOf(dk){const s=weekStart(dk);return Array.from({length:7},(_,i)=>dkAdd(s,i));}

const REP_LABEL={daily:'每天',weekdays:'工作日',weekly:'每周'};

function repText(t){if(t.kind!=='tpl')return '';if(t.repeat==='weekly'&&(t.weekdays||[]).length)return '每周 '+(t.weekdays||[]).map(w=>'日一二三四五六'[w]).join('·');return REP_LABEL[t.repeat]||'';}

function tplOn(t,dk){if(t.kind!=='tpl')return false;if(dk<t.date)return false;const w=dkWeekday(dk);
  if(t.repeat==='daily')return true;
  if(t.repeat==='weekdays')return w>=1&&w<=5;
  if(t.repeat==='weekly')return (t.weekdays||[]).includes(w);
  return false;}

const logKey=(tid,dk)=>tid+'@'+dk;

const logOn=(tid,dk)=>S.tasklog.some(l=>l.key===logKey(tid,dk));

function dayItems(dk){
  const arr=[];
  S.tasks.filter(t=>t.kind==='day'&&t.date===dk).forEach(t=>arr.push({t,done:!!t.done,tpl:false}));
  S.tasks.filter(t=>tplOn(t,dk)).forEach(t=>arr.push({t,done:logOn(t.id,dk),tpl:true}));
  arr.sort((a,b)=>{if(a.done!==b.done)return a.done?1:-1;
    const at=a.t.time||'',bt=b.t.time||'';
    if(at!==bt){if(!at)return 1;if(!bt)return -1;return at<bt?-1:1;}
    return (a.t.order||0)-(b.t.order||0);});
  return arr;
}

async function toggleDay(item,dk){
  if(item.tpl){const k=logKey(item.t.id,dk);const i=S.tasklog.findIndex(l=>l.key===k);
    if(i>=0){await dbDel('tasklog',k);S.tasklog.splice(i,1);}
    else{const l={key:k,tplId:item.t.id,date:dk,doneAt:Date.now()};await dbPut('tasklog',l);S.tasklog.push(l);}
  }else{item.t.done=!item.t.done;item.t.doneAt=item.t.done?Date.now():0;await dbPut('tasks',item.t);}
}

const monthGoals=m=>S.tasks.filter(t=>t.kind==='month'&&t.month===m).sort((a,b)=>a.createdAt-b.createdAt);

function goalPct(g){if(g.done)return 100;if(!g.target)return 0;return Math.max(0,Math.min(100,Math.round((+(g.current||0))/(+g.target)*100)));}

async function setGoalDone(g){g.done=!g.done;g.doneAt=g.done?Date.now():0;g.updatedAt=Date.now();await dbPut('tasks',g);}

async function goalStep(g,d){g.current=Math.max(0,(+(g.current||0))+d);if(g.target&&g.current>=g.target){g.done=true;g.doneAt=Date.now();}else if(g.target&&g.current<g.target){g.done=false;}g.updatedAt=Date.now();await dbPut('tasks',g);}

const LINK_TYPES=[['none','不关联'],['episode','课程分集（直接播放）'],['course','课程主页'],['note','笔记'],['mistake','错题'],['url','网页链接']];

const LINK_ICON={episode:'play',course:'book',note:'note',mistake:'target',url:'globe'};

const LINK_TEXT={episode:'去播放',course:'课程',note:'笔记',mistake:'错题',url:'链接'};

function openTaskLink(l){
  if(!l||l.type==='none')return;
  if(l.type==='episode'){const ep=S.episodes.find(e=>e.id===l.id);if(ep)Player.open(ep.id);else toast('关联的分集不存在','err');}
  else if(l.type==='course'){if(S.courses.find(c=>c.id===l.id))location.hash='#/course/'+l.id;else toast('关联的课程不存在','err');}
  else if(l.type==='note'){const n=S.notes.find(x=>x.id===l.id);if(n)noteForm({note:n});else toast('关联的笔记不存在','err');}
  else if(l.type==='mistake'){const m=S.mistakes.find(x=>x.id===l.id);if(m){const list=[...S.mistakes].sort((a,b)=>(b.wrongAt||b.createdAt)-(a.wrongAt||a.createdAt));mistakeDetail(list.findIndex(x=>x.id===m.id),list);}else toast('关联的错题不存在','err');}
  else if(l.type==='url'&&l.url){window.open(l.url,'_blank','noopener');}
}

function linkEditorHTML(val){
  val=val||{type:'none'};
  let out='<div class="link-sel-row"><select class="select" id="tfLkType">'+LINK_TYPES.map(([v,n])=>'<option value="'+v+'"'+(val.type===v?' selected':'')+'>'+n+'</option>').join('')+'</select></div><div id="tfLkBox" style="margin-top:8px"></div>';
  return out;
}

function bindLinkEditor(wrap,link){
  const typeSel=wrap.querySelector('#tfLkType'),box=wrap.querySelector('#tfLkBox');
  function draw(){
    const ty=typeSel.value;
    if(ty==='episode'){
      const cid=(S.episodes.find(e=>e.id===(link.id))||{}).courseId||(S.courses[0]&&S.courses[0].id)||'';
      box.innerHTML='<div class="link-sel-row"><select class="select" id="lkCourse">'+S.courses.map(c=>'<option value="'+c.id+'">'+esc(c.name)+'</option>').join('')+'</select><select class="select" id="lkEp"></select></div>';
      const cs=box.querySelector('#lkCourse'),es=box.querySelector('#lkEp');cs.value=cid;
      function drawEps(){const eps=epsOf(cs.value);es.innerHTML=eps.map((e,i)=>'<option value="'+e.id+'">第 '+(i+1)+' 集 · '+esc(e.title)+'</option>').join('');
        if(link.id&&eps.some(e=>e.id===link.id))es.value=link.id;link.id=es.value;}
      cs.onchange=()=>{drawEps();};drawEps();
      es.onchange=()=>{link.id=es.value;};
    }else if(ty==='course'){
      box.innerHTML='<select class="select" id="lkCourse">'+S.courses.map(c=>'<option value="'+c.id+'">'+esc(c.name)+'</option>').join('')+'</select>';
      const cs=box.querySelector('#lkCourse');if(link.id&&S.courses.some(c=>c.id===link.id))cs.value=link.id;link.id=cs.value;
      cs.onchange=()=>{link.id=cs.value;};
    }else if(ty==='note'){
      box.innerHTML='<select class="select" id="lkNote">'+S.notes.map(n=>'<option value="'+n.id+'">'+esc(n.title)+'</option>').join('')+'</select>'+(S.notes.length?'':'<div class="field-hint">还没有笔记，可先保存任务，之后再关联</div>');
      const ns=box.querySelector('#lkNote');if(link.id&&S.notes.some(n=>n.id===link.id))ns.value=link.id;if(ns)link.id=ns.value;
      if(ns)ns.onchange=()=>{link.id=ns.value;};
    }else if(ty==='mistake'){
      box.innerHTML='<select class="select" id="lkMk">'+S.mistakes.map(m=>'<option value="'+m.id+'">'+esc(m.subject+(m.chapter?' · '+m.chapter:'')+' — '+(m.stem||'附件错题').slice(0,24))+'</option>').join('')+'</select>'+(S.mistakes.length?'':'<div class="field-hint">还没有错题，可先保存任务，之后再关联</div>');
      const ms=box.querySelector('#lkMk');if(link.id&&S.mistakes.some(m=>m.id===link.id))ms.value=link.id;if(ms)link.id=ms.value;
      if(ms)ms.onchange=()=>{link.id=ms.value;};
    }else if(ty==='url'){
      box.innerHTML='<input class="input" id="lkUrl" placeholder="https://…" value="'+esc(link.url||'')+'">';
      const u=box.querySelector('#lkUrl');u.oninput=()=>{link.url=u.value;};
    }else box.innerHTML='';
  }
  typeSel.onchange=()=>{link.type=typeSel.value;if(link.type==='url')link.url=link.url||'';else link.id='';draw();};
  link.type=typeSel.value;draw();
}

/* 从弹性课程表 xlsx 导入每周重复任务 */


export { CAT_PAL, catColor, catTag, taskCats, dkAdd, dkWeekday, dkLabel, curMonthKey, monthLabel, monthDays, weekStart, weekOf, REP_LABEL, repText, tplOn, logKey, logOn, dayItems, toggleDay, monthGoals, goalPct, setGoalDone, goalStep, LINK_TYPES, LINK_ICON, LINK_TEXT, openTaskLink, linkEditorHTML, bindLinkEditor };
