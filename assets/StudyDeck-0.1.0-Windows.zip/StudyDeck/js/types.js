// @ts-check
// 数据模型的 JSDoc 类型定义（**编译期**部分）。
//
// 这里带 @ts-check，所以 tsc 会把它当作真实类型来校验 ——
// schema.js 只放运行期的值，字段形状放这里，两者配合：
//   运行时主键  → schema.js 的 STORE_KEYS（db.js 建表、测试断言）
//   编译期形状  → 本文件的 typedef（各模块用 @type {import('./types.js').X} 引用）
//
// 关键设计：TaskLog **没有** id 字段，只有 key。这样"按 id 过滤 tasklog"这种写法
// 会被 tsc 直接报错（TS2339），而不是等到恢复时静默丢掉打卡记录。

/**
 * 课程。
 * @typedef {Object} Course
 * @property {string} id
 * @property {string} name
 * @property {string} [subject]
 * @property {string} [color]      形如 #rrggbb；渲染前一律过 safeColor()
 * @property {string} [desc]
 * @property {number} [createdAt]
 * @property {number} [sort]       列表排序位（dataSig 也读它）
 * @property {number} [updatedAt]  备份指纹 dataSig 会读课程/错题的它
 */

/**
 * 分集。
 * @typedef {Object} Episode
 * @property {string} id
 * @property {string} courseId
 * @property {number} [order]
 * @property {string} [title]
 * @property {'bili'|'local'|string} [src]
 * @property {string} [url]
 * @property {number} [status]      0 未开始 / 1 进行中 / 2 已完成
 * @property {number|null} [completedAt]
 * @property {number} [updatedAt]
 * @property {number} [estMin]      预计单集时长（分钟），由 forms.js 写入，用于计划统计
 * @property {number} [playPos]     上次播放位置（秒），player.js 读写用于续播
 * @property {string} [fileName]    本地视频文件名（渲染前必须 esc()）
 * @property {unknown} [fileHandle] 文件句柄；个别浏览器无法结构化克隆，存库前会删掉
 */

/**
 * 笔记。epIds 可能缺失（旧备份），读取处必须容忍。
 * @typedef {Object} Note
 * @property {string} id
 * @property {string} [courseId]
 * @property {string[]} [epIds]
 * @property {string} [title]
 * @property {string} [text]
 * @property {number} [createdAt]
 * @property {number} [updatedAt]
 */

/**
 * 附件元数据。二进制本体在 blobs 表（或 _autobackup/blobs/）。
 * @typedef {Object} Attachment
 * @property {string} id
 * @property {string} noteId       挂载目标 id；三个构造点（forms/views-note/views-tasks）都写入
 * @property {string} [name]
 * @property {string} [type]        MIME；可能缺失，读取处必须给默认值
 * @property {number} [size]
 * @property {boolean} [missing]    备份时被跳过 / 本机没有二进制
 * @property {string} [kind]        'mistake' | 'task' —— 标注附件挂在哪种笔记/任务上
 * @property {number} [createdAt]
 * @property {number} [lastModified] 当前**没有任何写入方**会设置它（三个构造点都只写
 *                                   id/name/type/size/createdAt）。dataSig 里读它是历史遗留，
 *                                   值恒为 0。保留是为了不改动指纹字符串的格式。
 */

/**
 * 附件二进制。
 * @typedef {Object} BlobRec
 * @property {string} id
 * @property {Blob} blob
 */

/**
 * 学习计时会话。
 * @typedef {Object} Session
 * @property {string} id
 * @property {string} [epId]
 * @property {string} [courseId]  用于按课程汇总时长（courseSec/courseLastAt 都读它）
 * @property {number} start
 * @property {number} [end]       仍在计时中时可能还没有
 * @property {number} sec         本段秒数
 * @property {string} [kind]      'auto'（播放器自动计时）/ 'manual'（手动补记）
 */

/**
 * 错题。
 * @typedef {Object} Mistake
 * @property {string} id
 * @property {string} [subject]
 * @property {string} [chapter]
 * @property {string[]} [points]
 * @property {string} [stem]
 * @property {string} [analysis]
 * @property {number} [status]      0 待复习 / 1 复习中 / 2 已掌握
 * @property {number} [wrongAt]
 * @property {number} [createdAt]
 * @property {number} [updatedAt]
 */

/**
 * 任务 / 目标。
 * @typedef {Object} Task
 * @property {string} id
 * @property {'day'|'tpl'|'goal'|string} [kind]
 * @property {string} [date]
 * @property {string} [title]
 * @property {string} [note]
 * @property {boolean} [done]
 * @property {number} [doneAt]     完成时间（dataSig 读它）
 * @property {number} [order]
 * @property {number} [createdAt]
 * @property {number} [updatedAt]
 * @property {string} [repeat]     课表的重复规则（weekly / daily …）
 * @property {number[]} [weekdays] 课表按周几排（1=周一）
 * @property {string} [time]       课表时间 HH:MM
 * @property {string} [cat]        分类名（课表/目标会用到）
 * @property {string} [link]       关联对象（分集/课程/资料）
 */

/**
 * 打卡记录。**主键是 key，不是 id** —— 结构为 `模板id@日期`。
 * 刻意不声明 id 字段：任何按 id 读写它的代码都会被 tsc 报错。
 * @typedef {Object} TaskLog
 * @property {string} key           `${tplId}@${date}`，见 views-task.js 的 logKey()
 * @property {string} [tplId]
 * @property {string} [date]        YYYY-MM-DD
 * @property {number} [doneAt]
 */

/**
 * 资料库条目（文件或文件夹）。
 * @typedef {Object} Resource
 * @property {string} id
 * @property {string} [name]
 * @property {string} [type]
 * @property {string} [kind]        'folder' | 'folder-item' | 其他
 * @property {number} [size]
 * @property {string} [folder]
 * @property {number} [createdAt]
 * @property {number} [updatedAt]
 * @property {{id:string}[]} [files] kind 为 folder-item 时的子文件（删除时要一并清 blobs）
 * @property {number} [fileCount]   文件夹条目记录的子文件数
 */

/**
 * 应用设置。凭证 SESSDATA 不进备份。
 * @typedef {Object} Settings
 * @property {string} [theme]
 * @property {number} [dailyGoal]
 * @property {boolean} [autoLocal]
 * @property {boolean} [autoBackup]
 * @property {boolean} [autoNext]
 * @property {string} [biliMode]
 * @property {number} [biliQn]
 * @property {string} [sessdata]
 * @property {boolean} [timerTickSound]
 * @property {boolean} [showCountdown]
 * @property {string} [countdownDate]
 * @property {string} [aiApiKey]       AI 大模型 API Key（不进备份导出）
 * @property {string} [aiBaseUrl]      AI 接口根地址（默认 DeepSeek）
 * @property {string} [aiModel]        AI 模型名（默认 deepseek-chat）
 * @property {string} [aiNotesPrompt]  AI 笔记自定义提示词（可选）
 */

/**
 * 备份文件里的一个附件条目（v3：只有清单；v2：带 Base64 的 data）。
 * @typedef {Object} BackupFileEntry
 * @property {string} id
 * @property {number} [size]
 * @property {string} [type]
 * @property {string} [name]
 * @property {string} [data]        v2 旧格式：data:...;base64,...
 */

/**
 * 播放器（player.js 的 Player 对象）的内部状态字段。
 * 这些键之前在对象字面量里没有初始化，只在运行中赋值 —— tsc 看字面量推断类型，
 * 于是 `this._dashCtrl` 这类 32 处赋值全部报 TS2339。把状态显式声明出来才是诚实的形状。
 * @typedef {Object} PlayerState
 * @property {string|null} epId
 * @property {any} md                        当前播放器弹窗（openModal 的返回值）
 * @property {{running:boolean,startedAt:number,base:number}|null} timer  学习计时器状态
 * @property {string|null} objectUrl
 * @property {Session|null} curSess
 * @property {number|null} tickTimer
 * @property {AbortController|null} _dashCtrl
 * @property {AbortController|null} _fetchCtrl
 * @property {string|null} _dashUrl
 * @property {number|null} _nextTimer
 * @property {number|null} _pendFin
 * @property {number|null} _chkTimer
 * @property {((e:KeyboardEvent)=>void)|null} _docKey
 * @property {(()=>void)|null} _fsHandler
 */

/**
 * 备份文件的形状。
 * @typedef {Object} BackupData
 * @property {'studydeck'} [app]
 * @property {number} [version]
 * @property {number} [exportedAt]
 * @property {Course[]} [courses]
 * @property {Episode[]} [episodes]
 * @property {Note[]} [notes]
 * @property {Attachment[]} [attachments]
 * @property {Session[]} [sessions]
 * @property {Mistake[]} [mistakes]
 * @property {Task[]} [tasks]
 * @property {TaskLog[]} [tasklog]
 * @property {Resource[]} [resources]
 * @property {Settings} [settings]
 * @property {BackupFileEntry[]} [files]
 * @property {number} [_skippedBlobs]
 * @property {number} [_blobBytes]
 * @property {number} [_skippedBytes]
 * @property {{id:string,blob:Blob}[]} [_blobParts]  仅本次调用的二进制通道，不写进 JSON
 */

/**
 * 视图层的临时 UI 状态（不持久化，不进备份）。
 * @typedef {Object} UiState
 * @property {string} courseFilter
 * @property {string} epFilter
 * @property {string} noteCourse
 * @property {string} noteQuery
 * @property {{subject:string,chapter:string,point:string,status:string,q:string}} mist
 * @property {{tab:string,day:string,month:string}} task
 */

/**
 * 路由解析结果。
 * @typedef {Object} Route
 * @property {string} name
 * @property {string} [id]         通用 id（课程页用 S.route.id 取 courseId）
 * @property {string} [courseId]
 * @property {string} [epId]
 * @property {string} [noteId]
 * @property {string} [note]       笔记页要定位到的笔记 id（viewkit 路由解析写入）
 * @property {string} [mId]        错题页要定位到的错题 id（viewkit 路由解析写入）
 * @property {string} [rId]
 * @property {string} [play]
 * @property {string} [q]
 * @property {string} [tab]
 */

/**
 * 全局状态 S 的形状。这是**所有视图读写数据的地方**，
 * 把它标出来之后，S.courses[0].nam 这类拼写错误会直接变成编译错误。
 * @typedef {Object} AppState
 * @property {Course[]} courses
 * @property {Episode[]} episodes
 * @property {Note[]} notes
 * @property {Attachment[]} attachments
 * @property {Session[]} sessions
 * @property {Mistake[]} mistakes
 * @property {Task[]} tasks
 * @property {TaskLog[]} tasklog
 * @property {Resource[]} resources
 * @property {boolean} proxy
 * @property {Settings} settings
 * @property {Route} route
 * @property {UiState} ui
 * @property {boolean} [serverSess]
 * @property {string} [_lsig]      上次本地备份时的指纹（dataSig() 返回 JSON 字符串）
 * @property {string} [_cbSig]     上次云备份时的指纹（dataSig() 返回 JSON 字符串）
 * @property {any} [_cbHandle]     云备份文件夹句柄（FileSystemDirectoryHandle，非标准 API）
 */

/* 让本文件成为「模块」：否则 import('./types.js').X 会报 TS2306（不是模块）。
   顺带做两个编译期断言 —— 它们把 "tasklog 用 key 不用 id" 从注释变成约束。 */

/** 每个 store 名 → 它记录类型的主键字段名。 */
export const PRIMARY_KEY_FIELDS = {
  courses: /** @type {'id'} */ ('id'),
  episodes: /** @type {'id'} */ ('id'),
  notes: /** @type {'id'} */ ('id'),
  attachments: /** @type {'id'} */ ('id'),
  blobs: /** @type {'id'} */ ('id'),
  sessions: /** @type {'id'} */ ('id'),
  mistakes: /** @type {'id'} */ ('id'),
  tasks: /** @type {'id'} */ ('id'),
  tasklog: /** @type {'key'} */ ('key'),
  kv: /** @type {'key'} */ ('key'),
  resources: /** @type {'id'} */ ('id'),
};

/**
 * 每个 store 名 → 它的记录类型。用来把「主键字段名必须真实存在于该记录上」变成编译期约束。
 * @typedef {Object} StoreRecords
 * @property {Course} courses
 * @property {Episode} episodes
 * @property {Note} notes
 * @property {Attachment} attachments
 * @property {BlobRec} blobs
 * @property {Session} sessions
 * @property {Mistake} mistakes
 * @property {Task} tasks
 * @property {TaskLog} tasklog
 * @property {{key:string,value:unknown}} kv
 * @property {Resource} resources
 */

/**
 * 编译期断言：每个 store 的主键字段名必须是**该记录类型上真实存在的字段**。
 * 给 tasklog 写成 'id' 会立刻报错 —— 因为 TaskLog 上没有 id（这正是上次事故的形状）。
 * @typedef {{[K in keyof StoreRecords]: keyof StoreRecords[K]}} PrimaryKeyMustExist
 */

/** @type {PrimaryKeyMustExist} */
export const PRIMARY_KEYS_TYPECHECK = PRIMARY_KEY_FIELDS;

/**
 * 编译期断言：TaskLog **没有** id 字段。
 * 若哪天有人给 TaskLog 补上 `id`，这里会从 true 变成 never 而报错，
 * 强迫我们回头确认"打卡记录到底该用 key 还是 id"这个出过事故的设计。
 * @type {TaskLog extends {id:string} ? never : true}
 */
export const TASKLOG_HAS_NO_ID = /** @type {any} */ (true);
