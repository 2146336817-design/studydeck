// @ts-check
// 启动入口：初始化界面、加载数据、拉起备份定时器。
//
// 备份 / 恢复 / 云备份的逻辑都在 settings-backup.js（**单向**依赖）。
// 早先这些逻辑与 views-dispatch.js 相互 import，形成 app ⇄ views-dispatch 的环；
// 拆出 settings-backup.js 之后依赖图是干净的 DAG（tools/cycle-check.mjs 会把关）。
import './views-dispatch.js';
import { S, openDB, loadAll } from './db.js';
import { confirmDialog, toast } from './ui.js';
import { $, dataSig, ensurePersistentStorage, esc, fmtDateTime } from './util.js';
import { applyTheme, render } from './viewkit.js';
/* 备份/云备份的逻辑都在 settings-backup.js —— 单向依赖，不再反向 import。 */
import {
  applyBackupData, auditNote, BACKUP_VERSION, hydrateFromLocalBackup,
  startCloudBackupTimer, startLocalBackupTimer, startupCloudBackup,
} from './settings-backup.js';

async function maybeAutoRestore(){
  if(S.courses.length>0)return;
  try{
    const r=await fetch('/api/autobackup/read');const j=await r.json();
    if(!j||j.code!==0||!j.data)return;
    const d=j.data;
    if(d.app!=='studydeck')return;
    if(d.version&&d.version>BACKUP_VERSION)return;
    for(const k of ['courses','episodes','notes','attachments','sessions','mistakes','tasks','tasklog','files','resources']){if(d[k]!==undefined&&!Array.isArray(d[k]))return;}
    if(!((d.courses||[]).length+(d.notes||[]).length+(d.tasks||[]).length))return;
    const name=(d.exportedAt?fmtDateTime(d.exportedAt):'');
    const ok=await confirmDialog('发现本地自动备份','当前浏览器里没有数据，但检测到本地自动备份'+(name?'（备份于 '+name+'）':'')+'。要自动恢复吗？','自动恢复');
    if(!ok)return;
    await hydrateFromLocalBackup(d);      /* 先把附件二进制从本地备份拉回来 */
    const audit=await applyBackupData(d,'merge');
    S._lsig=dataSig();
    toast('已自动恢复本地备份'+(name?'（'+name+'）':'')+auditNote(audit),audit&&audit.missing?'err':'ok');
  }catch(e){}
}


/* ============ 启动 ============ */

async function init(){
  try{
    const menu=$('#mMenu'), scrim=$('#scrim'), sb=$('#sidebar');
    menu.onclick=()=>{sb.classList.toggle('open');scrim.classList.toggle('show',sb.classList.contains('open'));};
    scrim.onclick=()=>{sb.classList.remove('open');scrim.classList.remove('show');};
    await openDB(); await loadAll(); applyTheme();
    ensurePersistentStorage();     /* 异步申请持久化配额，不阻塞启动 */
    if(location.protocol==='http:'||location.protocol==='https:'){
      try{const pr=await fetch('/api/ping');const pj=await pr.json();S.proxy=pj.ok===true;S.serverSess=!!pj.hasSessFile;}catch(e){S.proxy=false;S.serverSess=false;}
    }
    if(!location.hash)location.hash='#/dashboard';
    render();
    if(location.protocol==='file:'){
      toast('当前是「直接双击 html」模式：看不到代理版（127.0.0.1:8787）和云备份里的数据，B 站高清也不可用。日常请用「启动课业（B站高清）.bat」打开。','err');
    }
    startCloudBackupTimer();startupCloudBackup();startLocalBackupTimer();
    setTimeout(maybeAutoRestore,1200);
  }catch(e){
    console.error(e);
    $('#main').innerHTML='<div class="view"><div class="empty"><div class="empty-title">启动失败</div><div class="small">'+esc((/** @type {any} */ (e)).message)+'<br>请使用 Edge / Chrome 打开，并确认浏览器未禁用 IndexedDB。</div></div></div>';
  }
}

/* 只注册一次。
   这里曾经**重复注册了两遍**（拆分 app.js 时留下的）：DOMContentLoaded 触发两次 init，
   于是 startCloudBackupTimer/startLocalBackupTimer 各被调用两次、startupCloudBackup 跑两次。
   两个 start* 内部本身是幂等的（先 clearInterval 再 setInterval），
   但那只是"重复调用不出错"，不该拿它兜底接线错误 —— 所以既删掉重复注册，
   也在 start* 里加了显式守卫（见 settings-backup.js）。 */
document.addEventListener('DOMContentLoaded',init);
