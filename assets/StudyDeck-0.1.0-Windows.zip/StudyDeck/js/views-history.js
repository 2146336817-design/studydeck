// @ts-check
// 历史视图：按天浏览学习记录并删除条目。
// （从 views-task.js 拆出。）
import { I } from './icons.js';
import { S, courseOf, dbDel } from './db.js';
import { confirmDialog } from './ui.js';
import { esc, fmtDurShort, pad2 } from './util.js';
import { render, viewHead } from './viewkit.js';

function histDk(t){const d=new Date(t);return d.getFullYear()+'-'+pad2(d.getMonth()+1)+'-'+pad2(d.getDate());}

function histTime(t){const d=new Date(t);return pad2(d.getHours())+':'+pad2(d.getMinutes());}

function histDayLabel(k){const d=new Date(k.replace(/-/g,'/'));const wd=['日','一','二','三','四','五','六'][d.getDay()];return k+' 周'+wd;}

function viewHistory(main){
  const CATS=[['all','全部'],['video','视频'],['resource','资料'],['note','笔记'],['mistake','错题']];
  const TYPE_META={video:['play','#0f6b54','看了视频'],resource:['file','#a86b2d','上传资料'],note:['note','#2f5d8a','写了笔记'],mistake:['target','#b3412f','添加错题']};
  let cat='all';
  const events=[];
  S.sessions.forEach(s=>{const ep=S.episodes.find(e=>e.id===s.epId);if(!ep)return;
    events.push({t:s.start||s.end,type:'video',id:s.id,epId:ep.id,title:ep.title,cid:ep.courseId,extra:fmtDurShort(s.sec)});});
  S.resources.filter(r=>r.kind!=='folder').forEach(r=>events.push({t:r.createdAt,type:'resource',id:r.id,title:r.name,cid:'',extra:r.type||'其他'}));
  S.notes.forEach(n=>events.push({t:n.updatedAt||n.createdAt,type:'note',id:n.id,title:n.title||'无标题笔记',cid:n.courseId,extra:''}));
  S.mistakes.forEach(m=>events.push({t:m.wrongAt||m.createdAt,type:'mistake',id:m.id,title:(m.subject||'错题')+(m.chapter?' · '+m.chapter:''),cid:m.courseId,extra:(m.stem||'').slice(0,30)}));
  events.sort((a,b)=>b.t-a.t);
  main.innerHTML=viewHead('历史','按时间回顾你的学习轨迹（视频 / 资料 / 笔记 / 错题），可搜索、点条目跳转、删除')+
    '<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:14px">'+
      '<span class="small muted">分类</span>'+
      CATS.map(c=>'<button class="btn btn-sm'+(cat===c[0]?' btn-primary':'')+'" data-cat="'+c[0]+'">'+c[1]+'</button>').join('')+
      '<div style="position:relative;margin-left:auto">'+I('search','')+'<input class="input" id="histSearch" placeholder="搜索历史…" style="padding-left:30px;width:180px"></div>'+
      '<span class="small muted">共 '+events.length+' 条</span></div>'+
    '<div id="histList"></div>';
  const list=main.querySelector('#histList');
  const draw=()=>{
    const q=(main.querySelector('#histSearch').value||'').toLowerCase().trim();
    /* (courseOf(e.cid)||{}).name 会在 cid 不匹配任何课程时抛 TypeError ——
       `undefined.name` 先于 `.toLowerCase()` 求值。历史搜索一输入就必现。
       用 String((...)||'') 兜底：既避开 undefined，也保证下面是字符串。 */
    const cnameOf=id=>String((courseOf(id)||{}).name||'').toLowerCase();
    const items=events.filter(e=>(cat==='all'||e.type===cat)&&(!q||(e.title||'').toLowerCase().includes(q)||cnameOf(e.cid).includes(q)||(e.extra||'').toLowerCase().includes(q)));
    if(!items.length){list.innerHTML='<div class="empty">'+I('clock')+'<div class="empty-title">暂无记录</div><div>学习过的视频、资料、笔记、错题会按时间出现在这里</div></div>';return;}
    const groups={};
    items.forEach(e=>{const k=histDk(e.t);(groups[k]=groups[k]||[]).push(e);});
    const days=Object.keys(groups).sort().reverse();
    list.innerHTML=days.map(k=>{
      const rows=groups[k].map(e=>{
        const m=TYPE_META[e.type]||['file','#2f5d8a',''];
        const cname=(courseOf(e.cid)||{}).name||'';
        return '<div class="card" style="display:flex;align-items:center;gap:12px;padding:12px 16px;margin-bottom:8px;cursor:pointer" data-go="'+e.type+'" data-cid="'+(e.cid||'')+'" data-id="'+e.id+'" data-ep="'+(e.epId||'')+'">'+
          '<span style="width:34px;height:34px;border-radius:9px;background:'+m[1]+'22;color:'+m[1]+';display:flex;align-items:center;justify-content:center;flex:none">'+I(m[0])+'</span>'+
          '<div style="flex:1;min-width:0"><div style="display:flex;align-items:center;gap:8px"><span class="pill" style="flex:none;font-size:11px">'+m[2]+'</span><span class="ellipsis" style="font-weight:600">'+esc(e.title)+'</span></div>'+
          '<div class="tiny dim">'+histTime(e.t)+(cname?' · '+esc(cname):'')+(e.extra?' · '+esc(e.extra):'')+'</div></div>'+
          '<span class="tiny dim" style="flex:none">'+histDk(e.t).slice(5)+'</span>'+
          '<button class="icon-btn" style="flex:none;color:#e74c3c" data-del="'+e.type+'" data-id="'+e.id+'" title="删除该条历史">'+I('x')+'</button>'+
        '</div>';
      }).join('');
      return '<div class="hist-day" style="margin:16px 0 8px;font-weight:650">'+histDayLabel(k)+'<span class="small muted"> · '+groups[k].length+' 条</span></div>'+rows;
    }).join('');
    list.querySelectorAll('[data-go]').forEach(row=>row.onclick=()=>{
      const t=row.dataset.go;
      if(t==='video')location.hash='#/course/'+row.dataset.cid+'/play/'+row.dataset.ep;
      else if(t==='resource')location.hash='#/resources/'+row.dataset.id;
      else if(t==='note')location.hash='#/notes/'+row.dataset.id;
      else location.hash='#/mistakes/'+row.dataset.id;
    });
    list.querySelectorAll('[data-del]').forEach(b=>b.onclick=async e=>{
      e.stopPropagation();await delHistItem(b.dataset.del,b.dataset.id);
    });
  };
  main.querySelectorAll('[data-cat]').forEach(b=>b.onclick=()=>{cat=b.dataset.cat;
    main.querySelectorAll('[data-cat]').forEach(x=>x.classList.toggle('btn-primary',x===b));draw();});
  main.querySelector('#histSearch').addEventListener('input',draw);
  draw();
}

async function delHistItem(type,id){
  if(type==='video'){
    if(!await confirmDialog('删除历史','将删除这条视频学习记录，学习时长统计也会相应减少。确定吗？','删除'))return;
    await dbDel('sessions',id);const i=S.sessions.findIndex(x=>x.id===id);if(i>=0)S.sessions.splice(i,1);
  }else if(type==='resource'){
    const r=S.resources.find(x=>x.id===id);
    if(!await confirmDialog('删除历史','将一并删除资料「'+esc(r?r.name:'')+'」及其文件内容。确定吗？','删除'))return;
    /* 与资料库页面的「删除」保持一致：文件夹条目还要清掉它下面每个子文件的二进制，
       否则这些 blob 会变成没人引用的孤儿（看不见、也永远不会被回收）。 */
    if(r&&r.kind==='folder-item'){for(const it of (r.files||[]))await dbDel('blobs',it.id);}
    await dbDel('blobs',id);await dbDel('resources',id);const i=S.resources.findIndex(x=>x.id===id);if(i>=0)S.resources.splice(i,1);
  }else if(type==='note'){
    if(!await confirmDialog('删除历史','将一并删除这篇笔记及其附件。确定吗？','删除'))return;
    await dbDel('notes',id);
    const atts=S.attachments.filter(a=>a.noteId===id);
    for(const a of atts){await dbDel('blobs',a.id);await dbDel('attachments',a.id);}
    S.notes=S.notes.filter(n=>n.id!==id);S.attachments=S.attachments.filter(a=>a.noteId!==id);
  }else if(type==='mistake'){
    if(!await confirmDialog('删除历史','将一并删除这条错题及其附件。确定吗？','删除'))return;
    await dbDel('mistakes',id);
    const atts=S.attachments.filter(a=>a.noteId===id);
    for(const a of atts){await dbDel('blobs',a.id);await dbDel('attachments',a.id);}
    S.mistakes=S.mistakes.filter(m=>m.id!==id);S.attachments=S.attachments.filter(a=>a.noteId!==id);
  }
  render();
}


export { histDk, histTime, histDayLabel, viewHistory, delHistItem };
