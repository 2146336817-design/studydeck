// @ts-check
// 零依赖的纯工具层。
//
// 这里**不许** import 任何本项目模块 —— 它是依赖图的叶子。
// 存在的意义：把「不碰全局状态 S、不碰数据层、不碰弹窗」的纯函数集中起来，
// 从而打断 db ⇄ util 与 util ⇄ ui 两个 import 环：
//     util → db → core
//     util → ui → core
// 两者都不再互相依赖。若哪天需要在这里 import 别的模块，说明该函数并不纯，
// 应该放回 util.js / db.js。

/** @param {string} s @param {ParentNode} [r] @returns {any} */
const $=(s,r)=> (r||document).querySelector(s);

/** @param {string} s @param {ParentNode} [r] @returns {any[]} */
const $$=(s,r)=> Array.from((r||document).querySelectorAll(s));

/**
 * 建一个元素（可选设置 class 与 innerHTML）。
 * @param {string} tag
 * @param {string} [cls]
 * @param {string} [html]
 * @returns {any}
 */
function el(tag, cls, html){const e=document.createElement(tag); if(cls)e.className=cls; if(html!=null)e.innerHTML=html; return e;}

/** HTML 转义（所有拼进 innerHTML 的外部数据都必须过它）。
 *  @param {any} s @returns {string} */
const esc=s=> String(s==null?'':s).replace(/[&<>"']/g, c =>
  /** @type {Record<string,string>} */ ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c] || c);

/** @returns {string} 随机 id */
const uid=()=> Date.now().toString(36)+Math.random().toString(36).slice(2,8);

/** @param {number} n @param {number} a @param {number} b @returns {number} */
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));

/** @param {number} n @returns {string} */
const pad2=n=>String(n).padStart(2,'0');

/** @param {number} ts @returns {string} YYYY-MM-DD */
function dateKey(ts){const d=new Date(ts); return d.getFullYear()+'-'+pad2(d.getMonth()+1)+'-'+pad2(d.getDate());}

/** @returns {string} */
function todayKey(){return dateKey(Date.now());}

/** @param {number} sec @returns {string} 计时器样式 00:00:00 */
function fmtTime(sec){ // 计时器 00:00:00
  sec=Math.max(0,Math.round(sec)); const h=Math.floor(sec/3600), m=Math.floor(sec%3600/60), s=sec%60;
  return (h?pad2(h)+':':'')+pad2(m)+':'+pad2(s);
}

/** @param {number} sec @returns {string} 学习时长 1时05分 / 23分 */
function fmtDur(sec){ // 学习时长 1时05分 / 23分
  sec=Math.round(sec||0); if(sec<60) return sec+'秒';
  const h=Math.floor(sec/3600), m=Math.round(sec%3600/60);
  if(!h) return m+'分'; return h+'时'+pad2(m)+'分';
}

/** @param {number} sec @returns {string} */
function fmtDurShort(sec){
  sec=Math.round(sec||0); if(sec<60) return sec+'s';
  const h=Math.floor(sec/3600), m=Math.floor(sec%3600/60);
  return h? (h+'h'+(m?m+'m':'')) : m+'m';
}

/** @param {number} [ts] @returns {string} */
function fmtDateTime(ts){ if(!ts)return '—'; const d=new Date(ts);
  return (d.getMonth()+1)+'月'+d.getDate()+'日 '+pad2(d.getHours())+':'+pad2(d.getMinutes());}

/** @param {number} ts @returns {string} */
function fmtDay(ts){const d=new Date(ts);return d.getMonth()+1+'/'+d.getDate();}

/** @param {string} k1 @param {string} k2 @returns {number} 两个 YYYY-MM-DD 相差几天 */
function daysBetween(k1,k2){return Math.round((new Date(k2+'T00:00:00').getTime()-new Date(k1+'T00:00:00').getTime())/864e5);}

/** @param {number} [ts] @returns {string} */
function humanAgo(ts){ if(!ts)return '从未'; const diff=Date.now()-ts;
  if(diff<6e4)return '刚刚'; if(diff<36e5)return Math.floor(diff/6e4)+'分钟前';
  if(diff<864e5)return Math.floor(diff/36e5)+'小时前'; if(diff<30*864e5)return Math.floor(diff/864e5)+'天前';
  return fmtDateTime(ts);}

/** @param {number} bytes @returns {string} */
function fmtSize(bytes){ if(bytes<1024)return bytes+' B'; if(bytes<1048576)return (bytes/1024).toFixed(1)+' KB';
  return (bytes/1048576).toFixed(1)+' MB';}

/** @param {string} name @param {Blob} blob */
function downloadBlob(name, blob){ const u=URL.createObjectURL(blob); const a=document.createElement('a');
  a.href=u;a.download=name;document.body.appendChild(a);a.click();a.remove(); setTimeout(()=>URL.revokeObjectURL(u),4000);}

/** @param {string} url @returns {string} */
function hostOf(url){try{return new URL(url).hostname.replace(/^www\./,'');}catch(e){return '';}}

/* B站链接解析：支持 BV/av + 分P */

/** B 站链接解析结果：三种形态必居其一，page 恒有。
 *  @param {any} url
 *  @returns {{bvid:string,avid?:undefined,ep?:undefined,page:number}|{bvid?:undefined,avid:string,ep?:undefined,page:number}|{bvid?:undefined,avid?:undefined,ep:string,page:number}|null} */
function parseBili(url){
  if(!url) return null;
  const m = url.match(/(BV[0-9A-Za-z]{10})/i);
  const av = url.match(/[?\/]av(\d+)/i);
  let page=1; const pm=url.match(/[?&]p=(\d+)/); if(pm)page=+pm[1];
  if(m) return {bvid:m[1].replace(/^bv/i,'BV'), page};
  if(av) return {avid:av[1], page};
  const epm = url.match(/bangumi\/play\/ep(\d+)/i);
  if(epm) return {ep:epm[1], page:1};
  return null;
}
/* 合集页链接解析：space.bilibili.com/{mid}/channel/collectiondetail?sid=xxx */

/** @param {string} url @returns {{type:string,[k:string]:any}|null} */
function parseCollection(url){
  if(!url) return null;
  /* 合集（season）：channel/collectiondetail?sid= 或 ?sid= */
  let m = url.match(/channel\/collectiondetail[^?]*[?&]sid=(\d+)/i)
        || url.match(/[?&]sid=(\d+)/i);
  if(m) return {type:'season', sid:m[1]};
  /* 新版收藏夹 /lists/{id}?type=fav */
  m = url.match(/\/lists\/(\d+)\?type=fav/i);
  if(m) return {type:'fav', fid:m[1]};
  /* 新版合集 /lists/{id}?type=season */
  m = url.match(/\/lists\/(\d+)\?type=season/i);
  if(m) return {type:'season', sid:m[1]};
  /* 合集 /lists|mlist/{id}（无 type 默认合集） */
  m = url.match(/\/lists\/(\d+)/i) || url.match(/\/mlist\/(\d+)/i);
  if(m) return {type:'season', sid:m[1]};
  /* 收藏夹：favlist?fid= 或 medialist/detail/ml{id} */
  m = url.match(/[?&]fid=(\d+)/i);
  if(m) return {type:'fav', fid:m[1]};
  m = url.match(/medialist\/detail\/ml(\d+)/i);
  if(m) return {type:'fav', fid:m[1]};
  /* 番剧/综艺/电视剧整季 /bangumi/play/ss{id} */
  m = url.match(/bangumi\/play\/ss(\d+)/i);
  if(m) return {type:'pgc', ssid:m[1]};
  /* 番剧单集 /bangumi/play/ep{id} → 服务端反查整季 */
  m = url.match(/bangumi\/play\/ep(\d+)/i);
  if(m) return {type:'pgc', ep:m[1]};
  /* UP 主主页 /space.bilibili.com/{mid} 或 /video */
  m = url.match(/space\.bilibili\.com\/(\d+)(?:\/video)?(?=[?#]|$)/i);
  if(m) return {type:'up', mid:m[1]};
  return null;
}

/** @param {any} ep @returns {string} */
function biliEmbed(ep){ const b=parseBili(ep.url); if(!b)return '';
  const p='&page='+(b.page||1);
  return 'https://player.bilibili.com/player.html?'+(b.bvid?('bvid='+b.bvid):('aid='+b.avid))+p+'&high_quality=1&danmaku=0&autoplay=1';}

const SRC_LABEL={bili:'B站',local:'本地',web:'网页'};

const COURSE_COLORS=['#0f6b54','#2f5d8a','#a86b2d','#7c5cbf','#b3412f','#34506e','#7a8441','#945d76'];

/** 只放行 #rrggbb，其余（含 undefined / 畸形值）回落默认色。
 *  @param {any} v @returns {string} */
function safeColor(v){return (typeof v==='string'&&/^#[0-9a-fA-F]{6}$/.test(v.trim()))?v.trim():'#2f5d8a';}

/* ============ IndexedDB 数据层 ============ */

/** @param {any} name @returns {string} */
function courseInitial(name){return (name||'?').trim().charAt(0)||'?';}

const STATUS_LABEL=['未开始','进行中','已完成'];

const MK_STATUS=[{v:0,name:'待复习',color:'#b3412f'},{v:1,name:'复习中',color:'#c08a26'},{v:2,name:'已掌握',color:'#0f6b54'}];

/** @param {number} s @returns {{v:number,name:string,color:string}} */
const mkStatusOf=s=>MK_STATUS.find(x=>x.v===s)||MK_STATUS[0];

const MISSING_ATT_TAG=' <span style="color:var(--danger);font-size:11px;font-weight:650">· 数据缺失</span>';

/** 本机实际存在的附件二进制 id 集合（loadAll/刷新时重建）。 */
const blobsHave=new Set();

/** @param {any} a @returns {boolean} */
const isMissingAtt=a=>!!(a&&!blobsHave.has(a.id));

async function ensurePersistentStorage(){
  try{
    if(!(navigator.storage&&navigator.storage.persist))return false;
    if(await navigator.storage.persisted())return true;
    return await navigator.storage.persist();
  }catch(e){return false;}
}

async function storageInfo(){
  try{
    if(!(navigator.storage&&navigator.storage.estimate))return null;
    const est=await navigator.storage.estimate();
    return {usage:est.usage||0,quota:est.quota||0,persisted:await ensurePersistentStorage()};
  }catch(e){return null;}
}

async function renderStorageInfo(){
  /* 用 HTMLElement 而不是 Element：下面要设 style.color。 */
  const box=/** @type {HTMLElement|null} */ (document.querySelector('#storageInfo'));
  if(!box)return;
  const info=await storageInfo();
  if(!info){box.textContent='当前浏览器不支持读取存储占用信息';return;}
  const pct=info.quota?Math.round(info.usage/info.quota*100):0;
  box.textContent='本机存储：已用 '+fmtSize(info.usage)+' / 配额约 '+fmtSize(info.quota)+'（'+pct+'%）　·　持久化存储：'
    +(info.persisted?'已开启（浏览器不会自动清理）':'未开启（磁盘紧张时浏览器可能回收数据，请务必保留一份导出备份）');
  box.style.color=info.persisted?'':'var(--danger)';
}

/* 长期密钥清单：**既不能进备份、也不能进备份指纹**的设置项。
   放在这里当单一真源 —— 当初就是两处各写一遍，导致 sessdata 脱敏了、aiApiKey 漏掉
   （改 API Key 会白白触发一次备份，Key 还会进 kv 的 backupSig）。 */
/** @type {readonly string[]} */
const SECRET_SETTINGS = ['sessdata', 'aiApiKey'];

/* 只导出本文件真正定义的那些纯工具（不要照抄 util.js 的导出清单 ——
   那份清单里包含 dataSig / openAttachment 等依赖状态的符号，本文件并没有它们）。 */
export { $, $$, el, esc, uid, clamp, pad2, dateKey, todayKey, fmtTime, fmtDur, fmtDurShort, fmtDateTime, fmtDay, daysBetween, humanAgo, fmtSize, downloadBlob, hostOf, parseBili, parseCollection, biliEmbed, SRC_LABEL, COURSE_COLORS, safeColor, courseInitial, STATUS_LABEL, MK_STATUS, mkStatusOf, MISSING_ATT_TAG, blobsHave, isMissingAtt, ensurePersistentStorage, storageInfo, renderStorageInfo, SECRET_SETTINGS };
