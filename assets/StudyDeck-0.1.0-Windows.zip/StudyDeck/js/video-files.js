// 本地视频文件的选择与"分集→文件句柄"的存取。
//
// 从 player.js 拆出来：它是纯底层能力（浏览器文件选择 + fileHandle 存取），
// 不依赖播放器本体，也不依赖任何表单。player.js 与 forms.js 都从它取用。
import { S, dbPut } from './db.js';
import { toast } from './ui.js';

/* 检测本地文件选择能力。showOpenFilePicker 是非标准 API（不在 TS 的 DOM lib 里），按 any 访问。 */
const HAS_FS = !!(/** @type {any} */ (window).showOpenFilePicker);

/** @returns {Promise<{name:string,handle?:any,file?:File}[]>} */
async function pickVideoFiles(){
  if(HAS_FS){
    const handles=await (/** @type {any} */ (window)).showOpenFilePicker({multiple:true});
    // 不指定 types 过滤，避免 Windows 文件对话框在过滤模式下限制多选
    return handles.map((/** @type {any} */ h)=>({name:h.name,handle:h}));
  }
  return new Promise(res=>{
    const inp=document.createElement('input');inp.type='file';inp.multiple=true;inp.accept='video/*';
    inp.onchange=()=>res([...(/** @type {any} */ (inp.files)||[])].map((/** @type {any} */ f)=>({name:f.name,file:f})));
    inp.click();
  });
}

/* 单个分集表单 */


/** fileHandle 在个别浏览器无法结构化克隆时降级：先删掉句柄存一次，再把句柄放回内存对象。
 *  @param {any} ep @returns {Promise<void>} */
async function safePutEp(ep){ // fileHandle 个别浏览器无法结构化克隆时降级
  try{await dbPut('episodes',ep);}
  catch(e){const h=ep.fileHandle;delete ep.fileHandle;await dbPut('episodes',ep);ep.fileHandle=h;
    toast('浏览器不支持记住文件位置，已仅记录文件名','err');}
}

export { HAS_FS, pickVideoFiles, safePutEp };
