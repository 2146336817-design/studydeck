import { I } from './icons.js';
import { S, courseProgress, dbPutMany } from './db.js';
import { toast } from './ui.js';
import { courseInitial, courseLastAt, courseSec, esc, fmtDur, fmtDurShort, humanAgo, safeColor } from './util.js';
import { render, viewHead } from './viewkit.js';
import { courseForm } from './player.js';

function enableCourseDrag(grid){
  let dragId=null, dragging=false, startY=0, suppressClick=false;
  const clear=()=>{
    grid.querySelectorAll('.course-card').forEach(c=>c.classList.remove('dragging','drop-before','drop-after'));
    document.removeEventListener('pointermove',onMove);
    document.removeEventListener('pointerup',onUp);
  };
  function orderIds(){return [...grid.querySelectorAll('.course-card')].map(c=>c.dataset.id);}
  function onMove(e){
    if(!dragId)return;
    if(!dragging&&Math.abs(e.clientY-startY)<8)return;
    dragging=true;
    const src=grid.querySelector('.course-card[data-id="'+dragId+'"]');
    if(src)src.classList.add('dragging');
    grid.querySelectorAll('.course-card').forEach(c=>{
      const r=c.getBoundingClientRect();
      if(e.clientY>=r.top&&e.clientY<=r.bottom&&c.dataset.id!==dragId){
        const after=(e.clientY-r.top)>(r.height/2);
        c.classList.toggle('drop-after',after); c.classList.toggle('drop-before',!after);
        if(after)c.after(src); else c.before(src);
      }else{c.classList.remove('drop-before','drop-after');}
    });
  }
  function onUp(){
    if(dragId&&dragging)commitOrder(orderIds());
    dragId=null; dragging=false; clear();
  }
  function commitOrder(order){
    const rank=new Map(order.map((id,i)=>[id,i]));
    S.courses.sort((a,b)=>rank.get(a.id)-rank.get(b.id));
    S.courses.forEach((c,i)=>{c.sort=i;});
    suppressClick=true; setTimeout(()=>suppressClick=false,0);
    dbPutMany('courses',S.courses).then(()=>{render();toast('已调整课程顺序','ok');});
  }
  grid.querySelectorAll('.course-card').forEach(card=>{
    card.classList.add('sortable');
    card.addEventListener('pointerdown',e=>{dragId=card.dataset.id;startY=e.clientY;dragging=false;document.addEventListener('pointermove',onMove);document.addEventListener('pointerup',onUp);});
    const orig=card.onclick;
    card.onclick=e=>{if(suppressClick){e.preventDefault();e.stopPropagation();return;}if(orig)orig(e);};
  });
}

let courseQuery='', courseSort='manual';

function viewCourses(main){
  const totalSec=S.sessions.reduce((s,x)=>s+x.sec,0);
  const allDone=S.episodes.filter(e=>e.status===2).length;
  main.innerHTML=
    viewHead('课程','共 '+S.courses.length+' 门课 · 已完成 '+allDone+' 集 · 累计 '+fmtDur(totalSec),
      '<div style="position:relative">'+I('search','')+'<input class="input" id="cq" placeholder="搜索课程…" style="padding-left:30px;width:170px" value="'+esc(courseQuery)+'"></div>'+
      '<select class="select" id="csort" style="width:auto"><option value="recent">最近学习</option><option value="created">创建顺序</option><option value="name">名称</option><option value="progress">进度</option><option value="manual">手动排序</option></select>'+
      '<button class="btn btn-primary" id="newCourse">'+I('plus')+' 新建课程</button>')+
    '<div class="course-grid" id="cgrid"></div>';
  main.querySelector('#newCourse').onclick=()=>courseForm(null);
  main.querySelector('#cq').oninput=e=>{courseQuery=e.target.value;drawList();};
  const sortSel=main.querySelector('#csort'); sortSel.value=courseSort;
  sortSel.onchange=e=>{courseSort=e.target.value;drawList();};
  function drawList(){
    let list=[...S.courses];
    if(courseQuery){const q=courseQuery.toLowerCase();list=list.filter(c=>(c.name+' '+(c.subject||'')+' '+(c.desc||'')).toLowerCase().includes(q));}
    if(courseSort!=='manual'){
      list.sort((a,b)=>{
        if(courseSort==='name')return a.name.localeCompare(b.name,'zh');
        if(courseSort==='progress')return courseProgress(b.id).pct-courseProgress(a.id).pct;
        if(courseSort==='created')return a.createdAt-b.createdAt;
        return (courseLastAt(b.id)||b.createdAt)-(courseLastAt(a.id)||a.createdAt);
      });
    }
    const grid=main.querySelector('#cgrid');
    if(!S.courses.length){grid.innerHTML='<div class="empty" style="grid-column:1/-1">'+I('book')+'<div class="empty-title">还没有课程</div><div>创建第一门课，开始整理你的网课分集与笔记</div><button class="btn btn-primary" id="emptyNew">'+I('plus')+' 新建课程</button></div>';
      grid.querySelector('#emptyNew').onclick=()=>courseForm(null);return;}
    if(!list.length){grid.innerHTML='<div class="empty" style="grid-column:1/-1"><div class="empty-title">没有匹配的课程</div></div>';return;}
    grid.innerHTML=list.map(c=>{
      const p=courseProgress(c.id), sec=courseSec(c.id), last=courseLastAt(c.id);
      return '<div class="card course-card" data-id="'+c.id+'">'+
        '<div class="cc-top"><div class="cc-logo" style="background:'+safeColor(c.color)+'">'+esc(courseInitial(c.name))+'</div>'+
        '<div style="flex:1;min-width:0"><div class="cc-name ellipsis">'+esc(c.name)+'</div>'+
        '<div class="cc-subj">'+esc(c.subject||'未分类')+'</div></div></div>'+
        '<div><div style="display:flex;justify-content:space-between;font-size:11.5px;color:var(--text-2);margin-bottom:6px"><span>'+p.done+' / '+p.total+' 集 · '+p.pct+'%</span><span>'+fmtDurShort(sec)+'</span></div>'+
        '<div class="progress thin"><i style="width:'+p.pct+'%;background:'+safeColor(c.color)+'"></i></div></div>'+
        '<div class="cc-foot"><span>'+(last?'上次学习 '+humanAgo(last):'尚未开始')+'</span><span class="dim">›</span></div></div>';
    }).join('');
    grid.querySelectorAll('.course-card').forEach(card=>{
      card.onclick=()=>{location.hash='#/course/'+card.dataset.id;};
    });
    if(courseSort==='manual')enableCourseDrag(grid);
  }
  drawList();
}

/* ================================================================
 * 分集模块
 * ================================================================ */

export { viewCourses };
