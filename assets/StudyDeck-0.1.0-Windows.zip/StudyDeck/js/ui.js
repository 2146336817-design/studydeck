import { I } from './icons.js';
import { S, saveSettings } from './db.js';
import { $, el, esc } from './core.js';

/** @param {any} msg @param {string} [type] */
function toast(msg,type){
  const w=$('#toastWrap'); const t=el('div','toast '+(type||''),esc(msg));
  /* 长提示（备份/恢复结果，可能带「几个附件数据缺失」的说明）多留一会儿 */
  const life=String(msg||'').length>34?6500:2200;
  w.appendChild(t); setTimeout(()=>{t.style.opacity='0';t.style.transition='opacity .3s';setTimeout(()=>t.remove(),300);},life);
}

/** @type {any[]} */
let modalStack=[];

/** @param {any} opt */
function openModal(opt){
  const mask=el('div','modal-mask');
  const m=el('div','modal '+(opt.wide?'wide':'')+' '+(opt.cls||''));
  m.innerHTML='<div class="modal-head"><div class="modal-title">'+esc(opt.title||'')+'</div><button class="icon-btn" data-close style="margin-left:auto">'+I('x')+'</button></div>';
  const body=el('div','modal-body');
  if(typeof opt.body==='string') body.innerHTML=opt.body; else if(opt.body) body.appendChild(opt.body);
  m.appendChild(body);
  if(opt.footer!==null){
    const foot=el('div','modal-foot');
    if(opt.footer) foot.appendChild(opt.footer);
    else {foot.innerHTML='<button class="btn" data-close>关闭</button>';}
    m.appendChild(foot);
  }
  mask.appendChild(m); modalStack.push(mask); $('#modalRoot').appendChild(mask);

  /* 关闭语义集中在一个地方，避免每条关闭路径各写一遍、漏掉清理：
     - dismissable:false 的弹窗（如 confirmDialog）不允许 Esc / 点遮罩关闭，
       否则调用方的 Promise 可能永远不 resolve，await 它的代码就永久挂起；
     - onClose 返回 false 表示「拒绝关闭」；
     - 无论从哪条路径关闭，都要摘掉 keydown 监听，否则会随弹窗数量累积。 */
  let closed=false;
  const teardown=()=>{
    document.removeEventListener('keydown',onKey);
    closed=true;
  };
  const requestClose=()=>{
    if(closed) return;
    if(opt.dismissable===false) return;
    if(opt.onClose && opt.onClose()===false) return;
    closeModal(mask);
  };
  const onKey=(/** @type {any} */ e)=>{ if(e.key==='Escape') requestClose(); };
  document.addEventListener('keydown',onKey);

  mask.addEventListener('mousedown',(/** @type {any} */ e)=>{ if(e.target===mask) requestClose(); });
  mask.querySelectorAll('[data-close]').forEach((/** @type {any} */ b)=>b.onclick=()=>requestClose());
  if(opt.after) opt.after(body,mask);
  /* 把清理函数挂在 mask 上：closeModal 拿到的是 mask。 */
  mask._teardown=teardown;
  /* 注意：close() 不过问 dismissable —— 程序化关闭（点「确定/取消」等）必须永远有效。 */
  return {close:()=>{ closeModal(mask); }, body, modal:m};
}

/** @param {any} target */
function closeModal(target){
  if(target){
    const i=modalStack.indexOf(target);
    if(i>=0){const m=modalStack.splice(i,1)[0]; if(m){ m.remove(); if(m._teardown)m._teardown(); }}
  } else {
    const m=modalStack.pop(); if(m){ m.remove(); if(m._teardown)m._teardown(); }
  }
}

/* 扫码登录 B 站：自动获取 SESSDATA（免手动复制） */

/** @type {number|null} */
let _qrTimer=null;

function _qrStop(){if(_qrTimer){clearInterval(_qrTimer);_qrTimer=null;}}

function scanSession(){
  if(!S.proxy){toast('请先启动本地服务（双击「启动课业（B站高清）.bat」）再扫码','err');return;}
  _qrStop();
  const md=openModal({
    title:'扫码登录 B 站',
    body:'<div id="qrBox" style="text-align:center;min-height:190px"><span class="tiny dim">正在生成二维码…</span></div>'+
         '<div id="qrState" class="tiny dim" style="text-align:center;margin-top:9px">用手机 B 站 App 右上角「扫一扫」扫码，并在手机上确认登录</div>',
    onClose:()=>{_qrStop();},
    after:(/** @type {any} */ body)=>{
      const _msk=body.closest('.modal-mask'); if(_msk){_msk.style.animation='none';_msk.style.opacity='1';}
      fetch('/api/bili/qrgen').then(r=>r.json()).then(d=>{
        if(d.code!==0||!d.svg){
          const st=body.querySelector('#qrState'); if(st)st.textContent='生成二维码失败：'+(d.message||'');
          return;
        }
        const qb=body.querySelector('#qrBox'); if(qb)qb.innerHTML=d.svg;
        const qsvg=qb?qb.querySelector('svg'):null; if(qsvg){qsvg.style.width='180px';qsvg.style.height='180px';}
        const key=d.key;
        const tick=()=>{
          fetch('/api/bili/qrpoll?key='+encodeURIComponent(key)).then(r=>r.json()).then(p=>{
            const st=body.querySelector('#qrState'); if(!st)return;
            if(p.code===0&&p.sessdata){
              st.textContent='登录成功，已自动保存 ✓';
              toast('登录成功。本文件夹含 B 站凭证（sessdata.txt），分享/上传前请先删除','err');
              S.settings.sessdata=p.sessdata; saveSettings();
              const inp=/** @type {any} */ (document.querySelector('#setSess')); if(inp)inp.value=p.sessdata;
              const ss=document.querySelector('#sessState'); if(ss)ss.textContent='已自动获取并保存（'+p.sessdata.slice(0,6)+'…）';
              toast('已自动获取 SESSDATA 并保存','ok');
              _qrStop(); md.close(); return;
            }
            const sc=(p.scan!==undefined)?p.scan:p.code;
            if(sc===86038){st.textContent='二维码已失效，请关闭弹窗后重新点「扫码获取」'; _qrStop(); return;}
            if(sc===86090)st.textContent='已扫码，请在手机上确认登录…';
            else if(sc===86101)st.textContent='等待扫码…';
            else st.textContent='登录处理中（'+(p.message||('code '+sc))+'）…';
          }).catch(()=>{const st=body.querySelector('#qrState');if(st)st.textContent='无法连接本地服务，请确认 bat 已启动';_qrStop();});
        };
        tick(); _qrTimer=setInterval(tick,2000);
      }).catch(()=>{const st=body.querySelector('#qrState');if(st)st.textContent='无法连接本地服务';});
    }
  });
}

/** @param {string} title @param {string} msg @param {string} [dangerText] */
function confirmDialog(title, msg, dangerText){
  return new Promise(resolve=>{
    const foot=document.createDocumentFragment();
    const cancel=el('button','btn','取消'); cancel.type='button';
    const ok=el('button','btn '+(dangerText?'btn-danger':'btn-primary'),dangerText||'确定'); ok.type='button';
    foot.append(cancel,ok);
    const md=openModal({title,body:'<p class="confirm-msg" style="color:var(--text-2);line-height:1.7">'+esc(msg||'')+'</p>',footer:foot,dismissable:false});
    cancel.onclick=()=>{md.close();resolve(false);};
    ok.onclick=()=>{md.close();resolve(true);};
  });
}

/* ============ 导航 / 路由 ============ */

export { confirmDialog, openModal, scanSession, toast };
