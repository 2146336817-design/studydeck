import { I } from './icons.js';
import { S, calcStreak, courseOf, courseProgress, dbPut, epsOf, kvSet, learnedBetween, learnedByDay, loadAll } from './db.js';
import { openModal, toast } from './ui.js';
import { $, courseInitial, dateKey, el, epSec, esc, fmtDur, fmtDurShort, humanAgo, safeColor, todayKey, uid } from './util.js';
import { render } from './viewkit.js';
import { Player, noteForm } from './player.js';
/* 这几个函数住在 task-utils.js，**不要**从 views-task.js（桶文件）绕一圈：
   views-task → views-stats → views-home → views-task 会形成 import 环。
   直接从真正定义它们的模块取，依赖图就是干净的 DAG。 */
import { dayItems, logOn, repText, toggleDay } from './task-utils.js';

function lastNDays(n){const arr=[];const d=new Date();d.setHours(0,0,0,0);
  for(let i=n-1;i>=0;i--){const x=new Date(d);x.setDate(d.getDate()-i);arr.push(x);}return arr;}

function heatLevel(sec){if(!sec)return 0;if(sec<900)return 1;if(sec<1800)return 2;if(sec<3600)return 3;return 4;}

function bars30(){
  const byDay=learnedByDay(); const days=lastNDays(30);
  const vals=days.map(d=>byDay[dateKey(d.getTime())]||0);
  const max=Math.max(...vals,600);
  const tk=todayKey();
  return '<div class="bar-chart">'+days.map((d,i)=>{
    const v=vals[i], h=v?Math.max(4,Math.round(v/max*120)):0;
    const key=dateKey(d.getTime());
    return '<div class="bar '+(v?'':'zero')+' '+(key===tk?'today':'')+'" style="height:'+(v?h:3)+'px" title="'+(d.getMonth()+1)+'/'+d.getDate()+'：'+fmtDur(v)+'"><span class="bar-tip">'+(d.getMonth()+1)+'/'+d.getDate()+' '+fmtDur(v)+'</span></div>';
  }).join('')+'</div><div class="chart-axis"><span>30 天前</span><span>今天</span></div>';
}

function heatmap(weeksN){
  const byDay=learnedByDay();
  const today=new Date();today.setHours(0,0,0,0);
  const start=new Date(today);start.setDate(start.getDate()-(weeksN*7-1));
  start.setDate(start.getDate()-start.getDay()); // 对齐到周日
  const cells=[];const d=new Date(start);
  while(d<=today){const sec=byDay[dateKey(d.getTime())]||0;
    cells.push('<div class="heat l'+heatLevel(sec)+'" title="'+(d.getMonth()+1)+'/'+d.getDate()+' '+fmtDur(sec)+'"></div>');
    d.setDate(d.getDate()+1);}
  return '<div class="heatmap" style="grid-template-rows:repeat(7,1fr);grid-auto-columns:12px">'+cells.join('')+'</div>';
}

function greet(){const h=new Date().getHours();return h<5?'夜深了':h<11?'早上好':h<14?'中午好':h<18?'下午好':'晚上好';}

function gaoKaoInfo(){
  const now=new Date();let y=now.getFullYear();
  let target=null;
  const m=String(S.settings.countdownDate||'').trim().match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
  if(m)target=new Date(+m[1],+m[2]-1,+m[3],9,0,0);
  let d=target||new Date(y,5,7,9,0,0);
  if(d.getTime()<=now.getTime()){
    if(target){target=new Date(target.getFullYear()+1,target.getMonth(),target.getDate(),9,0,0);d=target;}
    else{d=new Date(y+1,5,7,9,0,0);}
  }
  const days=Math.ceil((d.getTime()-now.getTime())/86400000);
  const word=days>300?'从容备考，功不唐捐':days>100?'稳住节奏，每天进一步':days>30?'查漏补缺，冲刺提分':'最后关头，全力以赴';
  return{y:d.getFullYear(),days,word,label:target?'倒计时':'高考倒计时',month:d.getMonth()+1,day:d.getDate()};
}

function viewDashboard(main){
  const todaySec=learnedBetween(new Date().setHours(0,0,0,0),Date.now());
  const totalSec=S.sessions.reduce((s,x)=>s+x.sec,0);
  const done=S.episodes.filter(e=>e.status===2).length, total=S.episodes.length;
  const streak=calcStreak(); const goal=S.settings.dailyGoal*60;
  const pct=goal?Math.min(100,Math.round(todaySec/goal*100)):0;
  const C=2*Math.PI*40;
  // 继续学习：最近 session 的分集去重
  const seen=new Set(), cont=[];
  for(const s of S.sessions){const ep=S.episodes.find(e=>e.id===s.epId);
    if(ep&&ep.status!==2&&!seen.has(ep.id)){seen.add(ep.id);cont.push(ep);if(cont.length>=4)break;}}
  const recentNotes=[...S.notes].sort((a,b)=>b.updatedAt-a.updatedAt).slice(0,3);
  main.innerHTML=
    '<div class="view-head"><div><div class="view-title">'+greet()+'，今天想学点什么？</div><div class="view-desc">'+
      (new Date().getMonth()+1)+' 月 '+new Date().getDate()+' 日 · 星期'+'日一二三四五六'[new Date().getDay()]+' · 连续学习 '+streak+' 天</div></div></div>'+
    '<div class="stat-grid">'+
      statCard('clock','今日学习',fmtDur(todaySec),'目标 '+S.settings.dailyGoal+' 分钟 · 达成 '+pct+'%')+
      statCard('flame','连续打卡',streak+'<span class="stat-unit">天</span>',streak?'保持节奏，别断签':'今天开始第一天')+
      statCard('chart','累计学习',fmtDur(totalSec),'共 '+S.sessions.length+' 次学习记录')+
      statCard('check','总体进度',done+'<span class="stat-unit">/ '+total+' 集</span>',total?('完成率 '+Math.round(done/total*100)+'%'):'添加分集后显示')+
    '</div>'+
    '<div class="dash-grid"><div>'+
      '<div class="card card-pad" style="margin-bottom:14px"><div class="section-title">'+I('chart')+' 近 30 天学习时长 <a class="more" href="#/stats">详细统计 ›</a></div>'+bars30()+'</div>'+
      '<div class="card card-pad"><div class="section-title">'+I('book')+' 课程进度</div><div id="dashCourses"></div></div>'+
    '</div><div>'+
      gaoKaoCard()+
      '<div class="card card-pad" style="margin-bottom:14px"><div class="section-title">'+I('target')+' 今日目标</div>'+
        '<div class="ring-wrap"><svg class="ring" viewBox="0 0 96 96"><circle class="ring-bg" cx="48" cy="48" r="40"/><circle class="ring-fg" cx="48" cy="48" r="40" stroke-dasharray="'+C.toFixed(1)+'" stroke-dashoffset="'+(C*(1-pct/100)).toFixed(1)+'"/><g class="ring-center"><text class="ring-num" x="48" y="52" text-anchor="middle" fill="var(--text)">'+pct+'%</text></g></svg>'+
        '<div><div style="font-weight:650">'+fmtDur(todaySec)+'</div><div class="tiny dim" style="margin-top:3px">目标 '+fmtDur(goal)+'</div><button class="btn btn-sm" id="goalEdit" style="margin-top:8px">调整目标</button></div></div></div>'+
      '<div class="card card-pad" style="margin-bottom:14px"><div class="section-title">'+I('play')+' 继续学习</div><div class="mini-list" id="contList"></div></div>'+
      '<div class="card card-pad" style="margin-bottom:14px"><div class="section-title">'+I('note')+' 最近笔记 <a class="more" href="#/notes">全部 ›</a></div><div class="mini-list" id="noteList"></div></div>'+
      '<div class="card card-pad" id="dashMkCard"></div>'+
      '<div class="card card-pad" id="dashTaskCard"></div>'+
    '</div></div>';
  main.querySelector('#goalEdit').onclick=goalForm;
  // 课程进度
  const cc=main.querySelector('#dashCourses');
  if(!S.courses.length){cc.innerHTML='<a href="#/courses" class="small" style="padding:6px 0;display:block">还没有课程，去「课程」页创建第一门课 ›</a>';}
  else cc.innerHTML=S.courses.slice(0,6).map(c=>{const p=courseProgress(c.id);
    return '<div class="mini-item" data-id="'+c.id+'"><div class="mini-dot" style="background:'+safeColor(c.color)+'">'+esc(courseInitial(c.name))+'</div>'+
      '<div class="mini-main"><div class="mini-title ellipsis">'+esc(c.name)+'</div><div class="progress thin" style="margin-top:5px"><i style="width:'+p.pct+'%;background:'+safeColor(c.color)+'"></i></div></div>'+
      '<div class="mini-right">'+p.done+'/'+p.total+'<br>'+p.pct+'%</div></div>';}).join('');
  cc.querySelectorAll('.mini-item').forEach(it=>it.onclick=()=>location.hash='#/course/'+it.dataset.id);
  // 继续学习
  const cl=main.querySelector('#contList');
  cl.innerHTML=cont.length?cont.map(ep=>{const c=courseOf(ep.courseId);
    return '<div class="mini-item" data-id="'+ep.id+'"><div class="mini-dot" style="background:'+safeColor(c&&c.color)+'">'+I('play')+'</div>'+
      '<div class="mini-main"><div class="mini-title ellipsis">'+esc(ep.title)+'</div><div class="mini-meta">'+esc(c?c.name:'')+' · 已学 '+fmtDurShort(epSec(ep.id))+'</div></div>'+
      '<div class="mini-right">继续 ›</div></div>';}).join(''):'<div class="small dim">没有进行中的分集</div>';
  cl.querySelectorAll('.mini-item').forEach(it=>it.onclick=()=>Player.open(it.dataset.id));
  // 最近笔记
  const nl=main.querySelector('#noteList');
  nl.innerHTML=recentNotes.length?recentNotes.map(n=>{const c=courseOf(n.courseId);
    return '<div class="mini-item" data-id="'+n.id+'"><div class="mini-dot" style="background:'+safeColor(c&&c.color)+'">'+I('note')+'</div>'+
      '<div class="mini-main"><div class="mini-title ellipsis">'+esc(n.title)+'</div><div class="mini-meta">'+esc(c?c.name:'')+' · '+humanAgo(n.updatedAt)+'</div></div></div>';}).join(''):'<div class="small dim">还没有笔记</div>';
  nl.querySelectorAll('.mini-item').forEach(it=>it.onclick=()=>{location.hash='#/notes';setTimeout(()=>noteForm({note:S.notes.find(n=>n.id===it.dataset.id)}),80);});
  // 错题待复习
  const mc=main.querySelector('#dashMkCard');
  const mk0=S.mistakes.filter(m=>m.status===0).length,mk1=S.mistakes.filter(m=>m.status===1).length,mk2=S.mistakes.filter(m=>m.status===2).length;
  mc.innerHTML='<div class="section-title">'+I('target')+' 错题本 <a class="more" href="#/mistakes">全部 ›</a></div>'+
    (S.mistakes.length?
      ('<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px">'+
        '<span class="pill" style="background:rgba(179,65,47,.12);color:#b3412f">待复习 '+mk0+'</span>'+
        '<span class="pill" style="background:rgba(192,138,38,.13);color:#9a6d12">复习中 '+mk1+'</span>'+
        '<span class="pill pill-ok">已掌握 '+mk2+'</span></div>'+
       '<button class="btn btn-sm btn-primary" id="dashMkAdd">'+I('plus')+' 收录错题</button>')
      :'<div class="small dim" style="margin-bottom:10px">还没有错题，拍照即可收录，按章节和知识点归类</div><button class="btn btn-sm btn-primary" id="dashMkAdd">'+I('plus')+' 收录第一道错题</button>');
  mc.querySelector('#dashMkAdd').onclick=()=>location.hash='#/mistakes';
  if(S.mistakes.length)mc.onclick=e=>{if(!e.target.closest('button'))location.hash='#/mistakes';};
  // 今日任务
  const tc=main.querySelector('#dashTaskCard');
  const titems=dayItems(todayKey()),tdone=titems.filter(x=>x.done).length,tleft=titems.filter(x=>!x.done);
  tc.innerHTML='<div class="section-title">'+I('calendar')+' 今日任务 <a class="more" href="#/tasks">全部 ›</a></div>'+
    (titems.length?('<div class="small dim" style="margin-bottom:9px">'+tdone+' / '+titems.length+' 已完成'+(tleft.length?'，还剩 '+tleft.length+' 项':'，全部完成')+'</div>'):'<div class="small dim" style="margin-bottom:9px">今天还没有安排任务</div>');
  if(titems.length){
    tc.insertAdjacentHTML('beforeend','<div class="mini-list" id="dashTaskList"></div>');
    const tl=tc.querySelector('#dashTaskList');
    tl.innerHTML=titems.slice(0,5).map(it=>'<div class="mini-item" data-id="'+it.t.id+'"><div class="t-check '+(it.done?'done':'')+'" style="margin-top:0" data-tc="'+it.t.id+'">'+I('check')+'</div>'+
      '<div class="mini-main"><div class="mini-title ellipsis '+(it.done?'done':'')+'" style="'+(it.done?'text-decoration:line-through;color:var(--text-3)':'')+'">'+esc(it.t.title)+'</div>'+
      '<div class="mini-meta">'+(it.t.time?esc(it.t.time)+' · ':'')+esc(it.t.cat||'')+(it.tpl?' · '+repText(it.t):'')+'</div></div></div>').join('')+
      (titems.length>5?'<div class="small dim" style="padding-left:30px">还有 '+(titems.length-5)+' 项…</div>':'');
    tl.querySelectorAll('[data-tc]').forEach(b=>b.onclick=async e=>{e.stopPropagation();const t0=S.tasks.find(x=>x.id===b.dataset.tc);await toggleDay({t:t0,tpl:t0.kind==='tpl',done:t0.kind==='tpl'?logOn(t0.id,todayKey()):t0.done},todayKey());render();});
    tl.querySelectorAll('.mini-item').forEach(r=>r.onclick=e=>{if(!e.target.closest('[data-tc]'))location.hash='#/tasks';});
  }
  tc.insertAdjacentHTML('beforeend','<button class="btn btn-sm btn-primary" id="dashTaskAdd" style="margin-top:9px">'+I('plus')+' 添加任务</button>');
  tc.querySelector('#dashTaskAdd').onclick=()=>location.hash='#/tasks';
}

function gaoKaoCard(){
  if(!S.settings.showCountdown)return '';
  const gk=gaoKaoInfo();
  return '<div class="card card-pad" style="margin-bottom:14px;background:linear-gradient(135deg,#0f6b54,#0b4d3e);color:#fff;border:none">'+
    '<div class="tiny" style="color:rgba(255,255,255,.72);font-weight:600;letter-spacing:.5px">'+gk.label+' · '+gk.y+' 年 '+gk.month+' 月 '+gk.day+' 日</div>'+
    '<div style="display:flex;align-items:baseline;gap:8px;margin:8px 0 4px"><span style="font-size:38px;font-weight:750;line-height:1">'+gk.days+'</span><span style="font-size:14px;color:rgba(255,255,255,.85)">天</span></div>'+
    '<div class="tiny" style="color:rgba(255,255,255,.78)">'+gk.word+'</div></div>';
}

function statCard(icon,label,valueHtml,sub){
  return '<div class="card stat-card"><div class="stat-label">'+I(icon)+label+'</div><div class="stat-value">'+valueHtml+'</div><div class="stat-sub">'+esc(sub)+'</div></div>';
}

function goalForm(){
  const wrap=el('div');
  wrap.innerHTML='<div class="field"><label class="field-label">每日学习目标（分钟）</label><input class="input" id="goalMin" type="number" min="5" step="5" value="'+S.settings.dailyGoal+'"></div>';
  const foot=document.createDocumentFragment();
  const cancel=el('button','btn','取消');const ok=el('button','btn btn-primary','保存');
  foot.append(cancel,ok);
  const md=openModal({title:'每日目标',body:wrap,footer:foot});
  cancel.onclick=()=>md.close();
  ok.onclick=async()=>{const v=+wrap.querySelector('#goalMin').value;if(!(v>=1)){toast('请输入有效分钟数','err');return;}
    S.settings.dailyGoal=v;await kvSet('settings',S.settings);md.close();render();toast('目标已更新','ok');};
}

/* 补记学习时长 */

function manualLogForm(){
  if(!S.courses.length){toast('请先创建课程','err');return;}
  const wrap=el('div');
  wrap.innerHTML=
    '<div class="field"><label class="field-label">课程</label><select class="select" id="mlCourse">'+S.courses.map(c=>'<option value="'+c.id+'">'+esc(c.name)+'</option>').join('')+'</select></div>'+
    '<div class="field"><label class="field-label">分集</label><select class="select" id="mlEp"></select></div>'+
    '<div class="form-row"><div class="field"><label class="field-label">学习时长（分钟）</label><input class="input" id="mlMin" type="number" min="1" value="30"></div>'+
    '<div class="field"><label class="field-label">发生时间</label><input class="input" id="mlWhen" type="datetime-local"></div></div>';
  const cSel=wrap.querySelector('#mlCourse'), eSel=wrap.querySelector('#mlEp');
  function fillEps(){const eps=epsOf(cSel.value);eSel.innerHTML=eps.map(e=>'<option value="'+e.id+'">第 '+(e.order+1)+' 集 · '+esc(e.title)+'</option>').join('')||'<option value="">（该课程暂无分集）</option>';}
  cSel.onchange=fillEps;fillEps();
  const now=new Date();now.setMinutes(now.getMinutes()-now.getTimezoneOffset());
  wrap.querySelector('#mlWhen').value=now.toISOString().slice(0,16);
  const foot=document.createDocumentFragment();
  const cancel=el('button','btn','取消');const ok=el('button','btn btn-primary','补记');foot.append(cancel,ok);
  const md=openModal({title:'补记学习时长',body:wrap,footer:foot});
  cancel.onclick=()=>md.close();
  ok.onclick=async()=>{
    const epId=eSel.value;if(!epId){toast('请先为课程添加分集','err');return;}
    const min=+wrap.querySelector('#mlMin').value;if(!(min>0)){toast('时长无效','err');return;}
    const when=new Date(wrap.querySelector('#mlWhen').value).getTime()||Date.now();
    const s={id:uid(),courseId:cSel.value,epId,start:when-min*60000,end:when,sec:min*60,kind:'manual'};
    await dbPut('sessions',s);await loadAll();md.close();render();toast('已补记 '+min+' 分钟','ok');
  };
}

export { bars30, heatmap, manualLogForm, statCard, viewDashboard };
