// @ts-check
// 依赖状态 / 数据层 / 弹窗的工具函数。
//
// 纯函数（不碰 S、不碰 db、不碰 ui）已经搬到 core.js —— 那是依赖图的叶子。
// 这样 db.js 与 ui.js 只需要依赖 core.js，db ⇄ util 与 util ⇄ ui 两个环就断了。
// 这里仍然把 core 的符号**再导出**一次，视图层无需改动。
import { S, dbGet, epsOf } from './db.js';
import { openModal, toast } from './ui.js';
import {
  $, $$, el, esc, uid, clamp, pad2, dateKey, todayKey, fmtTime, fmtDur, fmtDurShort,
  fmtDateTime, fmtDay, daysBetween, humanAgo, fmtSize, downloadBlob, hostOf, parseBili,
  parseCollection, biliEmbed, SRC_LABEL, COURSE_COLORS, safeColor, courseInitial, STATUS_LABEL,
  MK_STATUS, mkStatusOf, MISSING_ATT_TAG, blobsHave, isMissingAtt, ensurePersistentStorage,
  storageInfo, renderStorageInfo, SECRET_SETTINGS
} from './core.js';

/** @param {any} b @returns {Promise<any>} */
async function biliMeta(b){
  if(!b)return null;
  const q=b.bvid?('bvid='+b.bvid):('aid='+b.avid);
  let r;
  try{r=await fetch('/api/bili/meta?'+q,{headers:{'X-Sessdata':S.settings.sessdata||''}});}catch(e){throw new Error('本地服务连接失败');}
  if(!r.ok)throw new Error('本地服务无响应（HTTP '+r.status+'）');
  const j=await r.json();
  if(j.code!==0)throw new Error(j.message||('接口返回码 '+j.code));
  return j.data||null;
}
/** @param {string} cid @returns {number} 该课程累计学习秒数 */
function courseSec(cid){return S.sessions.reduce((s,x)=>x.courseId===cid?s+(x.sec||0):s,0);}
/** @param {string} cid @returns {number} 该课程最近一次学习时间 */
function courseLastAt(cid){let t=0; S.sessions.forEach(s=>{if(s.courseId===cid&&(s.end||s.start||0)>t)t=s.end||s.start||0;});return t;}
/** @param {string} epid @returns {number} */
const epSec=epid=> S.sessions.reduce((s,x)=>x.epId===epid?s+(x.sec||0):s,0);
/** @param {string} epid @returns {number} */
const epLastAt=epid=>{let t=0;S.sessions.forEach(s=>{if(s.epId===epid&&(s.end||s.start||0)>t)t=s.end||s.start||0;});return t;};
/** 该分集在课程内的序号（1 起）；不在列表里则 null。
 *  @param {import('./types.js').Episode} ep @returns {number|null} */
const epNumberOf=ep=>{const list=epsOf(ep.courseId);const i=list.findIndex(x=>x.id===ep.id);return i>=0?i+1:null;};
/** @param {any} src @returns {string} */
function md2html(src){
  if(!src)return '';
  let s=esc(src); const code=/** @type {string[]} */ ([]);
  s=s.replace(/```([\s\S]*?)```/g,(m,c)=>{code.push('<pre><code>'+c.replace(/^\n/,'').replace(/\n$/,'')+'</code></pre>');return '\0B'+(code.length-1)+'\0';});
  s=s.replace(/`([^`\n]+)`/g,(m,c)=>{code.push('<code>'+c+'</code>');return '\0I'+(code.length-1)+'\0';});
  const lines=s.split('\n'), out=[]; let inList=false, /** @type {string|null} */ listType=null, inQuote=false;
  const closeList=()=>{if(inList){out.push(listType==='ul'?'</ul>':'</ol>');inList=false;}};
  const closeQuote=()=>{if(inQuote){out.push('</blockquote>');inQuote=false;}};
  for(let ln of lines){
    let m;
    if(m=ln.match(/^(#{1,3})\s+(.*)/)){closeList();closeQuote();out.push('<h'+m[1].length+'>'+m[2]+'</h'+m[1].length+'>');continue;}
    if(m=ln.match(/^\s*[-*]\s+(.*)/)){closeQuote();if(!inList||listType!=='ul'){closeList();out.push('<ul>');inList=true;listType='ul';}out.push('<li>'+m[1]+'</li>');continue;}
    if(m=ln.match(/^\s*\d+\.\s+(.*)/)){closeQuote();if(!inList||listType!=='ol'){closeList();out.push('<ol>');inList=true;listType='ol';}out.push('<li>'+m[1]+'</li>');continue;}
    if(m=ln.match(/^>\s?(.*)/)){closeList();if(!inQuote){out.push('<blockquote>');inQuote=true;}out.push('<p>'+m[1]+'</p>');continue;}
    if(!ln.trim()){closeList();closeQuote();continue;}
    closeList();closeQuote();out.push('<p>'+ln+'</p>');
  }
  closeList();closeQuote();
  let h=out.join('\n');
  h=h.replace(/\*\*([^*]+)\*\*/g,'<strong>$1</strong>').replace(/\*([^*]+)\*/g,'<em>$1</em>');
  h=h.replace(/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/g,'<a href="$2" target="_blank" rel="noopener">$1</a>');
  h=h.replace(/\0([BI])(\d+)\0/g,(_,t,i)=>code[+i]);
  return h;
}
/** @param {string[]} epIds @param {string} cid @returns {string} */
function rangeText(epIds,cid){
  if(!epIds||!epIds.length)return '整个课程';
  const eps=epsOf(cid); const nums=epIds.map(id=>eps.findIndex(x=>x.id===id)+1).filter(x=>x>0).sort((a,b)=>a-b);
  if(!nums.length)return '关联分集';
  const ranges=[];let st=nums[0],prev=st;
  for(let i=1;i<=nums.length;i++){const n=nums[i];
    if(n===prev+1){prev=n;continue;}
    ranges.push(st===prev?(''+st):(st+'-'+prev));st=prev=n;}
  return '第 '+ranges.join('、')+' 集';
}
/** @param {import('./types.js').Attachment} att @returns {Promise<void>} */
async function openAttachment(att){
  const rec=await dbGet('blobs',att.id); if(!rec||!rec.blob){toast('附件数据缺失：'+(att.name||'')+'（该附件在备份时因超过 15MB 被跳过，或尚未保存到本机）','err');return;}
  const url=URL.createObjectURL(rec.blob);
  /* type/name 可能缺失（来自手工改过或旧版本的备份）：缺 type 时按图片以外的通用分支处理，
     不能让 att.type.startsWith 直接抛异常。 */
  const type=att.type||'application/octet-stream';
  const name=att.name||'附件';
  if(type.startsWith('image/')){
    const md=openModal({title:name,body:'<div style="text-align:center"><img src="'+url+'" style="max-width:100%;border-radius:8px"></div>',footer:null});
    md.modal.querySelector('.modal-head').style.cursor='pointer';
    setTimeout(()=>URL.revokeObjectURL(url),60000);
  }else if(type==='application/pdf'||/\.pdf$/i.test(name)){
    openModal({title:name,body:'<iframe src="'+url+'" style="width:100%;height:70vh;border:none;border-radius:8px"></iframe>',footer:null,wide:true});
    setTimeout(()=>URL.revokeObjectURL(url),120000);
  }else{
    const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),4000);
  }
}
/** @param {string} id @returns {import('./types.js').Attachment[]} */
const attsOfMk=id=>S.attachments.filter(a=>a.noteId===id).sort((a,b)=>(a.createdAt||0)-(b.createdAt||0));
/** 备份指纹：任一维度变化就触发一次备份。
 *  @returns {string} */
function dataSig(){
  /** @param {any[]} arr @param {(x:any)=>any} f @returns {number} */
  const mx=(arr,f)=>{let m=0;for(const x of arr){const v=f(x)||0;if(v>m)m=v;}return m;};
  /* 附件指纹直接现算：附件数量级很小，省掉一层容易失去同步的缓存。 */
  const blobSig=[...S.attachments].sort((x,y)=>x.id<y.id?-1:1).map(a=>a.id+':'+(a.size||0)+':'+(a.lastModified||0)).join('|');
  return JSON.stringify([
    S.courses.length,mx(S.courses,c=>Math.max(c.sort||0,c.createdAt||0,c.updatedAt||0)),
    S.episodes.length,mx(S.episodes,e=>Math.max(e.order||0,e.completedAt||0,e.updatedAt||0)),
    S.notes.length,mx(S.notes,n=>n.updatedAt),
    S.attachments.length,S.attachments.reduce((s,a)=>s+(a.size||0),0),blobSig,
    S.mistakes.length,mx(S.mistakes,m=>m.updatedAt),
    S.tasks.length,mx(S.tasks,t=>Math.max(t.updatedAt||0,t.doneAt||0)),S.tasklog.length,
    S.resources.length,mx(S.resources,r=>Math.max(r.createdAt||0,r.updatedAt||0)),S.resources.reduce((s,r)=>s+((r.files&&r.files.length)||r.fileCount||0),0),
    S.sessions.length,mx(S.sessions,x=>x.end||x.start),
    JSON.stringify(S.settings,(k,v)=>SECRET_SETTINGS.includes(k)?'':v)]);
}

/* 附件数据缺失标记：备份时超过 15MB 的附件会被跳过，恢复后只剩文件元数据。 */
/** @param {any} r @returns {number} */
const countMissingInFolder=r=>((r&&r.files)||[]).filter((/** @type {any} */ x)=>!blobsHave.has(x.id)).length;

/* 备份指纹：任一维度变化就触发一次备份。
   注意 episodes 必须在列：旧版漏了它，导致「导入整季课程 / 添加分集 / 排序 / 标记完成」不触发备份。 */
/* 说明：这里曾经有一套「_blobSigMap 缓存 + markDataDirty 脏标记」机制，
   但它从未接上（没有任何调用方），_blobSigMap 只写不读。已删除。
   dataSig() 现在直接依据 S.attachments 现算，行为等价且不会失去同步。 */
/* S4：持久化存储 + 占用/配额显示 */


/* 把 core.js 的纯工具**再导出**一次：视图层不必改 import 来源。 */
export {
  $, $$, el, esc, uid, clamp, pad2, dateKey, todayKey, fmtTime, fmtDur, fmtDurShort,
  fmtDateTime, fmtDay, daysBetween, humanAgo, fmtSize, downloadBlob, hostOf, parseBili,
  parseCollection, biliEmbed, SRC_LABEL, COURSE_COLORS, safeColor, courseInitial, STATUS_LABEL,
  MK_STATUS, mkStatusOf, MISSING_ATT_TAG, blobsHave, isMissingAtt, ensurePersistentStorage,
  storageInfo, renderStorageInfo,
} from './core.js';

/* 本文件自己定义的那些（依赖 S / db / ui），注意**不能**写成 `from './core.js'`。 */
export { attsOfMk, biliMeta, countMissingInFolder, courseLastAt, courseSec, dataSig,
  epLastAt, epNumberOf, epSec, md2html, openAttachment, rangeText };
