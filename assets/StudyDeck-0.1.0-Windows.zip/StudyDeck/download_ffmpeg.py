# -*- coding: utf-8 -*-
"""下载 ffmpeg Windows 构建，解压后把 ffmpeg.exe 放到程序目录。
自动检测并使用系统代理（Clash / v2ray 等）。"""
import os, sys, io, zipfile, urllib.request, shutil, time

HERE = os.path.dirname(os.path.abspath(__file__))
TARGET = os.path.join(HERE, "ffmpeg.exe")
URL = "https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip"
TMPZIP = os.path.join(HERE, "_ffmpeg_download.zip")
TMPDIR = os.path.join(HERE, "_ffmpeg_extract")

def log(msg):
    print(msg, flush=True)

def get_system_proxy():
    """从 Windows 注册表读取系统代理（Clash/v2ray 等设置的 127.0.0.1:port）。"""
    try:
        import winreg
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                             r"Software\Microsoft\Windows\CurrentVersion\Internet Settings")
        enable, _ = winreg.QueryValueEx(key, "ProxyEnable")
        if not enable:
            return None
        server, _ = winreg.QueryValueEx(key, "ProxyServer")
        winreg.CloseKey(key)
        if server:
            return "http://" + server
    except Exception:
        pass
    return None

# 配置代理（系统代理或环境变量）
_proxy = get_system_proxy() or os.environ.get("HTTPS_PROXY") or os.environ.get("HTTP_PROXY")
if _proxy:
    os.environ["HTTPS_PROXY"] = _proxy
    os.environ["HTTP_PROXY"] = _proxy
    proxy_handler = urllib.request.ProxyHandler({"https": _proxy, "http": _proxy})
    opener = urllib.request.build_opener(proxy_handler)
    urllib.request.install_opener(opener)
    log("使用代理: %s" % _proxy)

if os.path.isfile(TARGET):
    log("ffmpeg.exe 已存在，跳过下载")
    sys.exit(0)

log("开始下载 ffmpeg（约 80MB）…")
try:
    req = urllib.request.Request(URL, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=120) as r, open(TMPZIP, "wb") as f:
        total = int(r.headers.get("Content-Length", 0))
        done = 0
        last = time.time()
        while True:
            chunk = r.read(1024 * 256)
            if not chunk:
                break
            f.write(chunk)
            done += len(chunk)
            now = time.time()
            if now - last > 3:
                pct = (done * 100 // total) if total else 0
                log("  下载中 %d%% (%d MB)" % (pct, done // 1048576))
                last = now
    log("下载完成 (%d MB)" % (os.path.getsize(TMPZIP) // 1048576))
except Exception as e:
    log("下载失败: %s" % e)
    if os.path.exists(TMPZIP):
        os.remove(TMPZIP)
    sys.exit(1)

log("解压中…")
try:
    if os.path.exists(TMPDIR):
        shutil.rmtree(TMPDIR, ignore_errors=True)
    os.makedirs(TMPDIR, exist_ok=True)
    with zipfile.ZipFile(TMPZIP, "r") as z:
        z.extractall(TMPDIR)
    # 找到 ffmpeg.exe
    found = None
    for root, dirs, files in os.walk(TMPDIR):
        if "ffmpeg.exe" in files:
            found = os.path.join(root, "ffmpeg.exe")
            break
    if not found:
        log("错误：解压后未找到 ffmpeg.exe")
        sys.exit(1)
    shutil.copy2(found, TARGET)
    log("已复制 ffmpeg.exe 到程序目录")
    # 清理
    os.remove(TMPZIP)
    shutil.rmtree(TMPDIR, ignore_errors=True)
    log("清理临时文件完成")
    log("ffmpeg 安装成功：%s" % TARGET)
except Exception as e:
    log("解压失败: %s" % e)
    sys.exit(1)
