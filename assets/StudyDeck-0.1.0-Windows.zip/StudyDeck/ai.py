# -*- coding: utf-8 -*-
"""
课业 · AI 模块（零依赖，Python 3.8+）
提供：大模型对话（OpenAI 兼容接口）、B 站 CC 字幕获取、AI 笔记生成、错题解析。

设计原则：
  · 用户自带 API Key，默认 DeepSeek（中文好、便宜，约 1 元/百万 tokens）
  · 兼容任何 OpenAI 格式接口（DeepSeek / 智谱 / 月之暗面 / 本地 Ollama 等）
  · 只用 Python 标准库（urllib），不引入 requests 等第三方依赖
  · 所有函数纯函数化，不读写全局状态，方便测试

被 server.py 导入并注册为 /api/ai/* 路由。
"""
import json
import re
import time
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError
from urllib.parse import urlparse

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36")
BILI_API = "https://api.bilibili.com"

# 默认配置（前端可覆盖）
DEFAULT_BASE_URL = "https://api.deepseek.com"
DEFAULT_MODEL = "deepseek-chat"


# ================================================================
# 大模型对话（OpenAI 兼容）
# ================================================================

def llm_chat(api_key, base_url, model, messages, timeout=120, temperature=0.7):
    """调用 OpenAI 兼容的 /chat/completions 接口。

    Args:
        api_key:  用户的 API Key
        base_url: 接口根地址（如 https://api.deepseek.com），不含 /v1
        model:    模型名（如 deepseek-chat）
        messages: [{"role": "system"/"user"/"assistant", "content": "..."}]
        timeout:  超时秒数（AI 生成可能较慢，给 120s）
        temperature: 采样温度

    Returns:
        (ok: bool, content_or_error: str)

    为什么 base_url 不含 /v1：DeepSeek 的接口是 https://api.deepseek.com/chat/completions，
    而 OpenAI 是 https://api.openai.com/v1/chat/completions。为了让用户只填一个根地址，
    这里自动尝试「根地址/chat/completions」，如果 404 再试「根地址/v1/chat/completions」。
    """
    if not api_key:
        return False, "未配置 API Key，请在设置页填写"
    base = (base_url or DEFAULT_BASE_URL).rstrip("/")
    # base_url 来自设置页的自由文本，而下面会把 API Key 放进 Authorization 头。
    # 只接受 https://（避免明文发送 Key），但放行回环地址上的 http://，
    # 让 Ollama / LM Studio 这类本机模型仍可用。
    _low = base.lower()
    _loopback_http = _low.startswith(("http://127.0.0.1", "http://localhost", "http://[::1]"))
    if not _low.startswith("https://") and not _loopback_http:
        return False, ("base_url 必须是 https://（本机模型可用 http://127.0.0.1 或 "
                       "http://localhost）—— 否则 API Key 会以明文发出")
    model = model or DEFAULT_MODEL

    payload = json.dumps({
        "model": model,
        "messages": messages,
        "temperature": temperature,
        "stream": False,
    }).encode("utf-8")

    # 尝试两个路径：根地址直接 /chat/completions，以及 /v1/chat/completions
    urls_to_try = [base + "/chat/completions"]
    if not base.endswith("/v1"):
        urls_to_try.append(base + "/v1/chat/completions")

    last_err = ""
    for url in urls_to_try:
        try:
            req = Request(url, data=payload, method="POST")
            req.add_header("Content-Type", "application/json")
            req.add_header("Authorization", "Bearer " + api_key)
            req.add_header("User-Agent", UA)
            with urlopen(req, timeout=timeout) as r:
                raw = r.read().decode("utf-8", "replace")
            data = json.loads(raw)
            # OpenAI 格式：choices[0].message.content
            choices = data.get("choices") or []
            if choices:
                content = (choices[0].get("message") or {}).get("content", "")
                if content:
                    return True, content.strip()
            # 某些接口可能用 data.content 或其他格式
            if data.get("content"):
                return True, str(data["content"]).strip()
            return False, "接口返回为空：" + raw[:300]
        except HTTPError as e:
            body = ""
            try:
                body = e.read().decode("utf-8", "replace")[:300]
            except Exception:
                pass
            last_err = "HTTP %s：%s" % (e.code, body or e.reason)
            # 404 时尝试下一个路径；其他错误直接返回
            if e.code != 404:
                return False, last_err
        except URLError as e:
            last_err = "网络错误：%s" % e.reason
            return False, last_err
        except Exception as e:
            last_err = "请求异常：%s" % e
            return False, last_err

    return False, last_err or "请求失败"


def llm_test(api_key, base_url, model):
    """测试 API 连接是否正常。发一条极简消息验证 Key 和网络。"""
    return llm_chat(api_key, base_url, model, [
        {"role": "user", "content": "请只回复「连接正常」四个字。"}
    ], timeout=30, temperature=0)


# ================================================================
# B 站 CC 字幕获取
# ================================================================

def extract_bvid(url_or_bvid):
    """从 B 站视频 URL 或纯 bvid 中提取 BV 号。

    支持：
      · BV1xx411c7mD（纯 bvid）
      · https://www.bilibili.com/video/BV1xx411c7mD
      · https://www.bilibili.com/video/BV1xx411c7mD?p=2
      · https://b23.tv/xxx（短链不支持，返回空）
    """
    if not url_or_bvid:
        return ""
    s = url_or_bvid.strip()
    m = re.search(r"(BV[0-9A-Za-z]{10})", s)
    if m:
        return m.group(1)
    return ""


_BILI_FP = None  # 缓存的设备指纹 cookie；412 时置 None 强制重新获取


def _bili_cookie_fingerprint(timeout=8):
    """获取游客设备指纹 cookie（buvid3 / buvid4），用于规避 B 站 412 风控。

    B 站对「无任何设备 cookie 的游客请求」会直接回 412 Precondition Failed。
    先调 finger/spi 拿到 buvid3 / buvid4，后续接口带上即可被当作正常浏览器访客。
    返回 "buvid3=...; buvid4=..." 字符串；失败时返回空串（不阻塞主流程）。
    """
    global _BILI_FP
    if _BILI_FP is not None:
        return _BILI_FP
    parts = []
    try:
        req = Request(BILI_API + "/x/frontend/finger/spi",
                      headers={"User-Agent": UA, "Referer": "https://www.bilibili.com/",
                               "Accept": "application/json"})
        with urlopen(req, timeout=timeout) as r:
            d = json.loads(r.read().decode("utf-8", "replace"))
        data = d.get("data") or {}
        if data.get("b_3"):
            parts.append("buvid3=" + str(data["b_3"]))
        if data.get("b_4"):
            parts.append("buvid4=" + str(data["b_4"]))
        _BILI_FP = "; ".join(parts)
    except Exception:
        _BILI_FP = ""  # 获取失败不致命，退回无指纹请求
    return _BILI_FP


def _bili_http_get(url, sessdata=None, timeout=12, referer="https://www.bilibili.com/",
                   _retry=True):
    """带设备指纹 + SESSDATA 的 B 站 API GET，返回解析后的 JSON。

    请求头与 server.py 视频代理保持一致（UA + Referer），并额外补 buvid3/buvid4，
    使未登录游客也能通过风控。遇到 412 时刷新一次设备指纹并重试一次。
    """
    cookies = []
    fp = _bili_cookie_fingerprint()
    if fp:
        cookies.append(fp)
    if sessdata:
        cookies.append("SESSDATA=" + sessdata)
    headers = {"User-Agent": UA, "Referer": referer, "Accept": "application/json"}
    if cookies:
        headers["Cookie"] = "; ".join(cookies)
    req = Request(url, headers=headers)
    try:
        with urlopen(req, timeout=timeout) as r:
            raw = r.read()
        return json.loads(raw.decode("utf-8", "replace"))
    except HTTPError as e:
        # 412：设备指纹失效或被风控。清掉缓存指纹，带新指纹重试一次。
        if e.code == 412 and _retry:
            globals()["_BILI_FP"] = None
            return _bili_http_get(url, sessdata, timeout, referer, _retry=False)
        raise


def fetch_bilibili_subtitles(bvid, sessdata=None, page=1):
    """获取 B 站视频的 CC 字幕文本。

    流程：view API 拿 cid → player/v2 拿字幕列表 → 下载字幕 JSON → 拼接带时间戳文本。

    Args:
        bvid:    BV 号
        sessdata: B 站登录凭证（可选，部分视频需要登录才能看字幕）
        page:    分 P 号（合集视频用，默认 1）

    Returns:
        (ok: bool, text_or_error: str, meta: dict)
        text 格式：[00:00] 第一句话\n[00:05] 第二句话\n...
        meta 包含：cid, subtitle_count, duration 等
    """
    bvid = extract_bvid(bvid)
    if not bvid:
        return False, "无法从链接中提取 BV 号", {}

    try:
        video_ref = "https://www.bilibili.com/video/" + bvid
        # 1. 拿 cid（分 P 视频需要从 pages 里找）
        view = _bili_http_get(BILI_API + "/x/web-interface/view?bvid=" + bvid,
                              sessdata, referer=video_ref)
        vdata = view.get("data") or {}
        if view.get("code") != 0 or not vdata:
            return False, "获取视频信息失败：" + str(view.get("message", "未知错误")), {}
        pages = vdata.get("pages") or []
        req_page = int(page or 1)
        # 精确定位分 P：page 从 1 开始、pages 下标从 0 开始。
        # 分 P 取错会拿到别的集数字幕（笔记与视频无关），所以这里不能静默回退到第 1 P。
        page_obj = pages[req_page - 1] if (pages and 1 <= req_page <= len(pages)) else None
        if req_page > 1 and page_obj is None:
            return False, "该视频只有 %d 个分 P，找不到第 %d P" % (len(pages), req_page), {}
        cid = (page_obj or {}).get("cid") or vdata.get("cid") \
            or (pages[0].get("cid") if pages else None)
        if not cid:
            return False, "无法获取视频 cid", {}

        # 分 P 视频用该 P 的小标题（part），单 P 用视频总标题
        part_title = (page_obj or {}).get("part") or ""
        title = part_title or vdata.get("title", "")
        duration = (page_obj or {}).get("duration") or vdata.get("duration", 0)

        # 2. 拿字幕列表
        player = _bili_http_get(
            BILI_API + "/x/player/v2?bvid=" + bvid + "&cid=" + str(cid),
            sessdata, referer=video_ref)
        pdata = player.get("data") or {}
        subs = ((pdata.get("subtitle") or {}).get("subtitles")) or []
        if not subs:
            return False, "该视频没有 CC 字幕（AI 笔记需要视频有字幕，无字幕视频暂不支持）", {
                "cid": cid, "title": title, "subtitle_count": 0}

        # 3. 选字幕（优先中文 / AI 中文字幕）
        def pick_subtitle(subs_list):
            for s in subs_list:
                if s.get("lan", "") in ("zh-Hans", "zh-CN", "zh", "ai-zh"):
                    return s
            return subs_list[0] if subs_list else None

        chosen = pick_subtitle(subs)
        sub_url = (chosen or {}).get("subtitle_url", "") or ""

        # B 站 AI 字幕是按需异步生成的：条目已存在但 subtitle_url 为空，说明还在生成中。
        # 轮询 player/v2 几次（每次间隔 2 秒）等它生成好，而不是立刻判失败。
        if not sub_url:
            for _w in range(5):
                time.sleep(2)
                pr = _bili_http_get(
                    BILI_API + "/x/player/v2?bvid=" + bvid + "&cid=" + str(cid),
                    sessdata, referer=video_ref)
                subs = (((pr.get("data") or {}).get("subtitle") or {}).get("subtitles")) or []
                chosen = pick_subtitle(subs)
                sub_url = (chosen or {}).get("subtitle_url", "") or ""
                if sub_url:
                    break
        if not sub_url:
            return False, "该分 P 的 AI 字幕还在 B 站侧生成中，请过十几秒后重试", {
                "cid": cid, "title": title, "subtitle_count": len(subs)}

        if sub_url.startswith("//"):
            sub_url = "https:" + sub_url

        # 4. 下载字幕 JSON 并拼接（字幕 CDN 校验 Referer，必须来自 bilibili.com）
        sub_cookies = []
        fp = _bili_cookie_fingerprint()
        if fp:
            sub_cookies.append(fp)
        if sessdata:
            sub_cookies.append("SESSDATA=" + sessdata)
        sub_headers = {"User-Agent": UA, "Referer": video_ref,
                       "Accept": "application/json, text/plain, */*"}
        if sub_cookies:
            sub_headers["Cookie"] = "; ".join(sub_cookies)
        req = Request(sub_url, headers=sub_headers)
        with urlopen(req, timeout=15) as r:
            sub_raw = json.loads(r.read().decode("utf-8", "replace"))
        body = sub_raw.get("body") or []
        if not body:
            return False, "字幕内容为空", {"cid": cid, "title": title, "subtitle_count": len(subs)}

        lines = []
        for item in body:
            start = item.get("from", 0)
            content = (item.get("content") or "").strip()
            if not content:
                continue
            mm = int(start) // 60
            ss = int(start) % 60
            lines.append("[%02d:%02d] %s" % (mm, ss, content))

        text = "\n".join(lines)
        return True, text, {
            "cid": cid, "title": title, "page": req_page, "part": part_title,
            "subtitle_count": len(subs),
            "line_count": len(lines),
            "duration": duration,
        }

    except HTTPError as e:
        return False, "B 站接口 HTTP %s：%s" % (e.code, e.reason), {}
    except URLError as e:
        return False, "网络错误：%s" % e.reason, {}
    except Exception as e:
        return False, "获取字幕异常：%s" % e, {}


# ================================================================
# Prompt 构建
# ================================================================

DEFAULT_NOTES_SYSTEM = (
    "你是一个专业的学习笔记整理助手。用户会给你一段视频的字幕文本（带时间戳），"
    "请你整理成结构清晰、重点突出的学习笔记。要求：\n"
    "1. 用 Markdown 格式，包含适当的标题层级（# 大标题、## 小节）\n"
    "2. 提炼核心知识点，不要逐字复述字幕\n"
    "3. 重要的定义、公式、结论用 **加粗** 标出\n"
    "4. 适当使用列表（- 或 1.）组织内容\n"
    "5. 如果内容包含例题或推导，保留关键步骤\n"
    "6. 笔记末尾加一个「## 要点总结」，用 3-5 条概括整段视频最核心的内容\n"
    "7. 不要输出与视频内容无关的话，直接给笔记正文"
)

DEFAULT_MISTAKE_SYSTEM = (
    "你是一个专业的学科辅导老师。用户会给你一道错题的信息（学科、章节、知识点、题干、"
    "用户自己写的正解与复盘），请你给出专业的错题解析。要求：\n"
    "1. 用 Markdown 格式\n"
    "2. 先给出「## 解题思路」：分析题目考察的知识点，说明正确的思考方向\n"
    "3. 再给出「## 详细解答」：写出完整的解题步骤，关键步骤用 **加粗** 标出\n"
    "4. 然后给出「## 错因分析」：分析这道题容易出错的地方，以及用户可能的错误原因\n"
    "5. 最后给出「## 举一反三」：给出 1-2 道同类题的解题要点（不用写完整题目，只说考察方向和关键方法）\n"
    "6. 如果题干信息不足（比如只有图片没有文字），请明确说明「题干信息不完整，以下基于已有信息分析」，并给出通用的解题思路\n"
    "7. 不要输出与题目无关的话，直接给解析正文"
)


def build_notes_messages(title, subtitle_text, custom_prompt=None):
    """构建 AI 笔记的 messages。"""
    system = custom_prompt.strip() if custom_prompt and custom_prompt.strip() else DEFAULT_NOTES_SYSTEM
    user = "视频标题：%s\n\n以下是视频字幕（带时间戳）：\n\n%s\n\n请整理成学习笔记。" % (
        title or "（未提供标题）", subtitle_text)
    return [
        {"role": "system", "content": system},
        {"role": "user", "content": user},
    ]


def build_mistake_messages(subject, chapter, points, stem, analysis):
    """构建错题解析的 messages。"""
    parts = []
    if subject:
        parts.append("学科：%s" % subject)
    if chapter:
        parts.append("章节：%s" % chapter)
    if points:
        parts.append("知识点：%s" % "、".join(points))
    if stem:
        parts.append("题干 / 错因：\n%s" % stem)
    if analysis:
        parts.append("用户自己写的正解与复盘：\n%s" % analysis)
    if not parts:
        parts.append("（未提供题目信息）")
    user = "请解析以下错题：\n\n" + "\n\n".join(parts)
    return [
        {"role": "system", "content": DEFAULT_MISTAKE_SYSTEM},
        {"role": "user", "content": user},
    ]


# ================================================================
# 高层接口（被 server.py 路由调用）
# ================================================================

def api_generate_notes(payload):
    """生成 AI 笔记。

    payload 字段：
      api_key, base_url, model, bvid, sessdata, page, title, custom_prompt
    """
    api_key = (payload or {}).get("api_key", "")
    base_url = (payload or {}).get("base_url", "")
    model = (payload or {}).get("model", "")
    bvid = (payload or {}).get("bvid", "")
    sessdata = (payload or {}).get("sessdata", "")
    page = int((payload or {}).get("page", 1) or 1)
    title = (payload or {}).get("title", "")
    custom_prompt = (payload or {}).get("custom_prompt", "")

    # 1. 获取字幕
    ok, text, meta = fetch_bilibili_subtitles(bvid, sessdata, page)
    if not ok:
        return {"code": -1, "message": text, "stage": "subtitle"}

    # 字幕过长时截断（避免超出 LLM 上下文；DeepSeek 支持 64K，这里保守截 30000 字符）
    if len(text) > 30000:
        text = text[:30000] + "\n...（字幕过长，已截断）"

    # 2. 调 LLM 生成笔记
    messages = build_notes_messages(title or meta.get("title", ""), text, custom_prompt)
    ok2, result = llm_chat(api_key, base_url, model, messages)
    if not ok2:
        return {"code": -2, "message": result, "stage": "llm", "meta": meta}

    return {
        "code": 0,
        "message": "ok",
        "notes": result,
        "meta": meta,
    }


def api_analyze_mistake(payload):
    """AI 错题解析。

    payload 字段：
      api_key, base_url, model, subject, chapter, points, stem, analysis
    """
    api_key = (payload or {}).get("api_key", "")
    base_url = (payload or {}).get("base_url", "")
    model = (payload or {}).get("model", "")
    subject = (payload or {}).get("subject", "")
    chapter = (payload or {}).get("chapter", "")
    points = (payload or {}).get("points", [])
    stem = (payload or {}).get("stem", "")
    analysis = (payload or {}).get("analysis", "")

    if not isinstance(points, list):
        points = []

    messages = build_mistake_messages(subject, chapter, points, stem, analysis)
    ok, result = llm_chat(api_key, base_url, model, messages)
    if not ok:
        return {"code": -1, "message": result}

    return {"code": 0, "message": "ok", "analysis": result}


def api_test_connection(payload):
    """测试 AI API 连接。"""
    api_key = (payload or {}).get("api_key", "")
    base_url = (payload or {}).get("base_url", "")
    model = (payload or {}).get("model", "")
    ok, result = llm_test(api_key, base_url, model)
    return {"code": 0 if ok else -1, "message": result, "ok": ok}
