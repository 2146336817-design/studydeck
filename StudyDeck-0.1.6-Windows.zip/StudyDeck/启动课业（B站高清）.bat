@echo off
setlocal enableextensions
cd /d "%~dp0"
title StudyDeck - Bilibili HD local proxy
set "PYEXE="
set "PYARG="

if not exist "%~dp0server.py" goto nofile

rem 1) py launcher
for /f "delims=" %%i in ('where py 2^>nul') do if not defined PYEXE set "PYEXE=%%i" & set "PYARG=-3"

rem 2) python on PATH, skip the Microsoft Store 0-byte alias
if not defined PYEXE for /f "delims=" %%i in ('where python 2^>nul') do (
  echo %%i | find /i "WindowsApps" >nul || if not defined PYEXE set "PYEXE=%%i"
)

rem 3) standard per-user Python installs
if not defined PYEXE for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python3*") do if exist "%%D\python.exe" if not defined PYEXE set "PYEXE=%%D\python.exe"

rem 4) Doubao bundled runtime python
if not defined PYEXE for /d %%D in ("%LOCALAPPDATA%\Doubao\User Data\sandbox_runtime\bases\*") do if exist "%%D\python\python.exe" if not defined PYEXE set "PYEXE=%%D\python\python.exe"

if not defined PYEXE goto nopython

echo ==========================================================
echo  StudyDeck - Bilibili HD local proxy
echo  Python : %PYEXE%
echo  Browser opens automatically; see the URL printed below.
echo  Keep THIS window open while studying. Close it to stop.
echo ==========================================================
echo.
rem ensure segno for QR login
"%PYEXE%" %PYARG% -c "import segno" >nul 2>&1 || "%PYEXE%" %PYARG% -m pip install --quiet "segno==1.6.1"
"%PYEXE%" %PYARG% -c "import segno" >nul 2>&1 || echo [WARN] segno missing - QR login unavailable. Run: pip install "segno==1.6.1"
"%PYEXE%" %PYARG% "%~dp0server.py"
echo.
echo Proxy stopped (exit code %errorlevel%). Press any key to close.
pause >nul
exit /b

:nofile
echo [ERROR] server.py not found next to this launcher.
echo Keep index.html, server.py and this .bat in the SAME folder.
pause
exit /b 1

:nopython
echo [ERROR] Python 3 was not found on this computer.
echo Install Python 3.8+ from https://www.python.org/downloads/
echo and tick "Add python.exe to PATH", then run this launcher again.
pause
exit /b 1
