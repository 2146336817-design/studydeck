# -*- coding: utf-8 -*-
"""
课业 · 本地高清代理（零依赖，Python 3.8+）
作用：替浏览器向 B 站接口注入 Referer / SESSDATA，拿到高清直链。
视频流不经过本程序，仍由浏览器直连 B 站 CDN。
启动：双击「启动课业（B站高清）.bat」，或  python server.py
注意：sessdata.txt 是本机保存的 B 站登录凭证，切勿分享/上传本程序文件夹。
"""
import json
import sys
import io
import re
import os
import base64
import zipfile
import xml.etree.ElementTree as ET
import shutil
import hashlib
import time
import socket
import threading
import subprocess
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs, quote
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

# AI 模块（大模型对话 + B 站字幕 + AI 笔记 + 错题解析），零依赖
import ai

sys.stdout.reconfigure(encoding="utf-8")

# 部分网络 IPv6 路由不通而 DNS 优先返回 IPv6，会逐个等待连接超时（可达数十秒）。
# 强制所有解析走 IPv4，避免取链长时间卡死。
_gai_orig = socket.getaddrinfo
def _ipv4_only(host, port, family=0, socktype=0, proto=0, flags=0):
    return _gai_orig(host, port, socket.AF_INET, socktype, proto, flags)
socket.getaddrinfo = _ipv4_only

HERE = os.path.dirname(os.path.abspath(__file__))

# 自动备份保存的互斥锁。
#
# 为什么必须有：服务端是 ThreadingHTTPServer（并发处理请求），而前端的自动备份定时器
# 每个标签页各跑一份（js/settings-backup.js 里 120s 间隔）。两个标签页同时保存时，
# 两次请求会在各自线程里交错执行「写 blobs → 写 manifest → _purge_blobs(keep)」，
# 而 keep 只取自**本次请求**的清单 —— 后到的一次会用自己更小的 keep 集合
# 删掉另一个标签页刚写进去的附件（数据丢失，且不可逆）。
# 加锁把整个保存串行化；keep 另取「本次 ∪ 盘上已有」的并集（见 _autobackup_save）。
_AB_SAVE_LOCK = threading.Lock()
# 凭证与备份目录可用环境变量覆盖（默认仍是程序目录）。
# 这是为了让端到端测试把备份写到临时目录，绝不去碰真实数据 ——
# 备份保存会调 _purge_blobs() 清理未被引用的附件，测试若共用真实目录会删掉用户附件。
SESS_FILE = os.environ.get("STUDYDECK_SESS_FILE") or os.path.join(HERE, "sessdata.txt")
# 本地自动备份：写进程序目录下的 _autobackup/latest.json，不依赖浏览器授权，
# 供「启动时自动恢复」使用——即使换了浏览器或清了浏览器数据，只要这份文件在就能恢复。
AB_DIR = os.environ.get("STUDYDECK_AB_DIR") or os.path.join(HERE, "_autobackup")
AB_FILE = os.path.join(AB_DIR, "latest.json")
# 附件二进制单独存目录：备份的元数据走 latest.json，文件本体走这里。
# 这样自动备份不再把附件 Base64 进 JSON（33% 膨胀 + 每次都全量序列化）。
AB_BLOBS = os.path.join(AB_DIR, "blobs")

# ===== 本地媒体库（MKV/AVI 等浏览器不支持格式的转码播放） =====
# 用户在设置里指定一个视频文件夹（如 D:\网课视频），后端直接读取该目录下的文件。
# 浏览器原生支持的格式直接静态伺服；不支持的格式用 ffmpeg 实时转码为 fMP4 流。
MEDIA_LIB_FILE = os.path.join(HERE, "media-library.txt")
# 浏览器 <video> 原生可解码的容器+编码（常见情况）。
NATIVE_VIDEO_EXTS = (".mp4", ".m4v", ".webm", ".ogg", ".ogv", ".mov")
# 需要转码的格式（容器不被浏览器支持，或编码通常不被支持）。
TRANSCODE_VIDEO_EXTS = (".mkv", ".avi", ".flv", ".wmv", ".rmvb", ".rm", ".ts", ".m2ts",
                         ".mts", ".vob", ".3gp", ".3g2", ".f4v", ".divx", ".xvid")
ALL_VIDEO_EXTS = NATIVE_VIDEO_EXTS + TRANSCODE_VIDEO_EXTS


def video_kind(ext):
    """某一扩展名该怎么播：native（浏览器直接放）/ transcode（需 ffmpeg）/ unsupported。

    这是**唯一**的格式判定入口：以前前端 player.js 里还自己维护了一份 transcodeExts 列表，
    两份清单一旦漂移，前端就会按错误的模式挂播放器（该用转码条却挂了原生控件，
    或者反过来）—— 所以改成由后端告诉前端。"""
    e = (ext or "").lower()
    if e in NATIVE_VIDEO_EXTS:
        return "native"
    if e in TRANSCODE_VIDEO_EXTS:
        return "transcode"
    return "unsupported"

# 「本地视频」(浏览器 fileHandle 选择的文件) 转码缓存目录。
# fileHandle 不暴露绝对路径，后端无法直接读取，所以前端把浏览器解不了的文件
# 上传到这里缓存，再复用媒体库的静态服务 / ffmpeg 转码逻辑。同一文件只传一次。
MEDIA_CACHE_DIR = os.path.join(HERE, "media-cache")
MEDIA_CACHE_MAX_BYTES = 20 * 1024 * 1024 * 1024  # 缓存上限 20GB，超出按最久未访问清理
_ffmpeg_cache = {"checked": False, "path": None}
def ffmpeg_path():
    """检测系统 ffmpeg，缓存结果。返回可执行路径或 None。"""
    if _ffmpeg_cache["checked"]:
        return _ffmpeg_cache["path"]
    _ffmpeg_cache["checked"] = True
    # 优先用程序目录下的 ffmpeg.exe（便携版可自带），再找系统 PATH。
    for cand in (os.path.join(HERE, "ffmpeg.exe"),
                 os.path.join(HERE, "tools", "ffmpeg.exe")):
        if os.path.isfile(cand):
            _ffmpeg_cache["path"] = cand
            return cand
    found = shutil.which("ffmpeg")
    _ffmpeg_cache["path"] = found
    return found
def media_lib_root():
    """读取媒体库根目录（用户在设置里保存的绝对路径）。不存在或为空返回 None。"""
    try:
        with open(MEDIA_LIB_FILE, "r", encoding="utf-8") as f:
            p = f.read().strip()
        if p and os.path.isdir(p):
            return os.path.realpath(p)
    except Exception:
        pass
    return None

# 视频时长探测缓存：{(路径, 大小, mtime): 时长秒}。转码前先拿到总时长，
# 才能用 -t 让 ffmpeg 在 fMP4 片头写死时长（管道输出无法在结束时回写 moov），
# 否则浏览器只能按已到达分片估算，进度条时长会一直跳。
_media_probe_cache = {}
def probe_media(fp):
    """用 ffmpeg -i 解析容器信息：时长（秒）+ 编解码器。按 真实路径+大小+mtime 缓存。

    编解码器用来决定"只换容器"还是"必须重新编码" —— 见 remux_plan()。
    返回 {"duration": float|None, "vcodec": str, "acodec": str, "depth10": bool}。"""
    try:
        st = os.stat(fp)
        key = (os.path.realpath(fp), st.st_size, int(st.st_mtime))
    except Exception:
        key = (fp, 0, 0)
    hit = _media_probe_cache.get(key)
    if hit is not None:
        return hit
    info = {"duration": None, "vcodec": "", "acodec": "", "depth10": False}
    ff = ffmpeg_path()
    if ff and os.path.isfile(fp):
        try:
            p = subprocess.run([ff, "-hide_banner", "-i", fp],
                               capture_output=True, timeout=20)
            txt = (p.stderr or b"").decode("utf-8", "ignore")
            m = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", txt)
            if m:
                info["duration"] = int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))
            mv = re.search(r"Stream #\d+:\d+[^\n]*?: Video:\s*([A-Za-z0-9_]+)([^\n]*)", txt)
            if mv:
                info["vcodec"] = mv.group(1).lower()
                # 10bit H.264 (Hi10P) 浏览器解不了，只能重新编码
                info["depth10"] = bool(re.search(r"p10|10le|10be", mv.group(2)))
            ma = re.search(r"Stream #\d+:\d+[^\n]*?: Audio:\s*([A-Za-z0-9_]+)", txt)
            if ma:
                info["acodec"] = ma.group(1).lower()
        except Exception:
            pass
    _media_probe_cache[key] = info
    return info


def probe_duration(fp):
    """容器时长（秒）；拿不到返回 None。"""
    return probe_media(fp).get("duration")


# 浏览器能直接解 MP4 里的哪些编码组合（决定"重封装"还是"重新编码"）
SAFE_VCODECS = ("h264", "avc1")
SAFE_ACODECS = ("aac", "mp3")


def remux_plan(pinfo):
    """能否只换容器就得到浏览器可播的 MP4；返回 ffmpeg 的编码参数，不能则返回 None。

    为什么值得这么做：重新编码是**分钟级**的（一整节课要等很久），而换容器是**秒级**的
    纯 I/O。只要视频编码浏览器本来就能解，就只把 MKV 装进 MP4 壳里，
    然后当成普通 MP4 用 Range 伺服 —— 时长、进度条、拖动全部交给浏览器原生处理，
    UI 与原生 MP4 完全一致（这正是"为什么 MKV 的 UI 和 MP4 不一样"的解法）。
    音频编码不兼容时单独转 AAC（音频编码很快，不影响体验）。"""
    v = (pinfo.get("vcodec") or "").lower()
    a = (pinfo.get("acodec") or "").lower()
    if pinfo.get("depth10") or v not in SAFE_VCODECS:
        return None
    if not a:
        # 探测没给出音频编码时，**不能**当成"没有音轨"（那会把声音整个丢掉），
        # 也不能直接 -c:a copy（未知编码进 MP4 可能失败）。统一转 AAC：
        # 音频编码比视频快两个数量级，而且 -map 0:a:0? 是可选的，真没音轨时也不会出错。
        return ["-c:v", "copy", "-c:a", "aac", "-b:a", "160k", "-ac", "2"]
    if a not in SAFE_ACODECS:
        return ["-c:v", "copy", "-c:a", "aac", "-b:a", "160k", "-ac", "2"]
    return ["-c:v", "copy", "-c:a", "copy"]


def play_mode(ext, pinfo):
    """该怎么播：native（直接伺服）/ remux（换个壳再用原生播）/ live（实时转码流）/ unsupported。"""
    e = (ext or "").lower()
    if e in NATIVE_VIDEO_EXTS:
        return "native"
    if e not in TRANSCODE_VIDEO_EXTS:
        return "unsupported"
    if not ffmpeg_path():
        return "noffmpeg"
    return "remux" if remux_plan(pinfo) else "live"


REMUX_DIR = os.path.join(MEDIA_CACHE_DIR, "remux")


def _remux_target(fp):
    """重封装缓存文件路径（按 真实路径 + 大小 做指纹）。

    **故意不含 mtime**：LRU 会 touch 源文件的时间戳，一旦把 mtime 算进指纹，
    同一个视频每播放一次就会算出一个新目标名、整份重新换壳一遍 ——
    每次多一份几百 MB 的副本，而且缓存永远命中不了（真实踩过）。
    上传缓存本身已按「名称+大小+修改时间」定址，路径+大小足以标识内容。"""
    try:
        st = os.stat(fp)
        key = "%s|%d" % (os.path.realpath(fp), st.st_size)
    except Exception:
        key = str(fp)
    return os.path.join(REMUX_DIR, hashlib.sha1(key.encode("utf-8", "ignore")).hexdigest()[:16] + ".mp4")


_remux_locks = {}
_remux_locks_guard = threading.Lock()


def _remux_lock(out):
    """取某个输出文件对应的锁。按目标隔离，不同文件的重封装仍可并行。"""
    with _remux_locks_guard:
        lk = _remux_locks.get(out)
        if lk is None:
            lk = threading.Lock()
            _remux_locks[out] = lk
        return lk


def ensure_remux(fp, plan):
    """把 fp 按 plan 重封装进 MP4 缓存（一个源文件只做一次）。成功返回缓存路径，失败返回 None。

    并发安全：两个请求同时要同一个文件时（两个标签页、或浏览器重试），
    必须只有一个 ffmpeg 在写 —— 否则两个进程往同一个 .part 里交错写，
    产生的是一段**坏掉的 MP4**，而且会被当成缓存永久复用。
    这里用「按目标文件加锁 + 锁内二次检查」保证只会真正转一次。"""
    out = _remux_target(fp)
    if os.path.isfile(out) and os.path.getsize(out) > 0:
        return out
    with _remux_lock(out):
        # 二次检查：排队等待期间，前一个线程可能已经把它做好了
        if os.path.isfile(out) and os.path.getsize(out) > 0:
            return out
        return _remux_do(fp, plan, out)


def _remux_do(fp, plan, out):
    """真正的重封装动作（调用方必须已持有该目标的锁）。"""
    ff = ffmpeg_path()
    if not ff:
        return None
    try:
        os.makedirs(REMUX_DIR, exist_ok=True)
    except Exception:
        return None
    tmp = out + ".part"
    # -map 只取第一条视频 + 可选音轨并 -sn 丢掉字幕：
    # MKV 里的 SRT/ASS 字幕在 MP4 里没有对应编码，不排除会让整条命令失败。
    cmd = ([ff, "-hide_banner", "-loglevel", "error", "-y", "-i", fp,
            "-map", "0:v:0", "-map", "0:a:0?", "-sn"]
           + plan + ["-movflags", "+faststart", "-f", "mp4", tmp])
    try:
        p = subprocess.run(cmd, capture_output=True, timeout=1800)
        if p.returncode != 0 or not os.path.isfile(tmp) or os.path.getsize(tmp) == 0:
            try:
                os.remove(tmp)
            except Exception:
                pass
            return None
        os.replace(tmp, out)
        return out
    except Exception:
        try:
            os.remove(tmp)
        except Exception:
            pass
        return None


def try_remux(fp):
    """能只换容器就换（返回 MP4 缓存路径），不能则 None。"""
    plan = remux_plan(probe_media(fp))
    if not plan:
        return None
    return ensure_remux(fp, plan)


UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36")
API = "https://api.bilibili.com"

# 可选日志：设环境变量 STUDYDECK_LOG 指向日志文件即开启（默认静默）
_LOG = os.environ.get("STUDYDECK_LOG", "").strip()
_logh = None
if _LOG:
    try:
        _logh = open(_LOG, "a", encoding="utf-8")
    except Exception:
        _logh = None

# 简单内存缓存：分P列表几乎不变；播放直链有效期约 120 分钟
_CACHE = {}
def cached_get(key, url, sessdata, referer, ttl, force=False):
    ck = (key, bool(sessdata))
    now = time.time()
    hit = _CACHE.get(ck)
    if not force and hit and now - hit[0] < ttl:
        return hit[1]
    val = http_get(url, sessdata, referer)
    _CACHE[ck] = (now, val)
    return val


def http_get(url, sessdata=None, referer="https://www.bilibili.com/"):
    headers = {"User-Agent": UA, "Referer": referer, "Accept": "application/json"}
    if sessdata:
        headers["Cookie"] = "SESSDATA=%s" % sessdata
    req = Request(url, headers=headers)
    with urlopen(req, timeout=10) as r:
        raw = r.read()
    return json.loads(raw.decode("utf-8", "replace"))


def http_get_text(url, sessdata=None, referer="https://www.bilibili.com/"):
    headers = {"User-Agent": UA, "Referer": referer, "Accept": "text/html,*/*"}
    if sessdata:
        headers["Cookie"] = "SESSDATA=%s" % sessdata
    req = Request(url, headers=headers)
    with urlopen(req, timeout=12) as r:
        raw = r.read()
    return raw.decode("utf-8", "replace")


def _WBI_MIX():
    return [46,47,18,2,53,8,23,32,15,50,10,31,58,3,45,35,27,43,5,49,33,9,42,19,29,28,14,39,12,38,41,13,37,48,7,16,24,55,40,61,26,17,0,1,60,51,30,4,22,25,54,21,56,59,6,63,57,62,11,36,20,34,44,52]
_WBI_CACHE = {}
def _wbi_mixin(sessdata=None):
    global _WBI_CACHE
    now = time.time()
    ck = "sess" if sessdata else "guest"
    if _WBI_CACHE.get(ck) and now - _WBI_CACHE[ck]["t"] < 86400:
        return _WBI_CACHE[ck]["mixin"]
    mixin = ""
    try:
        j = http_get(API + "/x/web-interface/nav", sessdata)
        wbi = (j.get("data") or {}).get("wbi_img") or {}
        img = wbi.get("img_url", "") or ""
        sub = wbi.get("sub_url", "") or ""
        ik = img.rsplit("/", 1)[-1].split(".", 1)[0] if "/" in img else ""
        sk = sub.rsplit("/", 1)[-1].split(".", 1)[0] if "/" in sub else ""
        src = ik + sk
        if len(src) >= 64:
            mixin = "".join(src[i] for i in _WBI_MIX())[:32]
    except Exception:
        mixin = ""
    if mixin:
        _WBI_CACHE[ck] = {"mixin": mixin, "t": now}
    return mixin

def _wbi_sign(params, sessdata=None):
    params = dict(params)
    params["wts"] = int(time.time())
    mixin = _wbi_mixin(sessdata)
    q = "&".join("%s=%s" % (k, re.sub(r"[!'()*]", "", str(params[k]))) for k in sorted(params))
    rid = hashlib.md5((q + mixin).encode()).hexdigest()
    return params, rid


def q(qs, name, default=""):
    v = qs.get(name, [default])
    return v[0] if v else default


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        if _logh:
            try:
                _logh.write("%s - - [%s] %s\n" % (
                    self.address_string(), self.log_date_time_string(), fmt % args))
                _logh.flush()
            except Exception:
                pass

    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        if isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        # 禁止浏览器对响应做 MIME 嗅探。
        # 没有这一行时，一个把 Content-Type 设成 text/html 的响应（附件接口曾经原样回显
        # 客户端传来的 type）会被当成 HTML 渲染 —— 同源 XSS，可借同源代理接口动用已存的
        # SESSDATA，也能调用删除类接口。nosniff 让浏览器严格按声明的类型处理。
        self.send_header("X-Content-Type-Options", "nosniff")
        # 出错时主动关闭连接：某些错误分支在读完 Content-Length 之前就返回了，
        # 未读的请求体会留在 socket 里，让 HTTP/1.1 keep-alive 的下一个请求被解析成
        # 垃圾（实测表现为 501 Unsupported method ('{...}POST')）。
        # 错误响应一律 Connection: close，让客户端换一条连接，杜绝这种错位。
        if code >= 400:
            self.send_header("Connection", "close")
            self.close_connection = True
        self.end_headers()
        self.wfile.write(body)

    def _json(self, obj, code=200):
        self._send(code, json.dumps(obj, ensure_ascii=False))

    def _send_download(self, data, filename):
        self.send_response(200)
        self.send_header("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        self.send_header("Content-Disposition", "attachment; filename*=UTF-8''%s" % quote(filename))
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        host = (self.headers.get("Host") or "").strip().lower()
        hname = host.split(":")[0].strip("[]") if host else ""
        if hname not in ("127.0.0.1", "localhost", "::1"):
            return self._json({"code": -403, "message": "forbidden host"}, 403)
        try:
            if path == "/" or path.endswith(".html") or path.endswith(".js"):
                return self._serve_file(path)
            if path == "/api/ping":
                return self._json({"ok": True, "name": "studydeck-proxy",
                                   "hasSessFile": os.path.exists(SESS_FILE)})
            if path == "/api/bili/playurl":
                return self._playurl(parse_qs(parsed.query))
            if path == "/api/bili/cdn":
                return self._cdn(parse_qs(parsed.query))
            if path == "/api/bili/me":
                return self._me(parse_qs(parsed.query))
            if path == "/api/bili/meta":
                return self._meta(parse_qs(parsed.query))
            if path == "/api/bili/collection":
                return self._collection(parse_qs(parsed.query))
            if path == "/api/bili/favlist":
                return self._favlist(parse_qs(parsed.query))
            if path == "/api/bili/pgc":
                return self._pgc(parse_qs(parsed.query))
            if path == "/api/bili/up":
                return self._up(parse_qs(parsed.query))
            if path == "/api/bili/qrgen":
                return self._qrgen()
            if path == "/api/bili/qrpoll":
                return self._qrpoll(parse_qs(parsed.query))
            if path == "/api/timetable/template":
                return self._timetable_template()
            if path == "/api/autobackup/read":
                return self._autobackup_read()
            if path == "/api/autobackup/blob":
                return self._autobackup_blob(parse_qs(parsed.query))
            if path == "/api/media/config":
                return self._media_config_get()
            if path == "/api/media/list":
                return self._media_list(parse_qs(parsed.query))
            if path == "/api/media/info":
                return self._media_info(parse_qs(parsed.query))
            if path.startswith("/api/media/play/"):
                return self._media_play(path[len("/api/media/play/"):], parse_qs(parsed.query))
            if path == "/api/media/cache-status":
                return self._media_cache_status(parse_qs(parsed.query))
            if path.startswith("/api/media/cached/"):
                return self._media_cached_play(path[len("/api/media/cached/"):], parse_qs(parsed.query))
            self._json({"code": -404, "message": "not found"}, 404)
        except HTTPError as e:
            self._json({"code": -e.code, "message": "上游 HTTP %s" % e.code})
        except URLError as e:
            self._json({"code": -1, "message": "网络错误：%s" % e.reason})
        except Exception as e:  # noqa
            self._json({"code": -1, "message": "代理异常：%s" % e})

    def _origin_ok(self):
        """跨站请求防护。

        Host 白名单只能挡 DNS rebinding，挡不住「用户浏览器里的恶意页面」——
        恶意页面对 127.0.0.1 发起的简单请求（无需预检的 POST / multipart）一样能到达这里。
        因此对会改动磁盘的接口校验 Origin / Referer：只接受本机来源；
        命令行（curl）不带这两个头，视为安全放行。
        """
        for header in ("Origin", "Referer"):
            raw = (self.headers.get(header) or "").strip()
            if not raw:
                continue
            try:
                h = urlparse(raw).hostname or ""
            except Exception:
                return False
            if h not in ("127.0.0.1", "localhost", "::1"):
                return False
        return True

    def do_POST(self):
        parsed = urlparse(self.path)
        host = (self.headers.get("Host") or "").strip().lower()
        hname = host.split(":")[0].strip("[]") if host else ""
        if hname not in ("127.0.0.1", "localhost", "::1"):
            return self._json({"code": -403, "message": "forbidden host"}, 403)
        try:
            if parsed.path == "/api/import/timetable":
                return self._import_timetable()
            if parsed.path == "/api/timetable/export":
                return self._timetable_export()
            if parsed.path == "/api/autobackup/save":
                if not self._origin_ok():
                    return self._json({"code": -403, "message": "拒绝跨站写入"}, 403)
                return self._autobackup_save()
            if parsed.path == "/api/autobackup/delete":
                if not self._origin_ok():
                    return self._json({"code": -403, "message": "拒绝跨站写入"}, 403)
                return self._autobackup_delete()
            if parsed.path == "/api/sessdata/delete":
                if not self._origin_ok():
                    return self._json({"code": -403, "message": "拒绝跨站写入"}, 403)
                return self._sess_delete()
            if parsed.path == "/api/ai/generate-notes":
                if not self._origin_ok():
                    return self._json({"code": -403, "message": "拒绝跨站调用"}, 403)
                return self._ai_generate_notes()
            if parsed.path == "/api/ai/analyze-mistake":
                if not self._origin_ok():
                    return self._json({"code": -403, "message": "拒绝跨站调用"}, 403)
                return self._ai_analyze_mistake()
            if parsed.path == "/api/ai/test":
                if not self._origin_ok():
                    return self._json({"code": -403, "message": "拒绝跨站调用"}, 403)
                return self._ai_test()
            if parsed.path == "/api/media/config":
                if not self._origin_ok():
                    return self._json({"code": -403, "message": "拒绝跨站写入"}, 403)
                return self._media_config_save()
            if parsed.path == "/api/media/upload":
                if not self._origin_ok():
                    return self._json({"code": -403, "message": "拒绝跨站写入"}, 403)
                return self._media_upload(parse_qs(parsed.query))
            self._json({"code": -404, "message": "not found"}, 404)
        except Exception as e:  # noqa
            self._json({"code": -1, "message": "代理异常：%s" % e})

    def _sess_delete(self):
        """删除程序目录下的 sessdata.txt（B 站登录凭证的明文副本）。

        这是一个独立的接口：早期版本让「删除本地凭证文件」按钮误调了
        /api/autobackup/delete，结果凭证没删掉、本地自动备份却被清空了。
        """
        if not os.path.exists(SESS_FILE):
            return self._json({"code": 0, "message": "not found", "deleted": False})
        try:
            os.remove(SESS_FILE)
        except Exception as e:
            return self._json({"code": -1, "message": "删除失败：%s" % e})
        return self._json({"code": 0, "message": "deleted", "deleted": True})

    def _read_json_body(self, max_bytes=2 * 1024 * 1024):
        """读取 POST 的 JSON 请求体。AI 接口用，限制 2MB 防止异常大请求。"""
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            return None
        if length <= 0 or length > max_bytes:
            return None
        try:
            raw = self.rfile.read(length).decode("utf-8")
            return json.loads(raw)
        except Exception:
            return None

    def _ai_generate_notes(self):
        """AI 生成笔记：取 B 站 CC 字幕 → 调大模型整理成结构化笔记。"""
        payload = self._read_json_body()
        if payload is None:
            return self._json({"code": 400, "message": "请求体不是合法 JSON"}, 400)
        # 凭证兜底：前端没带 sessdata 时（如扫码登录只写入了 sessdata.txt），
        # 从 X-Sessdata 头或本机 sessdata.txt 读取，与视频流代理 _playurl 保持一致，
        # 否则 AI 字幕会以游客身份请求，容易触发 B 站 412 风控且拿不到 AI 字幕。
        if not str(payload.get("sessdata") or "").strip():
            payload["sessdata"] = self._sess()
        result = ai.api_generate_notes(payload)
        return self._json(result)

    def _ai_analyze_mistake(self):
        """AI 错题解析：学科/章节/知识点/题干 → 调大模型给出解题思路、详细解答、错因分析。"""
        payload = self._read_json_body()
        if payload is None:
            return self._json({"code": 400, "message": "请求体不是合法 JSON"}, 400)
        result = ai.api_analyze_mistake(payload)
        return self._json(result)

    def _ai_test(self):
        """测试 AI API 连接（Key 是否有效、网络是否通）。"""
        payload = self._read_json_body()
        if payload is None:
            return self._json({"code": 400, "message": "请求体不是合法 JSON"}, 400)
        result = ai.api_test_connection(payload)
        return self._json(result)

    def _import_timetable(self):
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            return self._json({"code": 400, "message": "长度非法"}, 400)
        if length <= 0 or length > 12 * 1024 * 1024:
            return self._json({"code": 400, "message": "文件过大或为空"}, 400)
        try:
            payload = json.loads(self.rfile.read(length).decode("utf-8"))
        except Exception:
            return self._json({"code": 400, "message": "请求体不是合法 JSON"}, 400)
        b64 = (payload or {}).get("file_b64") or ""
        try:
            raw = base64.b64decode(b64)
        except Exception:
            return self._json({"code": 400, "message": "文件编码非法"}, 400)
        try:
            sheets = _parse_xlsx(raw)
        except Exception as e:
            return self._json({"code": -1, "message": "无法解析该文件，请确认为 .xlsx 表格：%s" % e})
        return self._json({"code": 0, "data": sheets})

    def _timetable_template(self):
        try:
            data = _make_xlsx(_blank_timetable())
        except Exception as e:
            return self._json({"code": -1, "message": "生成模板失败：%s" % e})
        return self._send_download(data, "在家自学弹性课程表-空白模板.xlsx")

    def _timetable_export(self):
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            return self._json({"code": 400, "message": "长度非法"}, 400)
        if length <= 0 or length > 2 * 1024 * 1024:
            return self._json({"code": 400, "message": "数据过大"}, 400)
        try:
            payload = json.loads(self.rfile.read(length).decode("utf-8"))
        except Exception:
            return self._json({"code": 400, "message": "请求体非法"}, 400)
        sheets = (payload or {}).get("sheets") or []
        if not sheets:
            return self._json({"code": 400, "message": "没有可导出的任务"}, 400)
        clean = [{"name": str(s.get("name", "Sheet")),
                  "rows": [[str(c) if c is not None else "" for c in (r or [])] for r in (s.get("rows") or [])]}
                 for s in sheets]
        try:
            data = _make_xlsx(clean)
        except Exception as e:
            return self._json({"code": -1, "message": "导出失败：%s" % e})
        return self._send_download(data, "在家自学弹性课程表-导出.xlsx")

    def _collect_blob_payloads(self, meta, files):
        """把这次请求里的附件二进制收集成 {id: bytes}。

        两个来源：
          * multipart 请求里的 blobs[]（新格式）—— 已经是原始字节；
          * meta['files'][].data 里的 data:...;base64,...（**旧格式**）—— 需要解码。

        旧格式这一支是必须的：过去只把 data 字段剥掉而不落盘，附件字节就永久丢失，
        紧接着的 _purge_blobs() 还会把磁盘上已有的附件一并清空。
        在这里解出真实字节，旧备份才算**真正完成迁移**，而不只是换个外形。

        单独成方法是为了能脱离 HTTP 层直接测试（见 tools/legacy-migration-test.py）。
        """
        out = {}
        for name, data in (files or {}).items():
            out[name] = data
        legacy = meta.get("files") or []
        if legacy and isinstance(legacy[0], dict) and "data" in legacy[0]:
            for f in legacy:
                if not isinstance(f, dict):
                    continue
                fid = f.get("id")
                raw_url = f.get("data")
                if not _valid_blob_id(fid) or not isinstance(raw_url, str):
                    continue
                comma = raw_url.find(",")
                if comma < 0:
                    continue
                try:
                    out[fid] = base64.b64decode(raw_url[comma + 1:])
                except Exception:
                    continue
        return out

    def _autobackup_read(self):
        if not os.path.exists(AB_FILE):
            return self._json({"code": 0, "data": None})
        try:
            with io.open(AB_FILE, encoding="utf-8") as f:
                data = json.load(f)
            return self._json({"code": 0, "data": data})
        except Exception as e:
            return self._json({"code": -1, "message": "读取本地备份失败：%s" % e})

    def _autobackup_save(self):
        """保存本地自动备份。

        两种请求体：
          1) 旧格式（纯 JSON）：备份里自带 Base64 的 files[]。服务端会把内联的 Base64
             **解出来写成真正的附件文件**，再按新格式只留清单 —— 也就是在服务端完成迁移。
             （绝不能只剥掉 data 字段：那会丢附件字节，且随后的 _purge_blobs 还会清空已有附件。）
          2) 新格式：JSON 元数据 + multipart/form-data 里的二进制附件（blobs[]）。
             二进制走独立通道后，备份请求从「34MB 的 Base64 JSON」变成
             「124KB 元数据 + N 个原始文件」，不再有 Base64 的 33% 膨胀。
        """
        ctype = (self.headers.get("Content-Type") or "").lower()
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            return self._json({"code": 400, "message": "长度非法"}, 400)
        if length <= 0 or length > 512 * 1024 * 1024:
            return self._json({"code": 400, "message": "备份过大或为空"}, 400)

        raw = self.rfile.read(length)
        try:
            if "multipart/form-data" in ctype:
                fields, files = _parse_multipart(raw, ctype)
                meta = json.loads((fields.get("manifest") or b"{}").decode("utf-8"))
            else:
                meta = json.loads(raw.decode("utf-8"))
                files = {}
        except Exception as e:
            return self._json({"code": 400, "message": "请求体非法：%s" % e}, 400)

        if not isinstance(meta, dict) or meta.get("app") != "studydeck":
            return self._json({"code": 400, "message": "备份内容非法"}, 400)

        try:
            os.makedirs(AB_DIR, exist_ok=True)
            os.makedirs(AB_BLOBS, exist_ok=True)
        except Exception as e:
            return self._json({"code": -1, "message": "创建备份目录失败：%s" % e})

        # 从这里到函数结束是「写附件 → 写 manifest → 清理孤儿」这一个不可分割的动作。
        # 必须整体串行化：并发（两个标签页各自的 120s 定时器）交错执行时，
        # 后到的 purge 会用自己更小的 keep 集合删掉对方刚写的附件。
        # 做法：把这一段包成一个内层函数交给 _locked 执行 —— 这样锁一定在 finally 里释放，
        # 而内部那几处提前 return 的缩进完全不用动（手工整段缩进最容易改错）。
        def _do_save():
            # 1) 先写二进制附件（写坏了也不会影响已有备份）
            written = []
            try:
                for name, data in self._collect_blob_payloads(meta, files).items():
                    if not _valid_blob_id(name):
                        continue
                    tmp = os.path.join(AB_BLOBS, name + ".tmp")
                    with open(tmp, "wb") as f:
                        f.write(data)
                    os.replace(tmp, os.path.join(AB_BLOBS, name))
                    written.append(name)
            except Exception as e:
                return self._json({"code": -1, "message": "保存附件失败：%s" % e})

            # 2) 元数据里的 files[] 只留清单（id / size），不再留 Base64
            files_meta = meta.get("files") or []
            if files_meta and isinstance(files_meta[0], dict) and "data" in files_meta[0]:
                meta["files"] = [{"id": f.get("id"), "size": f.get("size") or 0,
                                  "name": f.get("name") or ""} for f in files_meta]

            # 先把**旧清单**的引用读出来，再写新 manifest。
            # 顺序很关键：_purge_blobs 的 keep 要取「本次 ∪ 上次」的并集，
            # 而并集必须基于"被本次覆盖之前"的内容 —— 写完再读就只能读到本次自己。
            prev_ids = set()
            try:
                if os.path.exists(AB_FILE):
                    with io.open(AB_FILE, "r", encoding="utf-8") as f:
                        prev_ids = {x.get("id") for x in (json.load(f).get("files") or []) if x.get("id")}
            except Exception:
                prev_ids = set()   # 旧清单损坏/不存在 → 退化成只用本次清单

            try:
                # 覆盖前留一份上一版 manifest（latest.json.bak），供误清后人工恢复。
                # 只保留一份、只复制 manifest（不含二进制），所以开销很小。
                if os.path.exists(AB_FILE):
                    try:
                        shutil.copyfile(AB_FILE, AB_FILE + ".bak")
                    except Exception:
                        pass
                tmp = AB_FILE + ".tmp"
                with io.open(tmp, "w", encoding="utf-8") as f:
                    json.dump(meta, f, ensure_ascii=False)
                os.replace(tmp, AB_FILE)
            except Exception as e:
                return self._json({"code": -1, "message": "保存本地备份失败：%s" % e})

            # 3) 清理不再被引用的旧附件文件
            #
            # keep = 本次清单 ∪ 上次清单：并发保存时后到者不会删掉对方刚写的附件。
            incoming = {f.get("id") for f in (meta.get("files") or []) if f.get("id")}
            keep = incoming | prev_ids
            #
            # ⚠️ RK-01 防护：**本次清单没有声明任何文件时，绝不 purge**。
            # 触发场景：用户一个待恢复的附件都没有 —— 浏览器发来的就是 `files: []`，
            # 而 blobs/ 里可能还留着文件（历史遗留、或另一个标签页刚写的）。
            # 若照常 purge，这些文件会被整批删掉且不可逆。
            # 判据必须是 incoming（本次清单），不能是 keep —— keep 含 prev_ids，
            # 空清单时它往往非空，用 keep 判会漏掉这个场景（实测会删掉 2 个文件）。
            # 空 incoming 说明"这次备份不完整"，此时删除没有任何收益，只有风险。
            # （manifest 仍照常写入 —— 那是前端的真实意图，不该被拦。）
            removed = 0
            if incoming:
                removed = _purge_blobs(keep)
            return self._json({"code": 0, "message": "saved",
                               "blobsWritten": len(written), "blobsRemoved": removed,
                               "files": sorted(keep)})

        with _AB_SAVE_LOCK:
            return _do_save()

    def _autobackup_blob(self, qs):
        """按 id 取回一个附件二进制。用于客户端「按需水合」本地备份。"""
        bid = q(qs, "id")
        if not _valid_blob_id(bid):
            return self._json({"code": -2, "message": "缺少或非法的附件 id"}, 400)
        fp = os.path.join(AB_BLOBS, bid)
        if not os.path.isfile(fp):
            return self._json({"code": -3, "message": "该附件不在本地备份中"}, 404)
        try:
            with open(fp, "rb") as f:
                data = f.read()
        except Exception as e:
            return self._json({"code": -1, "message": "读取附件失败：%s" % e})
        # Content-Type 走**白名单**，不原样回显客户端传来的 type。
        #
        # 原来 `ctype = q(qs,"type") or "application/octet-stream"` 把查询参数直接塞进响应头，
        # 于是 `?type=text/html` 会让浏览器把附件字节当 HTML 在同源下执行 —— 存储型 XSS
        # （可借同源代理接口动用已存 SESSDATA、可调用删除类接口）。
        # 但"能指定 type"本身是**有意的功能**（PDF/图片要在应用内内联预览），
        # 所以不能一刀切删掉，而是收窄到"可以安全内联渲染"的类型；
        # 其余（含 text/html、image/svg+xml、application/javascript 等可执行/可注入类型）
        # 一律回落到 application/octet-stream 下载，配合 _send 的 nosniff 双重收口。
        return self._send(200, data, _safe_blob_ctype(q(qs, "type")))

    def _autobackup_delete(self):
        try:
            if os.path.exists(AB_FILE):
                os.remove(AB_FILE)
            if os.path.isdir(AB_BLOBS):
                shutil.rmtree(AB_BLOBS, ignore_errors=True)
        except Exception as e:
            return self._json({"code": -1, "message": "删除失败：%s" % e})
        return self._json({"code": 0, "message": "deleted"})

    def _serve_file(self, path):
        """只伺服本目录下的静态资源：根目录的 .html，以及 js/ 下的 ES 模块。

        注意：path 以 "/" 开头，绝不能直接喂给 os.path.join —— 绝对路径会忽略基目录。
        """
        rel = "index.html" if path in ("/", "") else path.lstrip("/")
        rel = os.path.normpath(rel).replace("\\", "/")
        if rel.startswith("../") or rel == ".." or rel.startswith("/"):
            return self._json({"code": -403}, 403)
        name = rel.rsplit("/", 1)[-1]
        if "/" not in rel:
            allowed = name.endswith(".html")                 # 根目录只放 html
        elif rel.startswith("js/"):
            allowed = name.endswith(".js")                   # js/ 只放模块脚本
        else:
            allowed = False                                  # 其他子目录一律不服务
        if not allowed:
            return self._json({"code": -403}, 403)
        base = os.path.realpath(HERE)
        fp = os.path.realpath(os.path.join(base, rel))
        if fp != base and not fp.startswith(base + os.sep):
            return self._json({"code": -403}, 403)
        if not os.path.isfile(fp):
            return self._send(404, "file not found", "text/plain; charset=utf-8")
        ctype = ("text/html; charset=utf-8" if name.endswith(".html")
                 else "text/javascript; charset=utf-8")
        with open(fp, "rb") as f:
            data = f.read()
        self._send(200, data, ctype)

    # ==================== 本地媒体库（转码播放） ====================

    def _media_config_get(self):
        root = media_lib_root()
        return self._json({
            "code": 0,
            "path": root or "",
            "hasFfmpeg": ffmpeg_path() is not None,
            "ffmpegPath": ffmpeg_path() or "",
        })

    def _media_config_save(self):
        """POST body: {"path": "D:\\网课视频"}。校验是真实目录后写入。"""
        try:
            length = int(self.headers.get("Content-Length") or 0)
            raw = self.rfile.read(length) if length else b""
            obj = json.loads(raw.decode("utf-8"))
        except Exception:
            return self._json({"code": -1, "message": "请求体解析失败"}, 400)
        p = (obj.get("path") or "").strip()
        if not p:
            # 空路径 = 清除媒体库设置
            try:
                if os.path.exists(MEDIA_LIB_FILE):
                    os.remove(MEDIA_LIB_FILE)
            except Exception:
                pass
            return self._json({"code": 0, "path": ""})
        if not os.path.isdir(p):
            return self._json({"code": -1, "message": "目录不存在：%s" % p}, 400)
        try:
            with open(MEDIA_LIB_FILE, "w", encoding="utf-8") as f:
                f.write(os.path.realpath(p))
        except Exception as e:
            return self._json({"code": -1, "message": "写入失败：%s" % e}, 500)
        return self._json({"code": 0, "path": os.path.realpath(p),
                            "hasFfmpeg": ffmpeg_path() is not None})

    def _media_list(self, qs):
        """递归列出媒体库目录下的视频文件。返回 [{path,name,size}]。"""
        root = media_lib_root()
        if not root:
            return self._json({"code": -1, "message": "未设置媒体库目录"}, 400)
        out = []
        try:
            for dirpath, _dirs, files in os.walk(root):
                for fn in files:
                    ext = os.path.splitext(fn)[1].lower()
                    if ext not in ALL_VIDEO_EXTS:
                        continue
                    full = os.path.join(dirpath, fn)
                    rel = os.path.relpath(full, root).replace("\\", "/")
                    try:
                        size = os.path.getsize(full)
                    except Exception:
                        size = 0
                    out.append({"path": rel, "name": fn, "size": size})
                    if len(out) >= 1000:
                        break
                if len(out) >= 1000:
                    break
        except Exception as e:
            return self._json({"code": -1, "message": "扫描失败：%s" % e}, 500)
        out.sort(key=lambda x: x["path"].lower())
        return self._json({"code": 0, "files": out, "root": root})

    def _safe_media_path(self, relpath):
        """把 URL 里的相对路径安全拼接到媒体库根目录，防目录遍历。
        返回真实绝对路径；非法或越界返回 None。"""
        root = media_lib_root()
        if not root:
            return None
        # URL 解码（路径里可能有中文、空格）
        from urllib.parse import unquote
        rel = unquote(relpath)
        rel = os.path.normpath(rel).replace("\\", "/")
        if rel.startswith("../") or rel == ".." or rel.startswith("/") or rel.startswith("~"):
            return None
        fp = os.path.realpath(os.path.join(root, rel))
        if fp != root and not fp.startswith(root + os.sep):
            return None
        return fp

    def _media_info(self, qs):
        """GET /api/media/info?path=<相对路径> → 真实时长 + 该怎么播。

        · 时长：转码流用 fMP4 + empty_moov 输出，moov 里没有时长，浏览器只能按
          "已经收到的分片"估 —— 会显示成几秒而视频还在放。HTTP 头（X-Media-Duration）
          写在媒体响应上，<video> 也不会把它暴露给 JS，所以只能另开一个 JSON 端点。
        · mode：前端据此决定挂原生控件还是自建控制条（见 play_mode）。"""
        rel = (qs.get("path") or [""])[0]
        fp = self._safe_media_path(rel)
        if not fp or not os.path.isfile(fp):
            return self._json({"code": -404, "message": "文件不存在或越界"}, 404)
        ext = os.path.splitext(fp)[1].lower()
        pinfo = probe_media(fp)
        mode = play_mode(ext, pinfo)
        return self._json({
            "code": 0,
            "duration": pinfo.get("duration"),      # 拿不到则为 null，前端自行退回
            "kind": video_kind(ext),
            "mode": mode,
            "native": ext in NATIVE_VIDEO_EXTS,
            "hasFfmpeg": ffmpeg_path() is not None,
        })

    def _media_play(self, relpath, qs):
        """播放端点。
        · 浏览器原生支持的格式 → 静态伺服（支持 Range）
        · 只换容器就行的（H.264/AAC 等）→ 重封装成 MP4 缓存再静态伺服：
          秒级完成，之后时长/进度条/拖动全由浏览器原生处理，UI 与普通 MP4 完全一致
        · 其余 → ffmpeg 实时转码为 fMP4 流（?t=<秒> 指定起始位置）
        ?live=1 强制走实时转码（前端在重封装结果播不了时用它兜底）。"""
        fp = self._safe_media_path(relpath)
        if not fp:
            return self._json({"code": -404, "message": "文件不存在或越界"}, 404)
        if not os.path.isfile(fp):
            return self._json({"code": -404, "message": "文件不存在"}, 404)
        ext = os.path.splitext(fp)[1].lower()
        # 浏览器原生支持 → 直接静态文件服务（支持 Range seek）
        if ext in NATIVE_VIDEO_EXTS:
            return self._serve_media_file(fp)
        # 需要转码
        ff = ffmpeg_path()
        if not ff:
            return self._json({
                "code": -1,
                "message": "该格式（%s）需要转码，但系统未安装 ffmpeg。"
                           "请下载 ffmpeg 并放入程序目录或系统 PATH。" % ext
            }, 501)
        if not qs.get("live"):
            out = try_remux(fp)
            if out:
                # 上限必须在**播放路径**上也执行：以前只有 _media_upload 会清理，
                # 于是走媒体库（从不上传）的用户永远不触发清理，换壳文件无界增长直到磁盘满。
                self._evict_media_cache()
                return self._serve_media_file(out)
            # 重封装不可用/失败 → 退回实时转码
        seek = 0.0
        try:
            t = qs.get("t", ["0"])[0]
            seek = max(0.0, float(t))
        except Exception:
            seek = 0.0
        return self._transcode_stream(ff, fp, seek)

    def _serve_media_file(self, fp):
        """支持 Range 的静态文件服务（用于浏览器原生支持的视频格式）。"""
        size = os.path.getsize(fp)
        ctype = "video/mp4"
        ext = os.path.splitext(fp)[1].lower()
        if ext == ".webm":
            ctype = "video/webm"
        elif ext in (".ogg", ".ogv"):
            ctype = "video/ogg"
        elif ext == ".mov":
            ctype = "video/quicktime"
        range_header = self.headers.get("Range")
        start = 0
        end = size - 1
        if range_header and range_header.startswith("bytes="):
            try:
                rng = range_header[6:].split("-")
                if rng[0]:
                    start = int(rng[0])
                if len(rng) > 1 and rng[1]:
                    end = int(rng[1])
                if start > end or start >= size:
                    self.send_response(416)
                    self.send_header("Content-Range", "bytes */%d" % size)
                    self.end_headers()
                    return
                end = min(end, size - 1)
            except Exception:
                start, end = 0, size - 1
        length = end - start + 1
        if range_header:
            self.send_response(206)
            self.send_header("Content-Range", "bytes %d-%d/%d" % (start, end, size))
        else:
            self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(length))
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        try:
            with open(fp, "rb") as f:
                f.seek(start)
                remaining = length
                chunk = 64 * 1024
                while remaining > 0:
                    data = f.read(min(chunk, remaining))
                    if not data:
                        break
                    self.wfile.write(data)
                    remaining -= len(data)
        except (BrokenPipeError, ConnectionResetError):
            pass  # 客户端关闭连接，正常

    def _transcode_stream(self, ff, fp, seek_sec):
        """用 ffmpeg 把任意视频实时转码为 fMP4 (H.264+AAC) 流式输出。
        seek_sec > 0 时从指定秒数开始（-ss 放在 -i 前，快速 seek）。
        先探测总时长并用 -t 限定输出时长，让 fMP4 片头带确定的 duration，
        否则管道输出无法回写 moov，浏览器进度条时长会反复跳动。
        客户端断开时杀掉 ffmpeg 子进程。"""
        total = probe_duration(fp)
        cmd = [ff, "-hide_banner", "-loglevel", "error"]
        if seek_sec > 0:
            cmd += ["-ss", "%.3f" % seek_sec]
        cmd += ["-i", fp]
        # 已知总时长时显式限定输出时长（seek 后为剩余时长），片头即可写死 duration
        if total and total > seek_sec + 0.2:
            cmd += ["-t", "%.3f" % (total - seek_sec)]
        cmd += [
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
            "-c:a", "aac", "-b:a", "128k", "-ac", "2",
            "-movflags", "+frag_keyframe+empty_moov+default_base_moof",
            "-f", "mp4",
            "pipe:1",
        ]
        try:
            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        except Exception as e:
            return self._json({"code": -1, "message": "启动 ffmpeg 失败：%s" % e}, 500)
        # 发送响应头：不设 Content-Length，Connection: close 表示流式直到关闭
        self.send_response(200)
        self.send_header("Content-Type", "video/mp4")
        self.send_header("Accept-Ranges", "none")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Connection", "close")
        if total:
            # 暴露给前端：原始总时长与本次流起点，便于校正进度显示
            self.send_header("X-Media-Duration", "%.3f" % total)
            self.send_header("X-Media-Start", "%.3f" % seek_sec)
        self.end_headers()
        try:
            while True:
                chunk = proc.stdout.read(64 * 1024)
                if not chunk:
                    break
                self.wfile.write(chunk)
        except (BrokenPipeError, ConnectionResetError):
            pass  # 客户端关闭，正常
        finally:
            try:
                proc.terminate()
                try:
                    proc.wait(timeout=3)
                except Exception:
                    proc.kill()
            except Exception:
                pass
            # 消费掉 stderr 避免管道阻塞
            try:
                proc.stderr.close()
            except Exception:
                pass

    # ===== 「本地视频」上传转码缓存（fileHandle 文件 → 后端缓存 → 转码播放） =====
    def _cache_safe_paths(self, key, name):
        """校验前端传来的 key/name，返回 (缓存目录, 视频文件绝对路径)；非法返回 (None, None)。
        key 仅允许 16 位十六进制（前端 cyrb53 指纹），name 只取纯文件名且必须是视频。"""
        from urllib.parse import unquote
        key = (key or "").strip()
        name = os.path.basename(unquote(name or "")).strip()
        if not re.fullmatch(r"[0-9a-f]{16}", key):
            return None, None
        if (not name) or name in (".", "..") or name.startswith(".") \
                or "/" in name or "\\" in name or os.path.sep in name:
            return None, None
        ext = os.path.splitext(name)[1].lower()
        if ext not in ALL_VIDEO_EXTS:
            return None, None
        base = os.path.realpath(MEDIA_CACHE_DIR)
        cdir = os.path.realpath(os.path.join(base, key))
        fp = os.path.realpath(os.path.join(cdir, name))
        if not (cdir == base or cdir.startswith(base + os.sep)):
            return None, None
        if not (fp == cdir or fp.startswith(cdir + os.sep)):
            return None, None
        return cdir, fp

    def _drain_body(self, length):
        """读完并丢弃请求体（复用连接时必须把 body 排空，否则下个请求会串行）。"""
        remaining = length
        while remaining > 0:
            chunk = self.rfile.read(min(1024 * 1024, remaining))
            if not chunk:
                break
            remaining -= len(chunk)

    def _media_cache_status(self, qs):
        """查询某文件是否已上传缓存。GET /api/media/cache-status?key=&name=

        顺带回传真实时长与播放方式：缓存文件走的是同一条转码链路，
        同样有"fMP4 报不出总时长"的问题，而前端在这个端点之前本来就要问一次，
        干脆一次问清，省掉一次往返。"""
        cdir, fp = self._cache_safe_paths(qs.get("key", [""])[0], qs.get("name", [""])[0])
        if not fp:
            return self._json({"code": -1, "message": "参数非法"}, 400)
        exists = os.path.isfile(fp)
        ext = os.path.splitext(fp)[1].lower()
        pinfo = probe_media(fp) if exists else {}
        return self._json({"code": 0, "exists": exists,
                            "size": os.path.getsize(fp) if exists else 0,
                            "duration": pinfo.get("duration") if exists else None,
                            "kind": video_kind(ext),
                            "mode": play_mode(ext, pinfo) if exists else "unknown",
                            "hasFfmpeg": ffmpeg_path() is not None})

    def _media_upload(self, qs):
        """接收前端上传的本地视频并缓存。POST /api/media/upload?key=&name=，body 为原始字节。
        先写 .part 再原子改名，避免播放到半成品。"""
        cdir, fp = self._cache_safe_paths(qs.get("key", [""])[0], qs.get("name", [""])[0])
        if not fp:
            return self._json({"code": -1, "message": "参数非法"}, 400)
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except Exception:
            length = 0
        if length <= 0:
            return self._json({"code": -1, "message": "空文件"}, 400)
        # 已缓存且大小一致：排空 body 后直接命中（双保险，前端通常先查 cache-status）
        if os.path.isfile(fp) and os.path.getsize(fp) == length:
            self._drain_body(length)
            return self._json({"code": 0, "cached": True, "size": length})
        try:
            os.makedirs(cdir, exist_ok=True)
        except Exception as e:
            return self._json({"code": -1, "message": "创建缓存目录失败：%s" % e}, 500)
        tmp = fp + ".part"
        got = 0
        try:
            with open(tmp, "wb") as out:
                remaining = length
                while remaining > 0:
                    chunk = self.rfile.read(min(1024 * 1024, remaining))
                    if not chunk:
                        break
                    out.write(chunk)
                    got += len(chunk)
                    remaining -= len(chunk)
        except Exception as e:
            try:
                if os.path.exists(tmp):
                    os.remove(tmp)
            except Exception:
                pass
            return self._json({"code": -1, "message": "上传写入失败：%s" % e}, 500)
        if got != length:
            try:
                if os.path.exists(tmp):
                    os.remove(tmp)
            except Exception:
                pass
            return self._json({"code": -1, "message": "上传不完整：%d/%d" % (got, length)}, 400)
        try:
            os.replace(tmp, fp)
        except Exception as e:
            return self._json({"code": -1, "message": "保存失败：%s" % e}, 500)
        self._evict_media_cache()
        return self._json({"code": 0, "cached": False, "size": got})

    def _media_cached_play(self, relpath, qs):
        """播放上传缓存的本地文件：原生格式直接静态服务（支持 Range），其余 ffmpeg 转码。
        ?t=<秒> 用于转码 seek。"""
        from urllib.parse import unquote
        rel = unquote(relpath)
        parts = rel.split("/", 1)
        if len(parts) != 2:
            return self._json({"code": -404, "message": "路径非法"}, 404)
        cdir, fp = self._cache_safe_paths(parts[0], parts[1])
        if not fp or not os.path.isfile(fp):
            return self._json({"code": -404, "message": "缓存不存在，请重新打开该视频"}, 404)
        ext = os.path.splitext(fp)[1].lower()
        if ext in NATIVE_VIDEO_EXTS:
            return self._serve_media_file(fp)
        ff = ffmpeg_path()
        if not ff:
            return self._json({"code": -1,
                               "message": "该格式（%s）需要转码，但未安装 ffmpeg。" % ext}, 501)
        try:
            # 只更新 atime（_evict_media_cache 就是按 atime 排序的 LRU）。
            # **不能动 mtime**：os.utime(fp, None) 会连 mtime 一起改，
            # 而重封装缓存的指纹包含 mtime —— 于是每播放一次都会算出新的目标文件名，
            # 把同一个视频整份重新换壳一遍（真实踩过：20 秒内同一文件生成了 3 份 350MB 副本）。
            os.utime(fp, (time.time(), os.path.getmtime(fp)))
        except Exception:
            pass
        # 与媒体库同一条策略：能只换容器就先换（原生 UI + 精确时长 + 拖动）
        if not qs.get("live"):
            out = try_remux(fp)
            if out:
                self._evict_media_cache()      # 播放路径也要执行上限（见 _media_play 的说明）
                return self._serve_media_file(out)
        seek = 0.0
        try:
            seek = max(0.0, float(qs.get("t", ["0"])[0]))
        except Exception:
            seek = 0.0
        return self._transcode_stream(ff, fp, seek)

    def _evict_media_cache(self):
        """缓存总量超过上限时，按最久访问时间删除旧文件。"""
        try:
            if not os.path.isdir(MEDIA_CACHE_DIR):
                return
            items = []
            total = 0
            for dirpath, _dirs, fns in os.walk(MEDIA_CACHE_DIR):
                for fn in fns:
                    full = os.path.join(dirpath, fn)
                    try:
                        st = os.stat(full)
                    except Exception:
                        continue
                    if fn.endswith(".part"):
                        try:
                            # 超过 1 小时的残留分片直接删
                            if time.time() - st.st_mtime > 3600:
                                os.remove(full)
                        except Exception:
                            pass
                        continue
                    items.append((st.st_atime, full, st.st_size))
                    total += st.st_size
            items.sort(key=lambda x: x[0])
            for atime, full, size in items:
                if total <= MEDIA_CACHE_MAX_BYTES:
                    break
                try:
                    os.remove(full)
                    total -= size
                except Exception:
                    pass
            for dirpath, _d, _f in os.walk(MEDIA_CACHE_DIR, topdown=False):
                if os.path.realpath(dirpath) == os.path.realpath(MEDIA_CACHE_DIR):
                    continue
                try:
                    if not os.listdir(dirpath):
                        os.rmdir(dirpath)
                except Exception:
                    pass
        except Exception:
            pass

    def _sess(self, qs=None):
        """SESSDATA：优先自定义头 X-Sessdata，其次本机 sessdata.txt。

        出于安全考虑不接受 query 传参（否则会把登录凭证留在 URL / 日志里）。
        qs 参数仅为兼容旧的调用签名保留。
        """
        sess = (self.headers.get("X-Sessdata") or "").strip()
        if not sess and os.path.exists(SESS_FILE):
            with io.open(SESS_FILE, encoding="utf-8") as f:
                sess = f.read().strip()
        return sess

    def _playurl(self, qs):
        bvid = q(qs, "bvid")
        aid = q(qs, "aid")
        try: page = int(q(qs, "p", "1") or "1")
        except ValueError: return self._json({"code": 400, "message": "参数 p 不是整数"}, 400)
        try: qn = int(q(qs, "qn", "80") or "80")
        except ValueError: return self._json({"code": 400, "message": "参数 qn 不是整数"}, 400)
        fmt = q(qs, "fmt", "durl")
        force = q(qs, "refresh") == "1"
        sess = self._sess(qs)

        ep = q(qs, "ep")
        if ep:
            # 番剧：pgc 播放接口。B 站已废弃番剧 flv/durl（fnval=1 返回空 durl），
            # 可播放流必须用 fnval=4048（dash）。前端 auto 模式会先试 dash。
            if fmt == "dash":
                fnval = 4048
            else:
                fnval = 1
            purl = ("%s/pgc/player/web/playurl?ep_id=%s&qn=%d&fnval=%d&fnver=0"
                    "&platform=html5&high_quality=1" % (API, quote(ep), qn, fnval))
            referer = "https://www.bilibili.com/bangumi/play/ep%s" % ep
            data = cached_get("pu:" + purl, purl, sess, referer, 4800, force)
            if isinstance(data, dict):
                res = data.get("result") if isinstance(data.get("result"), dict) else {}
                out = {"code": 0, "data": {}, "_proxy": {"ep": ep, "logged": bool(sess), "fmt": fmt}}
                if fmt == "dash" and isinstance(res.get("dash"), dict):
                    out["data"]["dash"] = res["dash"]
                    out["data"]["quality"] = res.get("quality")
                    out["data"]["accept_quality"] = res.get("accept_quality")
                    out["data"]["timelength"] = res.get("timelength")
                else:
                    out["data"]["durl"] = res.get("durl") or []
                    out["data"]["quality"] = res.get("quality")
                    out["data"]["accept_quality"] = res.get("accept_quality")
                return self._json(out)
            return self._json(data)

        ident = "bvid=%s" % quote(bvid) if bvid else "aid=%s" % quote(aid)
        if not bvid and not aid:
            return self._json({"code": -2, "message": "缺少 bvid / aid"})

        # 1) 分 P 列表，取 cid（缓存 6 小时）
        pl = cached_get("pl:" + ident, "%s/x/player/pagelist?%s" % (API, ident),
                        sess, "https://www.bilibili.com/", 21600, force)
        if pl.get("code") != 0:
            return self._json({"code": pl.get("code", -1),
                               "message": "分P列表获取失败：%s" % pl.get("message", "")})
        pages = pl.get("data") or []
        if not pages:
            return self._json({"code": -3, "message": "该视频没有分P数据"})
        idx = max(0, min(page - 1, len(pages) - 1))
        cid = pages[idx]["cid"]
        part = pages[idx].get("page", idx + 1)

        # 2) 播放地址
        if fmt == "dash":
            tail = "qn=%d&fnval=4048&fnver=0&fourk=1" % qn
        else:
            tail = "qn=%d&fnval=1&fnver=0&platform=html5&high_quality=1" % qn
        purl = "%s/x/player/playurl?%s&cid=%d&%s" % (API, ident, cid, tail)
        referer = "https://www.bilibili.com/video/%s?p=%d" % (bvid or ("av%s" % aid), part)
        # 播放直链缓存 80 分钟（官方有效期约 120 分钟）
        data = cached_get("pu:" + purl, purl, sess, referer, 4800, force)
        if isinstance(data, dict):
            # 游客 html5 接口会虚标 accept_quality（含 80 但实际只给 720P），
            # 未登录时过滤掉 720P 以上档位，避免前端误导
            if not sess and isinstance(data.get("data"), dict):
                aq = data["data"].get("accept_quality")
                if isinstance(aq, list):
                    data["data"]["accept_quality"] = [q for q in aq if q <= 64]
            data["_proxy"] = {"cid": cid, "page": part, "logged": bool(sess), "fmt": fmt}
        return self._json(data)

    def _cdn(self, qs):
        # 媒体流转发：浏览器无法伪造 Referer，部分 B 站 CDN 镜像会因此 403，
        # 由本地代理注入官方 Referer 后透传 Range 请求与 206 响应
        u = q(qs, "u")
        pu = urlparse(u)
        host = pu.hostname or ""
        if pu.scheme != "https" or not (host == "bilivideo.com"
                or host.endswith(".bilivideo.com") or host.endswith(".bilivideo.cn")):
            return self._json({"code": -403, "message": "forbidden host"}, 403)
        headers = {"User-Agent": UA, "Referer": "https://www.bilibili.com/"}
        rng = self.headers.get("Range")
        if rng:
            headers["Range"] = rng
        req = Request(u, headers=headers)
        try:
            with urlopen(req, timeout=30) as r:
                self.send_response(r.status)
                for hh in ("Content-Type", "Accept-Ranges", "Content-Range", "Cache-Control"):
                    vv = r.headers.get(hh)
                    if vv:
                        self.send_header(hh, vv)
                cl = r.headers.get("Content-Length")
                if cl:
                    self.send_header("Content-Length", cl)
                else:
                    self.send_header("Connection", "close")
                    self.close_connection = True
                self.end_headers()
                shutil.copyfileobj(r, self.wfile, 64 * 1024)
        except HTTPError as e:
            body = e.read()
            self.send_response(e.code)
            ct = e.headers.get("Content-Type", "application/octet-stream")
            self.send_header("Content-Type", ct)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            if body:
                self.wfile.write(body)
        except URLError as e:
            self._json({"code": -1, "message": "CDN 连接失败：%s" % e.reason}, 502)

    def _me(self, qs):
        sess = self._sess(qs)
        if not sess:
            return self._json({"code": 0, "data": {"isLogin": False}})
        j = http_get(API + "/x/web-interface/nav", sess)
        d = j.get("data") or {}
        return self._json({"code": j.get("code", -1),
                           "data": {"isLogin": bool(d.get("isLogin")),
                                    "uname": d.get("uname", ""),
                                    "vip": d.get("vipStatus", 0)}})

    def _meta(self, qs):
        # 视频信息：标题 + 分 P 列表（part），用于批量导入时自动识别每集标题
        bvid = q(qs, "bvid")
        aid = q(qs, "aid")
        if not bvid and not aid:
            return self._json({"code": -2, "message": "缺少 bvid / aid"})
        ident = "bvid=%s" % quote(bvid) if bvid else "aid=%s" % quote(aid)
        sess = self._sess(qs)
        # 分 P 列表（含每 P 的 part 标题）几乎不变，缓存 6 小时；
        # 不用 /x/web-interface/view，该接口被 B 站风控（无 WBI 签名返回 412）。
        url = "%s/x/player/pagelist?%s" % (API, ident)
        j = cached_get("meta:" + ident, url, sess, "https://www.bilibili.com/", 21600)
        if j.get("code") != 0:
            return self._json({"code": j.get("code", -1),
                               "message": "视频信息获取失败：%s" % j.get("message", "")})
        d = j.get("data") or []
        pages = d if isinstance(d, list) else (d.get("pages") or [])
        return self._json({"code": 0, "data": {
            "title": "",
            "pages": [{"page": p.get("page"), "part": p.get("part", ""),
                       "cid": p.get("cid"), "duration": p.get("duration")} for p in pages]
        }})

    def _collection(self, qs):
        # 合集：space.bilibili.com/{mid}/channel/collectiondetail?sid=xxx
        # 循环分页拉取合集内全部视频（每集一个独立视频，带标题）
        sid = q(qs, "sid")
        if not sid:
            return self._json({"code": -2, "message": "缺少合集 id (sid)"})
        sess = self._sess(qs)
        videos, name, page, total = [], "", 1, None
        while True:
            url = ("%s/x/polymer/web-space/seasons_archives_list?season_id=%s"
                   "&page_num=%d&page_size=30" % (API, quote(sid), page))
            j = http_get(url, sess, "https://www.bilibili.com/")
            if j.get("code") != 0:
                return self._json({"code": j.get("code", -1),
                                   "message": "合集获取失败：%s" % j.get("message", "")})
            d = j.get("data") or {}
            if not name:
                meta = d.get("meta") or {}
                name = meta.get("name", "") or meta.get("title", "")
            arch = d.get("archives") or []
            for a in arch:
                videos.append({"title": a.get("title", ""),
                               "bvid": a.get("bvid", ""),
                               "aid": a.get("aid", ""),
                               "duration": a.get("duration", 0)})
            pg = d.get("page") or {}
            if total is None:
                total = pg.get("total") or len(arch)
            if not arch or len(videos) >= total or page * 30 >= total or len(videos) >= 2000:
                break
            page += 1
        if not videos:
            return self._json({"code": -3, "message": "该合集没有视频"})
        return self._json({"code": 0, "data": {"name": name,
                                               "total": len(videos),
                                               "videos": videos}})


    def _favlist(self, qs):
        # 收藏夹：space.bilibili.com/{mid}/favlist?fid=xxx 或 medialist/detail/ml{id} 或 lists/{id}?type=fav
        # 循环分页拉取收藏夹内全部视频（带标题）
        fid = q(qs, "fid")
        if not fid:
            return self._json({"code": -2, "message": "缺少收藏夹 id (fid)"})
        sess = self._sess(qs)
        videos, name, page = [], "", 1
        while True:
            url = ("%s/x/v3/fav/resource/list?media_id=%s&pn=%d&ps=20"
                   % (API, quote(fid), page))
            j = http_get(url, sess, "https://www.bilibili.com/")
            if j.get("code") != 0:
                return self._json({"code": j.get("code", -1),
                                   "message": "收藏夹获取失败：%s" % j.get("message", "")})
            d = j.get("data") or {}
            if not name:
                info = d.get("info") or {}
                name = info.get("title", "")
            med = d.get("medias") or []
            for m in med:
                bv = m.get("bvid", "") or ""
                if not bv:
                    continue
                videos.append({"title": m.get("title", ""), "bvid": bv,
                               "aid": m.get("id", ""), "duration": m.get("duration", 0)})
            if not med or not d.get("has_more"):
                break
            page += 1
            if len(videos) >= 2000:
                break
        if not videos:
            return self._json({"code": -3, "message": "该收藏夹没有可导入的视频（私密收藏夹需先扫码登录）"})
        return self._json({"code": 0, "data": {"name": name,
                                               "total": len(videos),
                                               "videos": videos}})


    def _pgc(self, qs):
        # 番剧/综艺/电视剧整季：bangumi/play/ss{season_id}
        # 用 pgc/view/web/season 一次拉取整季全部剧集（每集带 ep_id/标题）
        ssid = q(qs, "ssid")
        ep = q(qs, "ep")
        if not ssid and not ep:
            return self._json({"code": -2, "message": "缺少番剧季 id (ssid) 或单集 ep"})
        sess = self._sess(qs)
        if ep and not ssid:
            # 从单集页面反查整季 season_id
            try:
                html = http_get_text("https://www.bilibili.com/bangumi/play/ep%s" % quote(ep),
                                     sess, "https://www.bilibili.com/")
            except Exception as e:
                return self._json({"code": -3, "message": "单集页面获取失败：%s" % e})
            m = re.search(r'"season_id"\s*:\s*(\d+)', html)
            if not m:
                return self._json({"code": -3, "message": "无法从单集反查到整季，请改用整季 ss 链接"})
            ssid = m.group(1)
        url = "%s/pgc/view/web/season?season_id=%s" % (API, quote(ssid))
        j = http_get(url, sess, "https://www.bilibili.com/bangumi/play/ss%s" % ssid)
        if j.get("code") != 0:
            return self._json({"code": j.get("code", -1),
                               "message": "番剧获取失败：%s" % j.get("message", "")})
        r = j.get("result") or {}
        eps = r.get("episodes") or []
        videos = []
        for e in eps:
            videos.append({"title": e.get("title", ""), "bvid": e.get("bvid", "") or "",
                           "aid": e.get("aid", "") or "", "cid": e.get("cid", "") or "",
                           "ep": e.get("id", "") or "", "duration": e.get("duration", 0)})
        if not videos:
            return self._json({"code": -3, "message": "该番剧没有可导入的剧集"})
        name = r.get("title", "") or r.get("season_title", "")
        return self._json({"code": 0, "data": {"name": name,
                                               "total": len(videos),
                                               "videos": videos}})


    def _up(self, qs):
        # UP 主主页全部视频：space.bilibili.com/{mid} 或 /video
        # 需登录（arc/search 未登录会被 B 站风控 -352）
        mid = q(qs, "mid")
        if not mid:
            return self._json({"code": -2, "message": "缺少 UP 主 id (mid)"})
        sess = self._sess(qs)
        if not sess:
            return self._json({"code": -4, "message": "拉取 UP 主全部视频需要登录，请先在设置页扫码登录"})
        videos, name, page = [], "", 1
        try:
            for _a in range(5):
                p, w = _wbi_sign({"mid": mid}, sess)
                uj = http_get("%s/x/space/wbi/acc/info?mid=%s&wts=%d&w_rid=%s"
                              % (API, quote(mid), p["wts"], w), sess,
                              "https://space.bilibili.com/%s/video" % mid)
                if uj.get("code") == 0:
                    name = (uj.get("data") or {}).get("name", "")
                    break
                time.sleep(0.5)
        except Exception:
            pass
        while True:
            j = None
            for _a in range(6):
                p, w = _wbi_sign({"mid": mid, "ps": 30, "pn": page, "order": "pubdate"}, sess)
                url = ("%s/x/space/wbi/arc/search?mid=%s&ps=30&pn=%d&order=pubdate"
                       "&wts=%d&w_rid=%s" % (API, quote(mid), page, p["wts"], w))
                try:
                    j = http_get(url, sess, "https://space.bilibili.com/%s/video" % mid)
                except HTTPError as e:
                    if e.code != 412:
                        raise
                    j = None
                if j and j.get("code") == 0:
                    break
                j = None
                time.sleep(0.6)
            if not j:
                return self._json({"code": -3, "message": "UP 主视频获取失败（B 站接口风控，请稍后重试）"})
            d = j.get("data") or {}
            v = (d.get("list") or {}).get("vlist") or []
            for x in v:
                videos.append({"title": x.get("title", ""), "bvid": x.get("bvid", ""),
                               "aid": x.get("aid", ""), "duration": x.get("length", "")})
            cnt = (d.get("page") or {}).get("count")
            if not v or (cnt is not None and len(videos) >= cnt) or page * 30 >= 2000:
                break
            page += 1
        if not videos:
            return self._json({"code": -3, "message": "该 UP 主没有视频"})
        return self._json({"code": 0, "data": {"name": name or ("UP主 " + mid),
                                               "total": len(videos),
                                               "videos": videos}})


    def _qrgen(self):
        # 扫码登录：生成 B 站登录二维码（SVG），前端展示并轮询
        try:
            import segno
        except Exception:
            return self._json({"code": -1,
                               "message": "缺少二维码库 segno，请运行: python -m pip install segno"})
        try:
            j = http_get("https://passport.bilibili.com/x/passport-login/web/qrcode/generate")
            d = j.get("data") or {}
            key = d.get("qrcode_key", "")
            url = d.get("url", "")
            if not key:
                return self._json({"code": j.get("code", -1),
                                   "message": j.get("message", "生成二维码失败")})
            buf = io.BytesIO()
            segno.make(url).save(buf, kind="svg", scale=4, border=2)
            return self._json({"code": 0, "key": key, "svg": buf.getvalue().decode("utf-8")})
        except HTTPError as e:
            return self._json({"code": -e.code, "message": "生成二维码失败：HTTP %s" % e.code})
        except URLError as e:
            return self._json({"code": -1, "message": "生成二维码失败：%s" % e.reason})
        except Exception as e:
            return self._json({"code": -1, "message": "生成二维码失败：%s" % e})

    def _qrpoll(self, qs):
        # 轮询扫码结果；登录成功后从 Set-Cookie 提取 SESSDATA 并写入 sessdata.txt
        key = q(qs, "key")
        if not key:
            return self._json({"code": -2, "message": "缺少 key"})
        url = "https://passport.bilibili.com/x/passport-login/web/qrcode/poll?qrcode_key=%s" % quote(key)
        headers = {"User-Agent": UA, "Referer": "https://www.bilibili.com/", "Accept": "application/json"}
        try:
            with urlopen(Request(url, headers=headers), timeout=12) as r:
                raw = r.read()
                setcookie = r.headers.get("Set-Cookie") or ""
        except HTTPError as e:
            return self._json({"code": -e.code, "message": "轮询失败：HTTP %s" % e.code})
        except URLError as e:
            return self._json({"code": -1, "message": "轮询失败：%s" % e.reason})
        try:
            d = json.loads(raw.decode("utf-8", "replace"))
        except Exception:
            d = {}
        sess = None
        m = re.search(r"SESSDATA=([^;]+)", setcookie)
        if m:
            sess = m.group(1)
        written = False
        if sess:
            try:
                with io.open(SESS_FILE, "w", encoding="utf-8") as f:
                    f.write(sess)
                written = True
            except Exception:
                written = False
        inner = (d.get("data") or {}) if isinstance(d.get("data"), dict) else {}
        return self._json({"code": d.get("code"), "message": d.get("message"),
                           "scan": inner.get("code"), "sessdata": sess, "written": written})


def _parse_xlsx(raw):
    NS = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
    RID = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"

    def colidx(ref):
        c = 0
        for ch in ref or "":
            if ch.isalpha():
                c = c * 26 + (ord(ch) - 64)
            else:
                break
        return c - 1

    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        wb = ET.fromstring(z.read("xl/workbook.xml"))
        rels = ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
        relmap = {}
        for r in rels:
            relmap[r.get("Id")] = r.get("Target", "").lstrip("/")
        sst = []
        try:
            ss = ET.fromstring(z.read("xl/sharedStrings.xml"))
            for si in ss.findall(NS + "si"):
                sst.append("".join(t.text or "" for t in si.iter(NS + "t")))
        except Exception:
            pass
        sheets = []
        for sh in wb.find(NS + "sheets"):
            name = sh.get("name")
            rid = sh.get(RID)
            target = relmap.get(rid, "")
            if not target:
                continue
            if not target.startswith("xl/"):
                target = "xl/" + target
            try:
                root = ET.fromstring(z.read(target))
            except Exception:
                continue
            rows = []
            for row in root.iter(NS + "row"):
                cells, maxc = {}, -1
                for c in row.findall(NS + "c"):
                    ci = colidx(c.get("r")); t = c.get("t"); v = c.find(NS + "v")
                    if t == "s" and v is not None:
                        val = sst[int(v.text)] if v.text else ""
                    elif t == "inlineStr":
                        is_ = c.find(NS + "is")
                        val = "".join(x.text or "" for x in (is_.iter(NS + "t") if is_ is not None else []))
                    elif v is not None:
                        val = v.text
                    else:
                        val = ""
                    cells[ci] = val
                    maxc = max(maxc, ci)
                rows.append([cells.get(i, "") for i in range(maxc + 1)])
            sheets.append({"name": name, "rows": rows})
        return sheets


def _make_xlsx(sheets):
    def esc(s):
        return str(s).replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;')
    n = len(sheets)
    ct = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
          '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">',
          '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>',
          '<Default Extension="xml" ContentType="application/xml"/>']
    for i in range(n):
        ct.append('<Override PartName="/xl/worksheets/sheet%d.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' % (i + 1))
    ct.append('<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/></Types>')
    root_rels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                 '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                 '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
                 '</Relationships>')
    wb = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
          '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>']
    for i, s in enumerate(sheets):
        wb.append('<sheet name="%s" sheetId="%d" r:id="rId%d"/>' % (esc(s['name']), i + 1, i + 1))
    wb.append('</sheets></workbook>')
    wb_rels = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
               '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">']
    for i in range(n):
        wb_rels.append('<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet%d.xml"/>' % (i + 1, i + 1))
    wb_rels.append('</Relationships>')

    def sheet_xml(rows):
        lines = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
                 '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>']
        for ri, row in enumerate(rows, 1):
            cells = []
            for ci, val in enumerate(row):
                if val is None or str(val) == '':
                    continue
                cells.append('<c r="%s%d" t="inlineStr"><is><t>%s</t></is></c>' % (chr(65 + ci), ri, esc(val)))
            if cells:
                lines.append('<row r="%d">%s</row>' % (ri, ''.join(cells)))
        lines.append('</sheetData></worksheet>')
        return ''.join(lines)
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.writestr('[Content_Types].xml', ''.join(ct))
        zf.writestr('_rels/.rels', root_rels)
        zf.writestr('xl/workbook.xml', ''.join(wb))
        zf.writestr('xl/_rels/workbook.xml.rels', ''.join(wb_rels))
        for i, s in enumerate(sheets):
            zf.writestr('xl/worksheets/sheet%d.xml' % (i + 1), sheet_xml(s['rows']))
    return buf.getvalue()


def _blank_timetable():
    header = ['开始', '结束', '时长(分)', '学习安排', '类型', '弹性说明 / 备注']
    sheets = []
    for name in ['周一', '周二', '周三', '周四', '周五', '周六']:
        rows = [[name + ' · 弹性课程表（可自行填写，填好后在任务板块一键导入）'],
                ['学习块顺序固定；类型可选：学习 / 刷题整理 / 俄语课；餐窗/课间/机动可不填'],
                [],
                header]
        for _ in range(14):
            rows.append(['', '', '', '', '', ''])
        sheets.append({'name': name, 'rows': rows})
    return sheets


def _parse_multipart(raw, ctype):
    """极简 multipart/form-data 解析（只支持本程序自己发的那一种格式）。

    返回 (fields: {name: bytes}, files: {name: bytes})。
    只用标准库：正文里按 boundary 切分，每段再按空行拆头部/正文。
    """
    m = re.search(r'boundary="?([^";]+)"?', ctype)
    if not m:
        raise ValueError("缺少 boundary")
    boundary = ("--" + m.group(1)).encode()
    fields, files = {}, {}
    # 先按 boundary 切块，再去掉每块首尾的 CRLF
    for chunk in raw.split(boundary):
        if not chunk or chunk in (b"--", b"--\r\n", b"\r\n"):
            continue
        chunk = chunk.lstrip(b"\r\n")
        head_end = chunk.find(b"\r\n\r\n")
        if head_end < 0:
            continue
        head = chunk[:head_end].decode("utf-8", "replace")
        body = chunk[head_end + 4:]
        # 只去掉紧挨 boundary 的那**一个** CRLF。
        # 以前写的是 body.rstrip(b"\r\n") —— 那会把正文尾部所有 \r/\n 都吃掉：
        # 二进制附件若以 \r 或 \n 结尾，就会静默少 1 个字节（实测过：131072 → 131071）。
        if body.endswith(b"\r\n"):
            body = body[:-2]
        elif body.endswith(b"\n"):
            body = body[:-1]
        nm = re.search(r'name="([^"]*)"', head)
        if not nm:
            continue
        name = nm.group(1)
        # 注意：浏览器 / Node 的 FormData 会给 Blob 也带上 filename，
        # 所以不能靠 filename 判断是字段还是文件 —— 按约定：blobs[...] 是附件，其余是字段。
        if name.startswith("blobs["):
            files[name[len("blobs["):].rstrip("]")] = body
        else:
            fields[name] = body
    return fields, files


def _valid_blob_id(bid):
    """附件 id 是本程序生成的 uid（日期 base36 + 随机串），只允许字母数字。"""
    return bool(bid) and isinstance(bid, str) and len(bid) <= 64 and bool(re.fullmatch(r"[A-Za-z0-9_-]+", bid))


# 允许作为附件响应 Content-Type 的**安全内联**类型白名单。
#
# 为什么需要白名单：附件字节是用户内容，若允许把 Content-Type 指定成 text/html
# （或 image/svg+xml、application/xhtml+xml、text/xml 等可脚本化的类型），
# 浏览器就会在应用同源下把它当页面执行 —— 存储型 XSS。
# 白名单只保留"渲染出来无法执行脚本"的类型，覆盖应用真实需要的内联预览场景。
_SAFE_BLOB_CTYPES = {
    "application/pdf",
    "image/png", "image/jpeg", "image/gif", "image/webp", "image/bmp", "image/avif",
    "video/mp4", "video/webm", "video/ogg",
    "audio/mpeg", "audio/ogg", "audio/wav", "audio/mp4",
    "text/plain",
}


def _safe_blob_ctype(ctype):
    """把请求里的 type 收敛到白名单；不在名单内（含空/畸形/可执行类型）一律 octet-stream。"""
    if not ctype or not isinstance(ctype, str):
        return "application/octet-stream"
    # 只取分号前的 MIME 本体，忽略 charset 等参数
    base = ctype.split(";", 1)[0].strip().lower()
    return base if base in _SAFE_BLOB_CTYPES else "application/octet-stream"


def _purge_blobs(keep):
    """删掉不再被备份引用的附件文件，避免无界增长。返回删除数量。"""
    if not os.path.isdir(AB_BLOBS):
        return 0
    removed = 0
    for name in os.listdir(AB_BLOBS):
        if name.endswith(".tmp") or name not in keep:
            try:
                os.remove(os.path.join(AB_BLOBS, name))
                removed += 1
            except OSError:
                pass
    return removed


def _port_in_use(port):
    """该端口上是否已经有一个**正在接受连接**的服务。

    为什么不靠 bind 报错来判断：Windows 上 SO_REUSEADDR 的语义是"允许抢占"，
    而 Python 的 HTTPServer 默认 allow_reuse_address=1 —— 于是第二个 server.py
    能成功绑上同一个端口，下面那段"端口被占用"的提示**永远不会触发**。
    后果非常隐蔽：两个进程同时服务同一个端口，请求被随机分给新旧两套代码，
    表现出来就是"有的改动生效了、有的没生效"，极难排查（真实踩过）。
    探活用 connect：TIME_WAIT 的残留连接不会接受连接，所以不会误判成"已占用"。"""
    s = socket.socket()
    s.settimeout(0.6)
    try:
        s.connect(("127.0.0.1", port))
        return True
    except Exception:
        return False
    finally:
        try:
            s.close()
        except Exception:
            pass


def main():
    # 默认固定端口 8787：IndexedDB 数据按「端口」隔离，换端口会看不到原有数据。
    # 若 8787 被占用则明确提示，绝不静默换端口（否则数据就像「消失」了）。
    #
    # 例外：STUDYDECK_PORT 仅供**自动化测试**用（真实启动不会设它）。
    # 测试必须能在 8787 被占（用户正开着课业）时照常跑 —— 否则一开着应用就没法回归。
    # 默认值不变，所以用户侧行为完全不受影响。
    port = 8787
    if os.environ.get("STUDYDECK_PORT"):
        try:
            port = int(os.environ["STUDYDECK_PORT"])
        except ValueError:
            port = 8787
    # 先探活再 bind：见 _port_in_use 的说明（Windows 上 bind 不会报错）
    if _port_in_use(port):
        print("=" * 64)
        print("  端口 %d 上已经有一个「课业」在运行，本次启动已取消。" % port)
        print("  你的数据是按端口(%d)保存的，同时开两个会让请求随机落到新旧两份代码上。" % port)
        print("  请先关闭原来那个窗口（或结束占用 %d 的进程），再重新启动本程序。" % port)
        print("=" * 64)
        sys.exit(1)
    while True:
        try:
            server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
            break
        except OSError:
            print("=" * 64)
            print("  端口 %d 已被占用，启动失败。" % port)
            print("  你的数据是按端口(%d)保存的，换端口会看不到原有数据。" % port)
            print("  多半是上次的「课业」程序还开着（占用了 %d）。" % port)
            print("  请先关闭占用 %d 的窗口/进程，再重新启动本程序。" % port)
            print("=" * 64)
            sys.exit(1)
    url = "http://127.0.0.1:%d/" % port
    print("StudyDeck HD proxy running at: %s" % url)
    print("Keep this window open. Close it to stop the proxy.")
    threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
