// @ts-check
// 设置页的备份 / 恢复 / 云备份 / 本机自动备份。
//
// 从 app.js 拆出来是为了打断 app ⇄ views-dispatch 这个 import 环：
//   views-dispatch.js 需要这几个 UI 动作（导出/导入/清空/云备份卡片）；
//   app.js 需要视图注册表（副作用 import views-dispatch）。
// 把被需要的那半边挪到这里之后，两边都只依赖本模块，环就断了。

import { I } from './icons.js';
import { SECRET_SETTINGS } from './core.js';
import { STORE_KEYS } from './schema.js';
import { S, dbAll, dbClear, dbDel, dbPut, dbPutMany, kvGet, kvSet, loadAll, openDB, resetSettings, saveSettings } from './db.js';
import { confirmDialog, openModal, toast } from './ui.js';
import { $, dataSig, downloadBlob, el, esc, fmtDateTime, safeColor, todayKey } from './util.js';
import { applyTheme, render } from './viewkit.js';

/** @param {Blob} blob @returns {Promise<string>} */
function blobToDataURL(blob){return new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(/** @type {any} */ (r.result));r.onerror=rej;r.readAsDataURL(blob);});}

/** @param {string} u @returns {Blob} */
function dataURLToBlob(u){
  const head=u.slice(0,u.indexOf(',')), b64=u.slice(u.indexOf(',')+1);
  const mime=(head.match(/data:(.*?);/)||[,])[1]||'application/octet-stream';
  const bin=atob(b64),arr=new Uint8Array(bin.length);
  for(let i=0;i<bin.length;i++)arr[i]=bin.charCodeAt(i);
  return new Blob([arr],{type:mime});
}

const BACKUP_VERSION=3;

/* 构建备份（元数据 + 附件清单）。
   附件二进制不再 Base64 进 JSON：本机自动备份走二进制通道（multipart 上传 / 按需下载），
   云备份把原始二进制写进 blobs/ 子目录 —— 避免每次备份都序列化几十 MB。 */

/** @param {any} data @returns {any} */
function backupMeta(data){const c={...data};delete c._blobParts;return c;}
/* 取回一个附件二进制（本地备份 / 云备份两条路径共用）。 */

async function buildBackupData(){
  const blobs=await dbAll('blobs'); const files=[]; const parts=[];
  const _maxBlob=15*1024*1024; let _skipped=0; const _skippedIds=new Set(); let _blobBytes=0; let _skippedBytes=0;
  for(const b of blobs){
    if(b.blob)_blobBytes+=(b.blob.size||0);
    if(b.blob&&b.blob.size>_maxBlob){_skipped++;_skippedBytes+=(b.blob.size||0);_skippedIds.add(b.id);continue;}
    if(!b.blob)continue;
    files.push({id:b.id,size:b.blob.size||0,type:b.blob.type||'application/octet-stream'});
    parts.push({id:b.id,blob:b.blob});
  }
  /* 把「哪些附件的文件内容没被打包」写进备份本身，恢复时显式标成数据缺失 */
  const _packedIds=new Set(files.map(f=>f.id));
  const _atts=(await dbAll('attachments')).map(a=>{
    const miss=a.missing||_skippedIds.has(a.id)||!_packedIds.has(a.id);
    return miss?(a.missing?a:Object.assign({},a,{missing:true})):a;
  });
  /* 密钥一律不进备份：清单来自 core.js 的单一真源（与 dataSig 脱敏共用同一份）。
     safeSettings 特意标成 Record<string,any> —— 它是"待删除若干键的副本"，
     按 S.settings 的精确类型去索引 SECRET_SETTINGS 里的字符串键会被 tsc 拒（TS7053）。 */
  const safeSettings=/** @type {Record<string,any>} */ ({...S.settings});
  for(const k of SECRET_SETTINGS)delete safeSettings[k];
  const data={app:'studydeck',version:BACKUP_VERSION,exportedAt:Date.now(),
    courses:S.courses,
    episodes:S.episodes.map(e=>{const c={...e};delete c.fileHandle;return c;}),
    notes:S.notes,attachments:_atts,resources:S.resources,sessions:S.sessions,mistakes:S.mistakes,tasks:S.tasks,tasklog:S.tasklog,settings:safeSettings,files,
    _skippedBlobs:_skipped,_skippedIds:[..._skippedIds],_blobBytes,_skippedBytes};
  /** @type {any} */ (data)._blobParts=parts;      /* 仅供本次调用的二进制通道使用，不会写进 JSON */
  return data;
}
/* 元数据副本：去掉仅供传输用的私有字段。 */

/** @param {any} urls @returns {Promise<any>} */
function blobFetch(urls){
  return (async()=>{
    let lastErr=null;
    for(const u of urls){
      try{const r=await fetch(u);if(!r.ok)throw new Error('HTTP '+r.status);return await r.blob();}catch(e){lastErr=e;}
    }
    throw lastErr||new Error('无法获取附件');
  })();
}
/* 从本机自动备份水合附件：只取本机没有的。 */

/** @param {any} meta @returns {Promise<number>} 实际水合回来的附件数 */
async function hydrateFromLocalBackup(meta){
  const wanted=(meta.files||[]).filter((/** @type {any} */ f)=>f&&f.id);
  if(!wanted.length)return 0;
  const have=new Set((await dbAll('blobs')).filter(b=>b&&b.blob).map(b=>b.id));
  let n=0;
  for(const f of wanted){
    if(have.has(f.id))continue;
    try{
      const blob=await blobFetch(['/api/autobackup/blob?id='+encodeURIComponent(f.id)+'&type='+encodeURIComponent(f.type||'')]);
      await dbPut('blobs',{id:f.id,blob});
      n++;
    }catch(e){}
  }
  return n;
}

async function exportData(){
  const data=await buildBackupData();
  const n=(data.files||[]).length;
  const mb=Math.round((data._blobBytes||0)/1048576*10)/10;
  /* 导出的 JSON 只含元数据 + 附件清单，**不含任何附件二进制**（v3 起附件走独立通道）。
     这一点必须提前说清楚：用户按「换机前先导出备份」操作时只带走这个文件，附件是拿不走的。 */
  if(n||data._skippedBlobs){
    const smb=Math.round((data._skippedBytes||0)/1048576*10)/10;
    const extra=data._skippedBlobs?('\n\n另外有 '+data._skippedBlobs+' 个附件（约 '+smb+'MB）超过单文件 15MB 上限，'+
      '本机自动备份与云备份同样不会打包它们，请单独另存。'):'';
    const go=await confirmDialog('这是一个「元数据备份」',
      '导出的 JSON 包含：课程、分集、笔记正文、错题、任务、学习记录，以及 '+n+' 个附件的名称/大小/类型。\n\n'+
      '它**不包含附件文件本身**（约 '+mb+'MB 的图片、PDF 等）。之所以这样设计，是因为把附件 Base64 进 JSON 会让文件膨胀 33%、每次备份都要整体序列化。\n\n'+
      '附件由这两条路保存，换机时请一并带走：\n'+
      '· 设置 → 自动云备份（选一个网盘同步文件夹，附件放在 blobs/ 子目录）\n'+
      '· 程序目录下的 _autobackup/（本机自动备份）'+extra+
      '\n\n仍然导出吗？','仍然导出');
    if(!go)return;
  }else{
    toast('正在打包备份…');
  }
  downloadBlob('studydeck-backup-'+todayKey()+'.json',new Blob([JSON.stringify(backupMeta(data))],{type:'application/json'}));
  toast('已导出元数据备份'+(n?('（含 '+n+' 个附件清单，附件文件需另行保留）'):''),'ok');
}

/** mode 的实际取值是 'merge' / 'over'（见下面 openModal 里的两个按钮），
 *  不是 'replace' —— 我之前注解成 'replace' 导致下面 `mode==='over'` 被报成 TS2367
 *  "两个类型没有交集"，看起来像死代码，其实是注解写错了。
 *  @param {any} data @param {'merge'|'over'} mode @returns {Promise<any>} */
async function applyBackupData(data,mode){
  if(mode==='over'){
    try{const rollback=await buildBackupData();
      downloadBlob('pre-overwrite-rollback-'+todayKey()+'-'+Date.now()+'.json',new Blob([JSON.stringify(backupMeta(rollback))],{type:'application/json'}));
      toast('已自动生成覆盖前备份，需要时可用它恢复','ok');
    }catch(e){}
    /* 注意：**不能**在这里清 blobs。
       新格式（v3）的附件二进制不在 JSON 里，而是恢复前由 hydrateFrom*Backup() 写进 blobs；
       若此处 dbClear('blobs')，刚水合回来的附件会被立刻清空 —— 覆盖恢复就等于丢掉全部附件。
       多余的 blob（不在本次备份里的）由随后的 auditAttachments() 当孤儿删掉。 */
    for(const st of ['courses','episodes','notes','attachments','sessions','mistakes','tasks','tasklog','resources'])await dbClear(st);
  }
  /* 记录形状守卫：备份文件是外部输入，字段缺失的记录会被下游按固定字段读取
     （notesOfEp 读 n.epIds、openAttachment 读 a.type），放进去就会在用户点开时才抛。
     用类型谓词写法，过滤之后 tsc 就知道元素是什么类型了 —— 否则这 9 行会报 20 个隐式 any。 */
  /** @template T @param {any} v @param {string} field @returns {v is T} */
  const hasStr=(v,field)=>!!v&&typeof v==='object'&&typeof v[field]==='string';
  /* 主键不仅要"是字符串"，还必须是**安全的字符集**。
     备份文件是外部输入：主键会被拼进 35+ 处 data-* 属性（`data-id="'+rec.id+'"`），
     只查 typeof 就允许 id = `" onclick=alert(1) x="` 逃逸出属性 → 存储型 XSS。
     合法形状实测全覆盖：uid() 是 base36（纯字母数字），tasklog 的 key 是 `tid@YYYY-MM-DD`，
     kv 的 key 是固定标识符 —— 都在 [A-Za-z0-9_.:-] 内，所以这个白名单不会误伤真实数据。
     不合规的记录**整条丢弃**（宁少恢复一条，也不把能注入的记录收进来）。 */
  const SAFE_ID=/^[A-Za-z0-9_.:@-]{1,128}$/;
  /** @param {any} v @param {string} field @returns {boolean} */
  const hasSafeKey=(v,field)=>hasStr(v,field)&&SAFE_ID.test(/** @type {any} */ (v)[field]);
  /* 主键字段名**从 schema 取**，不在这里再写一遍。
     这样 tasklog 那种「主键其实是 key、却按 id 过滤」的 bug 不是"被检测"，而是"写不出来"：
     字段名只存在于 schema.js 一处，过滤与建表读的是同一个值。
     （db.js 建表已经这么做了；这里把同一原则推到导入过滤这一层。） */
  /** @type {Record<string,string>} */
  const KEY_OF=STORE_KEYS;
  /** @param {string} store @param {any} arr @returns {any[]} */
  const byKey=(store,arr)=>/** @type {any[]} */ ((arr||[]).filter((/** @type {any} */ x)=>hasSafeKey(x,KEY_OF[store])));
  /* 除主键外的额外形状要求：字段**缺失**容忍，**存在但类型错**才拒绝。
     颜色一律净化：不合规的 color 会在渲染时拼进 style，必须挡在入库前（纵深防御之一）。 */
  /** @param {string} store @param {any} x @returns {boolean} */
  const extraOk=(store,x)=>{
    if(store==='courses'){ x.color=safeColor(x.color); return typeof x.name==='string'; }
    if(store==='episodes')return typeof x.courseId==='string';
    if(store==='notes')return (x.epIds===undefined||Array.isArray(x.epIds))&&(x.courseId===undefined||typeof x.courseId==='string');
    if(store==='attachments')return (x.type===undefined||typeof x.type==='string')&&(x.noteId===undefined||typeof x.noteId==='string');
    return true;
  };
  /** @param {string} store @returns {any[]} */
  const importable=store=>byKey(store,data[store]).filter((x)=>extraOk(store,x));

  await dbPutMany('courses',importable('courses'));
  await dbPutMany('episodes',importable('episodes').map((/** @type {any} */ e)=>{delete e.fileHandle;return e;}));
  /* 导入的形状校验要和 courses/episodes 一样严格：
     下面这些记录会被下游按固定字段读取（如 notesOfEp 读 n.epIds、openAttachment 读 a.type），
     放进来一条缺字段的记录，就会在用户点开分集笔记 / 附件时才抛异常。
     宁可少恢复一条坏记录，也不要把「自己渲染不了的形状」收进来。 */
  await dbPutMany('notes',importable('notes'));
  await dbPutMany('attachments',importable('attachments'));
  await dbPutMany('sessions',importable('sessions'));
  await dbPutMany('mistakes',importable('mistakes'));
  await dbPutMany('tasks',importable('tasks'));
  await dbPutMany('tasklog',importable('tasklog'));
  await dbPutMany('resources',importable('resources'));
  /* 新格式的 files[] 只有清单（二进制由 hydrate* 先行落库）；旧格式带 Base64 的 data，照旧还原。 */
  for(const fl of (data.files||[])){
    /* 旧格式（v2）带 Base64 的 data：这里的 fl.id 同样来自外部输入，
       也写进 blobs 表，所以一并过主键白名单。 */
    if(fl&&fl.data&&SAFE_ID.test(String(fl.id||'')))await dbPut('blobs',{id:fl.id,blob:dataURLToBlob(fl.data)});
  }
  if(data.settings){
    /* settings 是外部输入，且会被渲染进表单（如 views-dispatch 的 value="..."）。
       原来这里直接 Object.assign 全盘接收，等于允许注入任意字段（含 HTML）。
       改为**白名单 + 逐字段类型校验**：只收已知键、类型对了才写。 */
    /** @type {Record<string,'string'|'number'|'boolean'>} */
    const SETTING_TYPES={theme:'string',dailyGoal:'number',autoLocal:'boolean',autoBackup:'boolean',
      autoNext:'boolean',biliMode:'string',biliQn:'number',sessdata:'string',
      timerTickSound:'boolean',showCountdown:'boolean',countdownDate:'string',
      aiApiKey:'string',aiBaseUrl:'string',aiModel:'string',aiNotesPrompt:'string'};
    /** @type {Record<string,any>} */
    const clean={};
    for(const [k,ty] of Object.entries(SETTING_TYPES)){
      if(!(k in data.settings))continue;
      if(typeof data.settings[k]!==ty)continue;
      clean[k]=data.settings[k];
    }
    if(typeof clean.theme==='string'&&!['light','dark','auto'].includes(clean.theme))clean.theme='light';
    if(typeof clean.biliMode==='string'&&!['auto','embed','direct','external'].includes(clean.biliMode))clean.biliMode='auto';
    Object.assign(S.settings,clean);
  }
  await saveSettings();applyTheme();await loadAll();
  const audit=await auditAttachments();
  render();
  return audit;
}

/* 恢复/导入后核对附件：元数据可能完整，但文件内容可能因超限没被打包。
   逐条用真实占用大小比对，把对不上的显式标为 missing，删除孤儿二进制。 */

async function auditAttachments(){
  const blobs=await dbAll('blobs');
  const sizeOf=new Map();
  for(const b of blobs) sizeOf.set(b.id,(b.blob&&b.blob.size)||0);
  const have=new Set(sizeOf.keys());
  const missingIds=new Set();
  for(const a of S.attachments){ if(!have.has(a.id)||(a.size&&sizeOf.get(a.id)!==a.size)) missingIds.add(a.id); }
  /* 资料库的 blob id 有两种形状，**都要算进 keep 集合**：
       · folder-item（文件夹上传）：每个子文件挂在 r.files[] 里，id 各不相同；
       · 普通文件（uploadResources）：blob 直接用**资源自身的 id** 存
         （views-resources.js:167-170 同一个 id 既写 blobs 又写 resources；
          读取处 views-resources.js:222 dbGet('blobs',id) 用的也是 r.id）。
     只收 r.files[].id 时，普通资料的 blob 会被判成 orphan 删掉 ——
     而 applyBackupData 每次导入 / 云恢复 / 自动恢复都会跑这里，等于每次恢复都静默销毁资料库附件。 */
  const resourceBlobIds=new Set();
  for(const r of S.resources){
    resourceBlobIds.add(r.id);
    for(const f of (r.files||[])) resourceBlobIds.add(f.id);
  }
  const attIds=new Set(S.attachments.map(a=>a.id));
  const orphan=blobs.filter(b=>!attIds.has(b.id)&&!resourceBlobIds.has(b.id));
  const changed=[];
  for(const a of S.attachments){
    if(missingIds.has(a.id)){if(!a.missing){a.missing=true;changed.push(a);}}
    else if(a.missing){delete a.missing;changed.push(a);}   /* 本机确实有数据就清掉过期的缺失标记 */
  }
  if(changed.length) await dbPutMany('attachments',changed);
  for(const b of orphan){try{await dbDel('blobs',b.id);}catch(e){}}
  return {missing:missingIds.size,orphan:orphan.length,total:S.attachments.length};
}

/** @param {any} a @returns {string} */
function auditNote(a){  if(!a||!a.missing)return '';
  return '\n\n⚠ 其中 '+a.missing+' 个附件在备份时因超过单个 15MB 上限被跳过，只剩文件名和大小，无法打开。';
}

function importData(){
  const inp=document.createElement('input');inp.type='file';inp.accept='.json,application/json';
  inp.onchange=async()=>{
    const f=(/** @type {any} */ (inp.files)||[])[0];if(!f)return;
    let data;try{data=JSON.parse(await f.text());}catch(e){toast('文件解析失败，不是有效的备份','err');return;}
    if(data.app!=='studydeck'){toast('文件不是课业的备份','err');return;}
    if(data.version&&data.version>BACKUP_VERSION){toast('备份版本过新（v'+data.version+'），请先更新本程序再导入','err');return;}
    for(const k of ['courses','episodes','notes','attachments','sessions','mistakes','tasks','tasklog','files','resources']){if(data[k]!==undefined&&!Array.isArray(data[k])){toast('备份中「'+k+'」字段损坏，已停止导入','err');return;}}
    const mode=await new Promise(res=>{
      const foot=document.createDocumentFragment();
      const cancel=el('button','btn','取消');
      const merge=el('button','btn','合并导入');
      const over=el('button','btn btn-danger','覆盖现有');
      foot.append(cancel,merge,over);
      const md=openModal({title:'选择导入方式',body:'<p class="small" style="line-height:1.7;color:var(--text-2)"><b>合并导入</b>：保留现有数据，按 ID 补充 / 覆盖备份中的内容。<br><b>覆盖现有</b>：先清空当前全部数据，再完整还原备份（不可撤销）。</p>',footer:foot});
      cancel.onclick=()=>{md.close();res(null);};merge.onclick=()=>{md.close();res('merge');};over.onclick=()=>{md.close();res('over');};
    });
    if(!mode)return;
    try{
      const audit=await applyBackupData(data,mode);
      toast('导入完成：'+(data.courses||[]).length+' 门课程、'+(data.notes||[]).length+' 篇笔记、'+(data.mistakes||[]).length+' 道错题、'+(data.tasks||[]).length+' 个任务/目标'+auditNote(audit),audit&&audit.missing?'err':'ok');
    }catch(e){console.error(e);toast('导入过程出错：'+(/** @type {any} */ (e)).message,'err');}
  };
  inp.click();
}

async function wipeAll(){
  const ok1=await confirmDialog('清空全部数据','将删除所有课程、分集、笔记、附件与学习记录，且无法恢复。建议先导出备份。确定继续？','我已备份，继续');
  if(!ok1)return;
  /* 同时问一句本地自动备份：它不在浏览器里，清浏览器数据并不会删掉它，
     下次启动还会被当成「可恢复的备份」提示 —— 所以默认保留，要删需明确选择。 */
  const alsoBackup=await confirmDialog('本机自动备份要一起删吗',
    '程序目录下还有一份本机自动备份（_autobackup/：元数据 + 附件）。\n\n保留它：下次启动会提示「发现本地自动备份」，可以拿它把数据恢复回来。\n删除它：连带这份备份一起清掉，之后就真的没有退路了。\n\n要一起删除吗？','一起删除');
  const ok2=await confirmDialog('最后确认','真的要清空吗？此操作不可撤销。','全部删除');
  if(!ok2)return;
  for(const st of ['courses','episodes','notes','attachments','blobs','sessions','mistakes','tasks','tasklog','resources','kv'])await dbClear(st);
  /* 必须显式重置内存里的设置：loadAll 只合并不重置，清空 kv 后
     sessdata / aiApiKey 会留在 S.settings 里（界面照旧显示，下一次保存又会写回 kv）。 */
  resetSettings();
  await loadAll();render();
  if(alsoBackup){try{await fetch('/api/autobackup/delete',{method:'POST'});}catch(e){}}
  toast('已清空全部数据'+(alsoBackup?'（含本机自动备份）':'（保留了本机自动备份，下次可恢复）'),'ok');
}

/* ============ 自动云备份（写入本机同步文件夹，由网盘客户端上云） ============ */

const CB_DIR='studydeck-backup';

/* File System Access API（showDirectoryPicker / getDirectoryHandle / queryPermission…）
   目前不在 TS 的 DOM lib 里，所以整体按 any 用；下面各处 `h` / `root` 都因此是 any。 */
function fsOK(){const w=/** @type {any} */ (window);return !!(w.isSecureContext&&w.showDirectoryPicker&&w.FileSystemFileHandle&&w.FileSystemFileHandle.prototype.createWritable);}

/** @param {any} h @param {boolean} [writable] @returns {Promise<boolean>} */
async function cbPerm(h,writable){
  if(!h)return false;
  const o={mode:writable?'readwrite':'read'};
  if((await h.queryPermission(o))==='granted')return true;
  if((await h.requestPermission(o))==='granted')return true;
  return false;
}

async function cbGetHandle(){
  if(S._cbHandle!==undefined)return S._cbHandle||null;
  S._cbHandle=(await kvGet('backupDir'))||null;
  return S._cbHandle;
}

/** @param {any} h @param {any} data @returns {Promise<void>} */
async function cbWrite(h,data){
  const root=await h.getDirectoryHandle(CB_DIR,{create:true});
  /* 元数据 + 附件分开放：blobs/ 存原始二进制，JSON 里只留清单。
     旧快照（Base64 内嵌）仍读得回来，所以不清理历史文件。 */
  const meta=backupMeta(data);
  const metaBlob=new Blob([JSON.stringify(meta)],{type:'application/json'});
  const f=await root.getFileHandle('studydeck-latest.json',{create:true});
  const w=await f.createWritable();await w.write(metaBlob);await w.close();
  const keep=new Set((meta.files||[]).map((/** @type {any} */ x)=>x.id));
  if(keep.size){
    const bd=await root.getDirectoryHandle('blobs',{create:true});
    for(const p of (/** @type {any} */ (data)._blobParts||[])){
      if(!keep.has(p.id))continue;
      try{const bf=await bd.getFileHandle(p.id,{create:true});const bw=await bf.createWritable();await bw.write(p.blob);await bw.close();}catch(e){}
    }
    try{for await(const n of bd.keys()){if(!keep.has(n)){try{await bd.removeEntry(n);}catch(e){}}}}catch(e){}
  }
  const snaps=await root.getDirectoryHandle('snapshots',{create:true});
  const dname='studydeck-'+todayKey()+'.json';let has=false;
  for await(const n of snaps.keys()){if(n===dname){has=true;break;}}
  if(!has){
    const sf=await snaps.getFileHandle(dname,{create:true});
    const sw=await sf.createWritable();await sw.write(metaBlob);await sw.close();
  }
  const names=[];for await(const n of snaps.keys())names.push(n);
  names.sort();
  while(names.length>14){const old=names.shift();try{await snaps.removeEntry(old);}catch(e){}}
  await kvSet('backupState',{lastAt:Date.now(),name:h.name});
}

/** @param {boolean} [silent] @returns {Promise<boolean>} */
async function cloudBackup(silent){
  if(!fsOK()){if(!silent)toast('当前浏览器不支持文件夹备份，请用 Edge / Chrome','err');return false;}
  let h=await cbGetHandle();
  /* silent=true 表示这是**后台自动**备份（定时器 / 切标签页触发），没有用户手势。
     此时绝不能去调 cbPick()：showDirectoryPicker 需要用户手势，浏览器必然拒绝并抛错。
     原来这里无条件走 cbPick()，于是 autoBackup 默认开启、用户又从未绑定云文件夹时，
     每次切走标签页 / 最小化窗口都会弹红色「选择文件夹失败」。
     没有句柄就直接 return false，交回给用户主动点「选择文件夹」。
     另外两条自动备份路径（定时器 / startupCloudBackup）本来就有 !h 预检，只有这条缺。 */
  if(!h){
    if(silent)return false;
    try{h=await cbPick();}catch(e){if((/** @type {any} */ (e)).name==='AbortError')return false;toast('选择文件夹失败：'+(/** @type {any} */ (e)).message,'err');return false;}
  }
  if(!(await cbPerm(h,true))){if(!silent)toast('未授予文件夹写入权限','err');return false;}
  try{
    await cbWrite(h,await buildBackupData());
    S._cbSig=dataSig();await kvSet('backupSig',S._cbSig);
    if(!silent)toast('已备份到「'+h.name+'」同步文件夹','ok');
    return true;
  }catch(e){console.error(e);if(!silent)toast('备份失败：'+(/** @type {any} */ (e)).message,'err');return false;}
}

async function cbPick(){
  const h=await (/** @type {any} */ (window)).showDirectoryPicker({mode:'readwrite'});
  if(!(await cbPerm(h,true)))throw new Error('no permission');
  await kvSet('backupDir',h);S._cbHandle=h;
  await kvSet('backupState',Object.assign((await kvGet('backupState'))||{},{name:h.name}));
  return h;
}

async function cbForget(){
  await kvSet('backupDir',null);S._cbHandle=null;
}

/* 从云备份文件夹水合附件：blobs/ 目录里按 id 存原始二进制。 */

/** @param {any} root @param {any} meta @returns {Promise<number>} */
async function hydrateFromCloudBackup(root,meta){
  const wanted=(meta.files||[]).filter((/** @type {any} */ f)=>f&&f.id);
  if(!wanted.length)return 0;
  let dir=null;
  try{dir=await root.getDirectoryHandle('blobs');}catch(e){return 0;}
  const have=new Set((await dbAll('blobs')).filter(b=>b&&b.blob).map(b=>b.id));
  let n=0;
  for(const f of wanted){
    if(have.has(f.id))continue;
    try{const fh=await dir.getFileHandle(f.id);const file=await fh.getFile();await dbPut('blobs',{id:f.id,blob:file});n++;}catch(e){}
  }
  return n;
}

async function cloudRestore(){
  const h=await cbGetHandle();
  if(!h){toast('请先选择备份文件夹','err');return;}
  if(!(await cbPerm(h,false)))return;
  /** @type {any} */
  let root;try{root=await h.getDirectoryHandle(CB_DIR);}catch(e){toast('该文件夹中还没有课业备份','err');return;}
  const choices=/** @type {any[]} */ ([]);
  try{const lf=await root.getFileHandle('studydeck-latest.json');const st=await lf.getFile();choices.push({key:'latest',name:'最新备份（'+fmtDateTime(st.lastModified)+'）',file:st});}catch(e){}
  let snaps=null;try{snaps=await root.getDirectoryHandle('snapshots');}catch(e){}
  const snapNames=[];if(snaps)for await(const n of snaps.keys())snapNames.push(n);
  snapNames.sort().reverse();
  for(const n of snapNames.slice(0,14)){const sf=await snaps.getFileHandle(n);choices.push({key:n,name:'每日快照 '+n.replace(/studydeck-|\.json/g,''),file:await sf.getFile()});}
  if(!choices.length){toast('没有找到备份文件','err');return;}
  const mode=await new Promise(res=>{
    const wrap=el('div');
    wrap.innerHTML='<p class="small" style="line-height:1.7;color:var(--text-2);margin-bottom:10px">选择要恢复的版本：</p>'+
      choices.map((c,i)=>'<label style="display:flex;gap:8px;align-items:center;padding:6px 2px;font-size:13px;cursor:pointer"><input type="radio" name="cbver" value="'+i+'" '+(i===0?'checked':'')+'> '+esc(c.name)+'</label>').join('')+
      '<p class="small" style="line-height:1.7;color:var(--text-2);margin-top:12px">恢复方式：<b>合并</b>保留现有数据按 ID 补充覆盖；<b>覆盖</b>先清空再完整还原。</p>';
    const foot=document.createDocumentFragment();
    const cancel=el('button','btn','取消'),merge=el('button','btn','合并恢复'),over=el('button','btn btn-danger','覆盖恢复');
    foot.append(cancel,merge,over);
    const md=openModal({title:'从同步文件夹恢复',body:wrap,footer:foot,dismissable:false});
    cancel.onclick=()=>{md.close();res(null);};
    merge.onclick=()=>{const v=+wrap.querySelector('input[name=cbver]:checked').value;md.close();res({mode:'merge',c:choices[v]});};
    over.onclick=()=>{const v=+wrap.querySelector('input[name=cbver]:checked').value;md.close();res({mode:'over',c:choices[v]});};
  });
  if(!mode)return;
  try{
    const data=JSON.parse(await mode.c.file.text());
    if(data.app!=='studydeck'){toast('文件不是课业的备份','err');return;}
    if(data.version&&data.version>BACKUP_VERSION){toast('备份版本过新（v'+data.version+'），请先更新本程序再恢复','err');return;}
    for(const k of ['courses','episodes','notes','attachments','sessions','mistakes','tasks','tasklog','files','resources']){if(data[k]!==undefined&&!Array.isArray(data[k])){toast('备份中「'+k+'」字段损坏，已停止恢复','err');return;}}
    await hydrateFromCloudBackup(root,data);      /* 先把附件二进制拉回本机 */
    const audit=await applyBackupData(data,mode.mode);
    toast('已恢复：'+mode.c.name+auditNote(audit),audit&&audit.missing?'err':'ok');
  }catch(e){console.error(e);toast('恢复失败：'+(/** @type {any} */ (e)).message,'err');}
}

function cloudBackupCard(){
  if(!fsOK())return '<div class="card card-pad" style="margin-bottom:14px"><div class="section-title">'+I('globe')+' 自动云备份</div><p class="small muted">当前浏览器不支持文件夹自动备份，请使用 Edge / Chrome，或用下方「导出全部数据」手动备份。</p></div>';
  return '<div class="card card-pad" style="margin-bottom:14px"><div class="section-title">'+I('globe')+' 自动云备份（防丢机 / 换机同步）<span class="tiny" style="font-weight:400">推荐</span></div>'+
    '<p class="small muted" style="line-height:1.75;margin-bottom:12px">选择一个<b>网盘同步文件夹</b>（OneDrive、百度网盘、飞书云盘等在本机的同步目录均可），数据有变化时应用会在约 2 分钟内自动写入「'+CB_DIR+'」子文件夹，网盘客户端随即上传云端：<b>studydeck-latest.json</b> 只存课程/笔记等元数据（约百 KB），附件以原始二进制放在 <b>blobs/</b> 子目录（不再 Base64，写入更快），每天另留一份元数据快照（最近 14 天）。换机或重装后登录同一网盘账号，安装本应用并选回同一文件夹即可一键恢复。凭证 SESSDATA 不会被备份。</p>'+
    '<div class="set-row" style="border-top:none;padding-top:0"><div><div class="set-name">备份文件夹</div><div class="set-desc" id="cbState">检查中…</div></div>'+
    '<div style="display:flex;gap:7px;flex-wrap:wrap;justify-content:flex-end">'+
    '<button class="btn btn-primary btn-sm" id="cbPick">'+I('folder')+' 选择文件夹</button>'+
    '<button class="btn btn-sm" id="cbNow">'+I('download')+' 立即备份</button>'+
    '<button class="btn btn-sm" id="cbRestore">'+I('rotate')+' 恢复</button>'+
    '<button class="btn btn-sm" id="cbForget">停用</button></div></div>'+
    '<div class="set-row"><div><div class="set-name">自动备份</div><div class="set-desc">数据变化后自动写入；关闭后仅在点「立即备份」时备份</div></div><div class="switch '+(S.settings.autoBackup?'on':'')+'" id="cbAuto"></div></div></div>';
}

/** @param {any} main */
async function bindCloudBackup(main){
  if(!fsOK())return;
  const state=main.querySelector('#cbState');
  async function refresh(){
    const h=await cbGetHandle();
    if(!h){state.textContent='尚未选择文件夹';state.style.color='var(--text-3)';return;}
    const perm=await h.queryPermission({mode:'readwrite'});
    const bs=await kvGet('backupState');
    if(perm!=='granted'){state.innerHTML='已选择「'+esc(h.name)+'」，但需要重新授权——点「选择文件夹」重选一次即可';state.style.color='var(--danger)';return;}
    state.innerHTML='已绑定「'+esc(h.name)+'」'+(bs&&bs.lastAt?('，上次备份 '+fmtDateTime(bs.lastAt)):'，尚未备份');
    state.style.color='#0f6b54';
  }
  await refresh();
  main.querySelector('#cbPick').onclick=async()=>{try{await cbPick();await cloudBackup(false);await refresh();const r=main.querySelector('#cbAuto');if(r)r.classList.toggle('on',!!S.settings.autoBackup);}catch(e){if((/** @type {any} */ (e)).name!=='AbortError')toast((/** @type {any} */ (e)).message,'err');}};
  main.querySelector('#cbNow').onclick=async()=>{await cloudBackup(false);await refresh();};
  main.querySelector('#cbRestore').onclick=cloudRestore;
  main.querySelector('#cbForget').onclick=async()=>{const ok=await confirmDialog('停用自动备份','仅解除本机与备份文件夹的绑定，不会删除文件夹里已上传的备份文件。确定？','停用');if(!ok)return;await cbForget();S.settings.autoBackup=false;await saveSettings();refresh();toast('已停用自动备份','ok');};
  main.querySelector('#cbAuto').onclick=async function(){
    if(!S.settings.autoBackup){S.settings.autoBackup=true;this.classList.add('on');await saveSettings();toast('已开启自动备份','ok');}
    else{S.settings.autoBackup=false;this.classList.remove('on');await saveSettings();}
  };
}

/** @type {number|null} */
let cbTimer=null;

function startCloudBackupTimer(){
  /* 幂等：已经起过就直接返回。
     不靠"先 clearInterval 再 setInterval"兜底 —— 那种写法只是重复调用不报错，
     并会把接线错误（比如 DOMContentLoaded 重复注册导致 init 跑两次）藏起来。
     显式守卫让重复调用变成"什么都不做"，接错线在结构上无害。 */
  if(cbTimer)return;
  cbTimer=setInterval(async()=>{
    if(!S.settings.autoBackup||!fsOK())return;
    try{
      const h=await cbGetHandle();if(!h)return;
      if(await h.queryPermission({mode:'readwrite'})!=='granted')return;
      const sig=dataSig(),saved=S._cbSig||await kvGet('backupSig');
      if(sig!==saved)await cloudBackup(true);
    }catch(e){}
  },120000);
  /** @type {any} */
let _cbT=null;
  document.addEventListener('visibilitychange',()=>{
    /* 与上面定时器、下面 startupCloudBackup 两条自动路径保持一致：
       先确认已经绑定文件夹且仍有写权限，再去备份。缺这层预检时
       （autoBackup 默认开、用户没绑过文件夹），每次切走标签页都会
       无用户手势调用 showDirectoryPicker 并弹错。 */
    if(document.visibilityState==='hidden'&&S.settings.autoBackup&&fsOK()){
      if(_cbT)clearTimeout(_cbT);
      _cbT=setTimeout(async()=>{
        try{
          const h=await cbGetHandle();if(!h)return;
          if(await h.queryPermission({mode:'readwrite'})!=='granted')return;
          await cloudBackup(true);
        }catch(e){}
      },600);
    }
  });
}

async function startupCloudBackup(){
  if(!fsOK())return;
  try{
    const h=await cbGetHandle();if(!h)return;
    if(await h.queryPermission({mode:'readwrite'})!=='granted')return;
    S._cbSig=await kvGet('backupSig');
    setTimeout(async()=>{const sig=dataSig();if(sig!==S._cbSig)await cloudBackup(true);},8000);
  }catch(e){}
}

/* ============ 本地自动备份 + 启动自动恢复（走 server 写程序目录文件，不依赖浏览器授权） ============ */

async function localAutoBackup(){
  try{
    const data=await buildBackupData();
    /* 二进制通道：元数据一份 JSON，附件一个个原样上传（不再 Base64）。 */
    const fd=new FormData();
    fd.append('manifest',new Blob([JSON.stringify(backupMeta(data))],{type:'application/json'}));
    for(const p of (/** @type {any} */ (data)._blobParts||[])){
      try{fd.append('blobs['+p.id+']',p.blob,p.id);}catch(e){}
    }
    const r=await fetch('/api/autobackup/save',{method:'POST',body:fd});
    const j=await r.json();
    if(j&&j.code===0){S._lsig=dataSig();return true;}
    return false;
  }catch(e){return false;}
}

/** @type {number|null} */
let lcbTimer=null;

function startLocalBackupTimer(){
  /* 幂等，理由同 startCloudBackupTimer。
     注意下面还要 addEventListener('visibilitychange')：重复调用会让监听器叠加，
     那不是"重复调用不出错"能兜住的，所以守卫在这里尤其必要。 */
  if(lcbTimer)return;
  lcbTimer=setInterval(async()=>{
    if(!S.settings.autoBackup)return;
    try{const sig=dataSig();if(sig!==S._lsig)await localAutoBackup();}catch(e){}
  },120000);
  /** @type {number|null} */
  let _lt=null;
  document.addEventListener('visibilitychange',()=>{
    if(document.visibilityState==='hidden'&&S.settings.autoBackup){
      if(_lt)clearTimeout(_lt);
      _lt=setTimeout(()=>{try{const sig=dataSig();if(sig!==S._lsig)localAutoBackup();}catch(e){}},600);
    }
  });
}


export { bindCloudBackup, cloudBackupCard, exportData, importData, wipeAll, startCloudBackupTimer, startLocalBackupTimer, startupCloudBackup, applyBackupData, auditAttachments, auditNote, buildBackupData, hydrateFromLocalBackup, hydrateFromCloudBackup, localAutoBackup, cloudRestore, cloudBackup, BACKUP_VERSION };
