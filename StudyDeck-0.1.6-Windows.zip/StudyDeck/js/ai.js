// @ts-check
// AI 功能前端封装：调用本地 /api/ai/* 接口。
//
// 设计原则：
//   · 所有 AI 配置（apiKey / baseUrl / model / notesPrompt）存在 S.settings 里，跟 sessdata 一样不进备份
//   · 调用走本地代理 /api/ai/*，不直接从浏览器调大模型接口（避免 CORS + 保护 Key）
//   · 提供 aiConfigured() 判断是否已配置，UI 层用它控制按钮显隐
//   · 提供 showAiResult() 统一展示 AI 生成结果的弹窗（笔记 / 错题解析共用）

import { S } from './db.js';
import { openModal, toast } from './ui.js';
import { md2html, parseBili } from './util.js';

/** AI 是否已配置（有 API Key 才算）。 */
export function aiConfigured(){
  return !!(S.settings && S.settings.aiApiKey);
}

/** 读取 AI 配置（带默认值）。 */
function aiCfg(){
  const s = S.settings || {};
  return {
    apiKey: s.aiApiKey || '',
    baseUrl: s.aiBaseUrl || 'https://api.deepseek.com',
    model: s.aiModel || 'deepseek-chat',
    notesPrompt: s.aiNotesPrompt || '',
  };
}

/** 把 catch 到的 unknown 变成可读文本。
 *  catch 的参数在 TS 里是 unknown，直接取 .message 会报错（TS18046）。
 *  @param {unknown} e @returns {string} */
function errText(e){
  if(e && typeof e === 'object' && 'message' in e) return String(/** @type {any} */ (e).message);
  return String(e);
}

/** 从分集的 url 字段提取 BV 号。分集的 url 可能是纯 bvid 或完整 B 站链接。
 *  @param {{url?:string}|null} [ep] */
export function bvidOfEpisode(ep){
  if(!ep || !ep.url) return '';
  const m = String(ep.url).match(/(BV[0-9A-Za-z]{10})/);
  return m ? m[1] : '';
}

/** 判断分集是否为 B 站视频（可以取字幕生成 AI 笔记）。
 *  @param {{url?:string,src?:string}|null} [ep] */
export function isBiliEpisode(ep){
  return !!(ep && ep.src === 'bili' && bvidOfEpisode(ep));
}

/**
 * 生成 AI 笔记。
 * @param {{id:string,url?:string,src?:string,title?:string}} ep 分集对象
 * @param {string} [title] 视频标题（可选，不传用分集标题）
 * @returns {Promise<{ok:boolean, notes?:string, error?:string, stage?:string}>}
 */
export async function aiGenerateNotes(ep, title){
  if(!aiConfigured()) return {ok:false, error:'未配置 AI API Key，请在设置页填写'};
  const bvid = bvidOfEpisode(ep);
  if(!bvid) return {ok:false, error:'该分集不是 B 站视频，无法获取字幕'};
  // 分 P 视频：分 P 号存在 url 的 ?p=N 里，必须传对，否则会拿到第 1 P 的字幕（内容张冠李戴）
  const parsed = parseBili(ep.url);          // 上面已确认 url 非空，parseBili 只在空值时返回 null
  const page = (parsed && parsed.page) || 1;
  const cfg = aiCfg();
  try{
    const r = await fetch('/api/ai/generate-notes', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({
        api_key: cfg.apiKey,
        base_url: cfg.baseUrl,
        model: cfg.model,
        bvid: bvid,
        sessdata: S.settings.sessdata || '',
        page: page,
        title: title || ep.title || '',
        custom_prompt: cfg.notesPrompt,
      }),
    });
    const j = await r.json();
    if(j && j.code === 0 && j.notes){
      return {ok:true, notes:j.notes};
    }
    return {ok:false, error:(j && j.message) || '生成失败', stage:(j && j.stage) || ''};
  }catch(e){
    return {ok:false, error:'本地服务连接失败：'+errText(e)};
  }
}

/**
 * AI 错题解析。
 * @param {{subject?:string,chapter?:string,points?:string[],stem?:string,analysis?:string}} mk 错题对象
 * @returns {Promise<{ok:boolean, analysis?:string, error?:string}>}
 */
export async function aiAnalyzeMistake(mk){
  if(!aiConfigured()) return {ok:false, error:'未配置 AI API Key，请在设置页填写'};
  const cfg = aiCfg();
  try{
    const r = await fetch('/api/ai/analyze-mistake', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({
        api_key: cfg.apiKey,
        base_url: cfg.baseUrl,
        model: cfg.model,
        subject: mk.subject || '',
        chapter: mk.chapter || '',
        points: mk.points || [],
        stem: mk.stem || '',
        analysis: mk.analysis || '',
      }),
    });
    const j = await r.json();
    if(j && j.code === 0 && j.analysis){
      return {ok:true, analysis:j.analysis};
    }
    return {ok:false, error:(j && j.message) || '解析失败'};
  }catch(e){
    return {ok:false, error:'本地服务连接失败：'+errText(e)};
  }
}

/**
 * 测试 AI API 连接。
 * @returns {Promise<{ok:boolean, message:string}>}
 */
export async function aiTestConnection(){
  if(!aiConfigured()) return {ok:false, message:'未配置 API Key'};
  const cfg = aiCfg();
  try{
    const r = await fetch('/api/ai/test', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({api_key:cfg.apiKey, base_url:cfg.baseUrl, model:cfg.model}),
    });
    const j = await r.json();
    return {ok: !!j.ok, message: j.message || ''};
  }catch(e){
    return {ok:false, message:'本地服务连接失败：'+errText(e)};
  }
}

/**
 * 统一展示 AI 生成结果的弹窗。
 * 笔记和错题解析都用这个，支持「复制」和「插入到编辑器」（如果传了 onInsert）。
 * @param {string} title 弹窗标题
 * @param {string} markdown AI 返回的 Markdown 文本
 * @param {(text:string)=>void} [onInsert] 点击「插入」时的回调（把文本插入到编辑器）
 */
export function showAiResult(title, markdown, onInsert){
  // 复用项目标准弹窗 openModal：背景/文字走主题变量（深色模式下同样清晰），
  // 叠层由 modalStack 统一管理（能正确盖在笔记表单弹窗之上）。
  const foot = document.createDocumentFragment();
  const copyBtn = document.createElement('button');
  copyBtn.className = 'btn'; copyBtn.type = 'button'; copyBtn.textContent = '复制全文';
  let insertBtn = null;
  if(onInsert){
    insertBtn = document.createElement('button');
    insertBtn.className = 'btn btn-primary'; insertBtn.type = 'button';
    insertBtn.textContent = '插入到笔记';
  }
  const okBtn = document.createElement('button');
  okBtn.className = 'btn btn-primary'; okBtn.type = 'button'; okBtn.textContent = '完成';
  foot.append(copyBtn);
  if(insertBtn) foot.append(insertBtn);
  foot.append(okBtn);

  const md = openModal({
    title: title,
    wide: true,
    body: '<div style="font-size:12px;color:var(--text-3);margin-bottom:10px">AI 生成，仅供参考，请核对后再使用</div>'+
          '<div class="md-preview">'+md2html(markdown)+'</div>',
    footer: foot,
  });

  copyBtn.onclick = async ()=>{
    try{
      await navigator.clipboard.writeText(markdown);
      toast('已复制到剪贴板','ok');
    }catch(e){
      // 降级：用 textarea
      const ta = document.createElement('textarea');
      ta.value = markdown; document.body.appendChild(ta); ta.select();
      try{ document.execCommand('copy'); toast('已复制到剪贴板','ok'); }catch(_){ toast('复制失败','err'); }
      ta.remove();
    }
  };
  if(insertBtn && onInsert) insertBtn.onclick = ()=>{ onInsert(markdown); md.close(); toast('已插入到笔记','ok'); };
  okBtn.onclick = ()=> md.close();
}
