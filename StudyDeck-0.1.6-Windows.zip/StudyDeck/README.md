# 课业 · 网课学习管理器

本地网课学习管理工具：课程/分集管理、B 站合集·番剧·UP 视频导入、本地视频、笔记（Markdown）、错题本、任务日历、学习计时统计、本地与云备份。数据存浏览器 IndexedDB，本地高清直链通过 `server.py` 代理获取。

## 快速开始

1. 双击 **「启动课业（B站高清）.bat」**（需 Python 3.8+，会自动查找 Python 并安装扫码所需的 `segno` 库）。
2. 浏览器自动打开 `http://127.0.0.1:8787`；**端口固定为 8787**，若被占用会直接报错退出（不会静默换端口，因为数据按端口隔离，换端口就等于「数据不见了」），关掉占用 8787 的旧窗口再启动即可。
3. 添加课程 → 添加分集：支持 B 站合集 / 收藏夹 / 番剧 / UP 主页链接一键导入（自动按顺序 + 带标题），也支持本地视频多选批量导入。
4. 播放器支持高清直连、内嵌播放、小窗、倍速，以及「拖动分集/课程排序」。

> 请始终用 `.bat` 打开的地址（`http://127.0.0.1:8787`）使用，**不要直接双击 `index.html`**：浏览器不允许从 `file://` 加载 ES 模块，双击只会看到空白页。

## 本地视频与媒体库（MKV / AVI 等）

浏览器自己只能播 MP4 / WebM。把 MKV / AVI / FLV / WMV / RMVB 等交给课业时，程序在**你自己的电脑上**用 ffmpeg 处理，两种方式自动选：

- **只换容器（能换就换，秒级、画质无损）**：视频编码是 H.264 时，只是把 MKV/FLV 装进 MP4 壳，再当普通 MP4 播放 —— 时长、进度条、拖动全部由浏览器原生处理，**UI 和普通 MP4 完全一致**。结果缓存在 `media-cache/remux/`，同一个文件只做一次，之后秒开。
- **实时转码（少数格式）**：视频是 HEVC / 10bit H.264 / MPEG-4 等浏览器解不了的时候，边转边播（首次略慢）。这类流的时间轴只能是相对的，所以用播放器自带控制条，进度条按后端探测出的真实总时长显示。

两种添加方式：

1. **本地视频**：添加分集时多选文件。浏览器解不了的格式会先上传到本机 `media-cache/`（同一文件只传一次），之后直接打开。
2. **媒体库文件夹**：设置里指定一个视频文件夹，添加分集时从里面挑，**不复制文件**。

> **MKV / AVI 需要 ffmpeg。** 运行程序目录里的 **「安装ffmpeg.bat」** 即可自动下载（压缩包约 190MB，只取其中的 `ffmpeg.exe`，约 161MB）；也可以自己把 `ffmpeg.exe` 放进去，或装到系统 PATH。没有 ffmpeg 时这类格式会明确提示你去安装，而不是黑屏。
>
> `media-cache/` 里是**你视频的副本或换壳结果**，按 LRU 自动淘汰，不进备份、也不会被打进发布包。

## 获取 SESSDATA（1080P+ 高清）

- **推荐**：设置 → 「扫码获取」用手机 B 站 App 扫码，自动登录并保存。
- 手动：登录 bilibili.com，从浏览器 Cookie 复制 `SESSDATA` 值，粘贴到设置页保存。

## ⚠️ 凭证安全（务必阅读）

- `sessdata.txt`（本程序目录）和浏览器 IndexedDB 设置里各保存一份 **B 站登录凭证 SESSDATA**，等同于你的登录态。其中 `sessdata.txt` 是**明文文件**（扫码登录时写入）。
- **切勿分享 / 上传 / 网盘同步本程序文件夹**（把程序目录放进网盘同步目录，等于把登录凭证一起同步上云）。分享前务必删除 `sessdata.txt`，或直接在设置页点「删除本地凭证文件」；凭证已不进备份导出。

## ⚠️ AI 功能与数据出境（使用前必读）

AI 笔记 / AI 错题解析是**可选功能**，不填 API Key 就不会有任何出境请求。一旦启用，请注意：

- **会离开你机器的是哪些内容**（这是本工具唯一会把你的数据发到第三方的地方）：
  * **AI 生成笔记**：该分集的 **B 站字幕全文** + 视频标题 + 你在设置页填的自定义提示词。
    字幕由本机代理向 B 站获取，随后连同提示词一起发给大模型服务商。
  * **AI 错题解析**：该错题的 **题干 / 章节 / 知识点 / 已有的解析文本**。
- **发到哪里**：设置页里的 `base_url`（默认 `https://api.deepseek.com`，可改成任何 OpenAI 兼容服务）。
  也就是说"数据 100% 本机"这条承诺**只对 AI 功能之外的部分成立**——用了 AI，上述内容就交给了你选的模型服务商，
  请以该服务商的隐私条款为准。
- **API Key 存在哪**：只存在浏览器 IndexedDB 的设置里；**不进备份导出**（连本机自动备份与云备份也不含），
  与 `SESSDATA` 同等对待。它经「浏览器 → 本机代理 → 模型服务商」这条链传递，服务端不落盘、不写日志。
- **base_url 必须 https**：本机模型（Ollama / LM Studio 等）可以用 `http://127.0.0.1` 或 `http://localhost`，
  其余一律要求 https —— 因为 Key 会放进该地址的请求头，允许 http 就等于明文发送。
- **想停用**：把设置页的 API Key 清空即可；已生成的笔记/解析已落在本机，不受影响。

## 数据位置与备份

- 数据存浏览器 **IndexedDB**（课程、分集、笔记、计时等）。
- **存储隔离**：`127.0.0.1:8787`、`file://` 直开、以及任何其他端口，各自是一套独立存储，互相看不到数据。日常固定用 `.bat` 打开的那个地址。
- **持久化存储**：程序启动时会自动向浏览器申请「持久化存储」，设置页会显示当前占用 / 配额。若显示未开启，浏览器在磁盘紧张时可能回收这些数据，请务必保留一份备份。
- **手动导出 = 元数据备份**：设置 → 「导出全部数据」得到的是 JSON，内含课程/分集/笔记正文/错题/任务/学习记录，以及附件的**名称、大小、类型清单**——**不含附件文件本身**。附件由下面两条路保存，换机时请一并带走。
- **附件二进制**（图片 / PDF / 资料库文件）走独立通道，不再 Base64 内嵌进 JSON：
  * **本机自动备份**：程序目录 `_autobackup/`（`latest.json` 元数据 + `blobs/<id>` 原始文件），启动时会自动检测并在数据为空时提示恢复。
  * **自动云备份**：设置 → 选一个网盘同步文件夹，数据变化约 2 分钟内写入 `studydeck-backup/`（元数据 + `blobs/` + 近 14 天元数据快照）。
  * 恢复时按需把附件拉回本机（本机已有的不重复下载），随后做一次一致性审计，缺文件的附件会显式标成「数据缺失」，而不是留一条点不开的空记录。
- 导入分「合并」与「覆盖」；覆盖导入前会自动生成 `pre-overwrite-rollback-*.json` 回滚文件。
- **清空全部数据**时会单独问一句「本机自动备份要一起删吗」，默认**保留**——它是你最后一道退路。
- ⚠ **附件一律不在 JSON 导出里**（附件走独立二进制通道）。另外，**单个超过 15MB 的附件连本机自动备份与云备份也会跳过**（防内存溢出）：导出/备份时会弹窗说明，恢复后这些附件只剩文件名和大小，列表里会标为「数据缺失」。请把这类大文件单独另存一份，别只依赖本工具的备份。

## 常见故障

| 症状 | 处理 |
|------|------|
| 打不开页面 | 双击 bat 启动；地址固定是 `http://127.0.0.1:8787/`（端口被占用时程序会明确报错并退出，不会换端口） |
| 打开是空白页 | 你可能是直接双击了 `index.html`；请改用 bat 打开的地址（`file://` 下 ES 模块会被浏览器拦掉） |
| B 站取链失败 / 播放失败 | 设置 → 「验证登录态」确认 SESSDATA 有效；检查网络能否访问 B 站 |
| 扫码不可用 | 需 `segno` 库，bat 会自动安装；仍失败可在控制台手动 `pip install segno` |
| 页面缓存旧 | 强制刷新（Ctrl+F5），或给地址加 `?v=数字` 绕缓存 |
| 需要日志排查 | 设环境变量 `STUDYDECK_LOG=日志文件路径` 再启动 bat，会记录请求日志 |

## 合规说明

本工具通过本地代理为**已登录的 B 站账号**获取官方直链播放，仅供个人学习使用。请勿传播直链或用于商业用途，请遵守 B 站用户协议。

## 项目结构

- `index.html` — 页面外壳（样式 + 结构），逻辑在 `js/` 的 ES 模块里，用 `<script type="module">` 加载。
- `js/` — 前端模块（原生 ES 模块，**无构建、无第三方依赖**）：

  | 模块 | 职责 |
  |---|---|
  | `icons.js` | 内联 SVG 图标表 |
  | `types.js` | **数据模型的编译期类型**（JSDoc typedef + 编译期断言），供 tsc 校验 |
  | `schema.js` | **数据模型的运行期主键**（`STORE_KEYS`），db.js 建表与测试断言都读它 |
  | `core.js` | **零依赖纯工具层**（依赖图的叶子）：格式化、日期、转义、Bili 链接解析、`blobsHave` |
  | `util.js` | 依赖状态/数据层/弹窗的工具（课程与分集统计、`dataSig`、`md2html`、`openAttachment`）；并把 `core.js` 的纯工具再导出一次 |
  | `db.js` | IndexedDB 数据层、全局状态 `S`、`loadAll`、`saveSettings` |
  | `ui.js` | Toast / 弹窗 / 扫码登录 |
  | `viewkit.js` | 路由解析 + 视图分发（注册制）、视图标题栏等公共积木 |
  | `video-files.js` | 本地视频文件选择、分集 ↔ 文件句柄存取（底层能力，谁都不依赖） |
  | `forms.js` | 课程 / 分集 / 批量分集 / 笔记表单，以及分集拖拽排序 |
  | `player.js` | 播放器内核（MSE/DASH/本地视频）、计时、课程详情视图与课程/分集动作 |
  | `views-course.js` | 课程列表视图 |
  | `views-note.js` | 笔记 / 错题本视图 |
  | `views-tasks.js` | 任务与目标视图（日视图 / 月视图 / 任务表单） |
  | `task-utils.js` | 任务模块共用小工具：日期、分类、打卡、目标进度、链接编辑 |
  | `task-timetable.js` | 课表（在校自学弹性课程表）的导入与导出 |
  | `views-resources.js` | 资料库视图：上传 / 文件夹 / 下载 / 打开 / 移动 |
  | `views-history.js` | 历史视图：按天浏览学习记录并删除条目 |
  | `views-stats.js` | 统计与搜索视图 |
  | `views-task.js` | **桶文件**：只做再导出，保持对外 API 不变（原来 875 行，已按职责拆开） |
  | `views-home.js` | 概览 + 统计 |
  | `views-dispatch.js` | 注册「路由名 → 视图函数」 |
  | `settings-backup.js` | 设置页的备份 / 恢复 / 云备份 / 本机自动备份（导出、导入、清空、云备份卡片） |
  | `app.js` | 启动入口：init、DOMContentLoaded（备份逻辑在 settings-backup.js） |

  依赖方向是单向的：`player.js → forms.js → video-files.js → db.js`。
  `forms.js` 的笔记表单需要读「当前播放的分集」，为避免 `forms ⇄ player` 的 import 环，
  改由 `player.js` 调 `bindPlayer()` 注入 —— 别把 `Player` 直接 import 进 `forms.js`，
  那会重新造出环（测试里有源码断言盯着这一条）。

  **依赖图的形状**：`core.js` 是叶子（不 import 任何本项目模块），
  `db.js` / `ui.js` / `viewkit.js` 都只依赖它和彼此的上游，`util.js` 在它们之上。
  早先存在 `db ⇄ util` 与 `util ⇄ ui` 两个 import 环，当时"能跑"只是因为求值顺序恰好合适
  （靠 `tools/eval-order-check.mjs` 保平安）。把纯函数抽进 `core.js` 之后环真正断开了，
  现在是**结构上**安全，而不是"测试跑得过"。`test/run.mjs` 里有四条源码断言钉住这件事：
  `core.js` 不许有 import、`db.js`/`ui.js` 不许 import `util.js`。

- `server.py` — 本地代理（Python 标准库零依赖）：注入 Referer/SESSDATA 取直链、CDN 流式转发；同时伺服 `index.html` 与 `js/*.js`（只允许根目录 html 与 `js/` 下的脚本，其他路径一律 403/404）。
- `启动课业（B站高清）.bat` — 启动器（查 Python → 装 segno → 起服务）。

## 开发：`js/` 是唯一真源

**改代码就改 `js/`，然后跑 `npm run test:unit`。** 没有构建步骤，没有补丁要同步。

`js/` 下的 24 个原生 ES 模块就是运行时加载的东西，也是唯一的事实标准。
早先那套「基线 → 切分 → 重放补丁」的脚手架（用来证明本轮重构可从基线复现）
**已经冻结归档**，理由是它的使命完成了：重构既然收尾，链条就从"证明可复现"
退化成"每次改代码都要多想一层"的维护税。

```bash
npm install          # 安装 happy-dom（读取 package.json 的 overrides）
npm test             # 默认闸门链：syntax → cycle → typecheck → esm → eval-order → 单元 → 旧格式迁移
npm run test:all     # 上面这些 + server 端到端 + 三个冒烟测试（较慢）
npm run test:unit    # 只跑无头回归测试（打包 js/ + test/run.mjs）
npm run test:server  # 启动隔离实例跑 server.py 端到端测试（不碰真实数据）
npm run test:legacy  # 旧格式备份的服务端迁移（Base64 → blobs/，逐字节核对）
npm run test:smoke   # 三个 server 类冒烟测试（各自启动隔离实例）
npm run cycle        # 依赖环检测（当前应是干净的 DAG）
npm run typecheck    # 类型检查（棘轮：已纳入闸门的模块必须 0 错误）
npm run esm          # 用 Node 的真实 ESM 语义校验模块图
npm run eval-order   # 7 种 import 顺序下模块顶层代码都不抛异常
npm run syntax       # 逐模块语法检查
npm run archive      # 把当前 js/ 快照到 tools/archive/（回滚点）
npm run stats        # 看当前备份的体积构成
```

> **`npm test` 必须是完整的闸门链。** 它曾经只跑 `test:unit && test:legacy`，
> 于是"只跑 npm test 的人"拿到的检查比项目实际具备的更弱 —— 而闸门默认不跑就会漂。
> 现在 syntax / cycle / typecheck / esm / eval-order 都在默认路径里。

### 回滚点与归档

| 目录 | 内容 | 什么时候用 |
|---|---|---|
| `tools/archive/` | 当前已验证状态的快照（`js/` 全部模块 + 两份内联副本） | 担心改坏的定心丸。回滚：把 `tools/archive/js/*.js` 拷回 `js/` |
| `tools/legacy/` | 冻结的重放链（10 个脚本 + 基线副本） | 只在想**重新验证**「从基线能复现出当前代码」时 |

```bash
npm run archive                                          # 更新快照
node tools/legacy/rebuild-all.mjs --force --test         # 归档链条（会整份覆盖 js/）
```

> ⚠️ 归档链条会**整份覆盖 `js/`**，且它有自己的防呆检查（`check-unsynced`）：
> 若 `js/` 与「上次重建结果」指纹不一致就会中止，要强制覆盖得加 `--force`。
> 跑之前建议先 `npm run archive`。**已经验证过**：它重建出的 `js/` 与快照逐字节一致（12/12）。
### 测试为什么不会碰你的数据

保存备份时服务端会调用 `_purge_blobs(keep)`，把清单里没引用的附件文件**删掉**。如果测试和真实数据
共用 `_autobackup/`，一次保存就会清空你的附件二进制，而逐文件快照也救不回来（只能恢复新增的，恢复不了被删的）。
所以：

- `server.py` 的两个路径支持环境变量覆盖：
  * `STUDYDECK_AB_DIR` → 备份目录（默认 `程序目录/_autobackup`）
  * `STUDYDECK_SESS_FILE` → 凭证文件（默认 `程序目录/sessdata.txt`）
- `tools/lib/isolated-server.mjs` 用它为每个 server 类测试启动一个**完全隔离**的实例
  （备份与凭证都在临时目录），并在收尾时删除临时目录。
- 若存在真实 `sessdata.txt`，只做**改名保护**（`.testbak`）而不是删除，结束后改回。
- 每个 server 类测试结束都会核对**真实 `_autobackup/` 的逐文件指纹未变**，不一致就判失败。

> `package.json` 里的 `overrides` 把 happy-dom 传递依赖的 `whatwg-mimetype` 抬到 4.x：
> 旧版 3.x 在 Node 18+ 上解析某些 Content-Type 时会往 stderr 抛一整段崩溃堆栈。
> 另外 `test/run.mjs` 建 Window 时显式关掉了 happy-dom 的脚本加载 —— 否则它会真的去
> `fetch http://127.0.0.1:8787/js/app.js`，让测试依赖一个并不存在的服务器。

### 类型检查（棘轮）

`js/types.js` 里的 JSDoc typedef 不是文档 —— `js/` 里带 `// @ts-check` 的模块会被
`npx tsc --noEmit` 真正校验（typescript 只是 devDependency，运行时依然零依赖）。

全量 strict 检查最初有 **1366 个**错误，一次清零不现实；所以用**棘轮**：
`tools/typecheck.mjs` 里维护一份 `CHECKED` 清单，清单内的模块必须 **0 错误**，
清单外的只统计、不判失败。每清干净一个模块就加进去 —— **约束只会变严，不会变松**。

```bash
npm run typecheck    # 看闸门状态与待清理进度
```

顺带一个有用的自查（不在闸门里，但能找出多余 import）：

```bash
npx tsc --noEmit --noUnusedLocals     # TS6133 就是"导入了但没用到"
```

已知它拦得住的一类问题：把 `course.id` 写成 `course.nam` 会报 TS2339；
把 `tasklog` 的主键当成 `id`（真实是 `key`）同样报错 —— 后者正是当初静默丢打卡记录的事故形状。
`types.js` 里还有两条**编译期断言**：主键字段名必须真实存在于对应记录类型上、
`TaskLog` 不许有 `id`。给 `TaskLog` 加 `id` 会让 `TASKLOG_HAS_NO_ID` 报错，
强迫回头确认那个出过事故的设计。

> ⚠️ 用 `Set-Content` / `Out-File` 改这些文件会**按系统 ANSI 编码重写，破坏中文字符**并压掉换行
> （本会话踩过两次）。编辑一律用编辑器/`write` 工具。

### 工具链速查

活跃工具（`tools/`）——这些是日常会用的：

| 工具 | 作用 |
|---|---|
| `tools/bundle-for-test.mjs` | 把 `js/` 打成单个可评测文件供 `test/run.mjs` 使用 |
| `tools/syntax-check.mjs` | 逐模块语法检查 |
| `tools/esm-check.mjs` | 用 Node 的真实 ESM 语义校验模块图 |
| `tools/eval-order-check.mjs` | 7 种 import 顺序各起独立进程，确认模块顶层代码不依赖求值顺序 |
| `tools/archive.mjs` | 把当前 `js/` + 内联副本快照到 `tools/archive/`（回滚点） |
| `tools/server-test.mjs` | `server.py` 端到端：静态范围 / Origin 校验 / 凭证删除 / 备份往返 / keep-alive / 隔离性自检 |
| `tools/security-smoke.mjs` | 凭证删除接口 + CSRF 防护（自带隔离实例，不碰真实数据） |
| `tools/s5-smoke.mjs` | 附件二进制通道端到端（自带隔离实例） |
| `tools/browser-esm-check.mjs` | 经 HTTP 校验 `js/` 下全部模块的 Content-Type / 语法 / 互引用目标 |
| `tools/legacy-migration-test.py` | 旧格式备份的服务端迁移（Base64 → `blobs/`），逐字节核对 + 幂等 |
| `tools/run-python.mjs` | 用找到的 Python 跑上面的脚本（免得手写解释器路径） |
| `tools/backup-stats.mjs` | 统计当前备份里元数据与附件各占多少，量化 S5 的收益 |
| `tools/lib/isolated-server.mjs` | 为 server 类测试启动隔离实例（临时备份目录 + 凭证改名保护） |
| `tools/lib/replay-manifest.mjs` | 归档链条里的 patch 用它记录「应用/跳过了哪些改动」 |

归档工具（`tools/legacy/`）——日常不用，只在想重新验证可复现性时：

| 工具 | 作用 |
|---|---|
| `tools/legacy/rebuild-all.mjs` | 一键：基线 → 全部模块 → 全部改动 → 归档（**会覆盖 `js/`**） |
| `tools/legacy/baseline-inline.html` | 本轮重构**开始前**的单文件版本（干净基线） |
| `tools/legacy/original-inline.html` | 当前代码的「内联脚本」归档（带模块锚点注释） |
| `tools/legacy/restore-from-baseline.mjs` | 按归属表把基线切成模块（**注意：基线早于后续拆分，归属表已过时**，实际重建用 `rebuild-all.mjs`） |
| `tools/legacy/apply-all-fixes.mjs` | 重放 S1–S4、S6 接线、UI 与各轮评审修复 |
| `tools/legacy/s5-patch.mjs` | 重放 S5（附件二进制通道）改动 |
| `tools/legacy/generate.mjs` | 依据顶层声明生成 import / export |
| `tools/legacy/rebuild-canonical.mjs` | 把 `js/` 拼回带锚点的内联副本 |
| `tools/legacy/verify-replay.mjs` | 核对 patch 声称应用的改动是否**真的**落到产物里 |
| `tools/legacy/check-unsynced.mjs` | 重建前防呆：`js/` 若有未同步进补丁的改动就中止 |

> **「静默跳过」是重放链最容易出的错**：patch 用幂等探测判断「是否已应用」，
> 若探测字符串在新旧两版里都存在，就会把未打补丁的代码误判为已应用、整块替换直接跳过。
> 真实发生过一次（`exportData` 的 probe 用了旧版也有的 `JSON.stringify(backupMeta(data))`，
> 那处修复因此从没生效，而所有测试照常通过）。
> `verify-replay.mjs` 会用 patch 自己写出的清单核对：
> **凡是声称「已应用」或「已跳过」的改动，其新文本必须在产物里真实存在**，否则重建失败。

## 本地服务的安全边界

`server.py` 只监听 `127.0.0.1`，并且：

- **Host 白名单**：只接受 `127.0.0.1` / `localhost` / `::1`（挡 DNS rebinding）。
- **Origin / Referer 校验**：**有副作用**的接口拒绝非本机来源的请求 ——
  会改动磁盘的 `/api/autobackup/save`、`/api/autobackup/delete`、`/api/sessdata/delete`，
  以及会**发起出站请求**（消耗你的 API 额度）的 `/api/ai/generate-notes`、`/api/ai/analyze-mistake`、`/api/ai/test`。
  这是必要的：恶意网页对 `127.0.0.1` 发起的简单 POST 不需要预检，仅靠 Host 校验挡不住。
  对 AI 接口而言，"必须带 API Key"也挡不住 —— `base_url` 由请求方提供，不带真 Key 也能让本机去请求任意地址。
  命令行工具（curl 等）不带这两个头，视为安全放行。
- **AI 的 `base_url` 限制为 https**（本机模型可用 `http://127.0.0.1` / `http://localhost`）：见上一节的说明。
- **静态资源范围**：只伺服根目录的 `.html` 与 `js/` 下的 `.js`（其余路径 403/404，且做 `realpath` 包含性校验）。
- **凭证不入 URL**：`_sess` 只从请求头 `X-Sessdata` 或本机 `sessdata.txt` 读取，不接受 query 传参（避免凭证进日志）。
- 错误响应一律 `Connection: close`：某些错误分支在读完请求体之前就返回了，若不关连接，残留字节会让 keep-alive 的下一个请求被解析成垃圾。
- **路径可覆盖（供测试隔离）**：`STUDYDECK_AB_DIR`、`STUDYDECK_SESS_FILE` 可把备份目录与凭证文件指到别处；
  正常双击 bat 时不设置，行为不变。

## 备份架构（v3）

- **元数据**：课程 / 分集 / 笔记 / 任务 / 统计 + 附件清单（id、大小、类型），约百 KB。
- **附件二进制**：不再 Base64 进 JSON，而是独立通道 ——
  * 本机自动备份：`POST /api/autobackup/save` 用 `multipart/form-data` 上传原始字节，
    服务端写入 `_autobackup/blobs/<id>`；元数据存 `_autobackup/latest.json`。
  * 云备份：同步文件夹里 `studydeck-latest.json`（元数据）+ `blobs/<id>`（原始二进制）+ `snapshots/`（近 14 天元数据快照）。
  * 恢复：先按需把 `blobs` 拉回 IndexedDB（本机已有的不重复下载），再写元数据；
    最后 `auditAttachments()` 逐条核对，缺文件的标成「数据缺失」而不是留一条点不开的空记录。
- 旧格式（附件 Base64 内嵌在 `files[].data`）仍可正常恢复。**服务端会把它真正迁移**：
  保存时把内联 Base64 解出来写成 `blobs/<id>`，再把 `files[]` 换成清单。
  （早期实现只把 `data` 字段剥掉而**不落盘**，附件字节会永久丢失，且随后的清理还会清空已有附件 —— 已修，见 `npm run test:legacy`。）
- 附件永远不进 JSON；单个 >15MB 的附件连本机/云通道也跳过，导出时会弹窗说明，恢复后列表标记「数据缺失」。
- **导入会做形状校验**（与 courses/episodes 同一风格）：字段**类型错误**的记录会被丢弃，
  字段**缺失**的记录会保留（不能因为旧备份少一个可选字段就静默丢掉用户数据），
  改由下游的防御性读取兜住（`notesOfEp` 容忍缺 `epIds`、`openAttachment` 容忍缺 `type`）。
  版本检查只拒绝**比当前更新**的备份，所以手工改过或旧格式的备份也会走到这条路径。

## 已知边界与约定

- **`promptText` 目前没有被任何模块引用**，所以 `generate.mjs` 不会把它写进 `viewkit.js` 的 export 块
  （该脚本只导出「被别的模块用到的名字」）。这是「现成但暂时没用上的能力」，不是坏代码；
  等真有模块引用它，导出会自动出现。因此**不要用手工补丁去改 export 块** —— 它每次重建都会被重新生成。
- **`tools/` 里的 patch 脚本用幂等探测判断「是否已应用」**：探测字符串必须选「只有打过补丁后才出现」的文本。
  选错（新旧两版都有）会让整块替换被静默跳过，而所有测试照常通过 —— 这类问题由 `verify-replay.mjs` 兜底。
- **依赖图现在是干净的 DAG（无 import 环）。** 早先确实存在 `util⇄db`、`util⇄ui`、
  `app⇄views-dispatch`、`views-task⇄views-home` 这些环，当时"能跑"只是因为顶层代码只做
  事件注册与字面量初始化、不在求值期读取别的模块的绑定。后来把纯函数抽到零依赖的 `core.js`、
  把备份逻辑抽到 `settings-backup.js`，环已经**从结构上**消除了：
  `db`/`ui` 不再 import `util`，`app`/`views-dispatch` 不再互相 import。
  `npm run cycle` 会遍历整张图，发现任何环就失败；`test/run.mjs` 也有源码断言钉住方向。
  `tools/esm-check.mjs` 继续用 Node 的真实 ESM 语义守住「导出名必须真实存在」。

## 已知的结构性缺口：类型欠账 = 字符串 HTML

类型闸门现在覆盖 **15/24** 模块（`npm run typecheck` 的 `CHECKED` 列表）。
剩下 9 个模块还有约 300 个 `tsc` 错误，全部集中在**渲染大量用户数据**的视图 / 任务层
（`views-note`、`views-tasks`、`views-resources`、`task-utils`、`views-home`、`views-course`、
`views-history`、`task-timetable`）。已经清干净的 `views-dispatch`（设置页，结构固定）与
`views-stats`（图表为主）恰好不含这类代码 —— 这不是巧合。

根因是**这两件事其实是同一个问题**：视图层用字符串拼接 `innerHTML` 建 DOM，
而 DOM 在类型系统里没有形状。`n.title`、`a.type`、`c.color` 一旦拼进模板字符串，
编译器就再也管不到它们。这正是这些结构性缺陷能溜过去的原因：

- `tasklog` 的主键写成 `id`（真实是 `key`）→ 恢复时静默丢掉 12 条打卡记录
- `ep.fileName` 漏转义 → 可注入 HTML
- `parseSidx` 返回值被当数组用；`sbV` 的 TDZ 引用

因此**不要在视图模块上逐个加 `@param {HTMLElement}`**：实测那样会让错误**变多**
（`views-note.js` 71 → 110、`views-dispatch.js` 6 → 44），因为
`element.querySelector()` 返回 `Element|null`（没有 `.onclick`/`.dataset`/`.value`），
标注参数等于激活了整片 DOM 代码的检查。正确做法是二者之一：

1. **原子替换**：把该模块的 `querySelector` 全量换成 `core.js` 的 `$`/`$$`（返回 `any`），
   与参数标注在同一次改动里完成。`player.js` 已经这么做过（约 30 处）。
2. **引入极薄的元素构造抽象**（`h(tag, props, children)` 之类，几十行），让 DOM 结构
   进入类型系统。这一项投入能**同时**解决「类型」和「转义」两件事，
   是这两个缺口的共同出口。

在做到 1 或 2 之前，那些模块的 `n.title` 一类字段读取只能靠 `esc()` 纪律与现有测试兜底，
编译器管不到。这不是隐患（现有测试覆盖了已知的转义路径），但**约束确实没有全覆盖**。
