@echo off
chcp 65001 >nul
setlocal enableextensions
cd /d "%~dp0"
echo ========================================
echo   课业 StudyDeck - ffmpeg 安装工具
echo ========================================
echo.
echo 正在下载 ffmpeg（用于 MKV/AVI 等格式的转码播放）…
echo 下载源：GitHub BtbN 官方构建
echo.
rem 找 Python：与「启动课业（B站高清）.bat」同一套顺序（py 启动器 → PATH 上的 python
rem → 用户目录下的标准安装 → 豆包自带运行时）。
rem 以前这里直接写死 python：没装进 PATH 的机器会报「不是内部或外部命令」，
rem 而下面又一律提示「请检查网络」，诊断完全是错的 —— 而恰好是这些人需要这个工具。
set "PYEXE="
set "PYARG="
for /f "delims=" %%i in ('where py 2^>nul') do if not defined PYEXE set "PYEXE=%%i" & set "PYARG=-3"
if not defined PYEXE for /f "delims=" %%i in ('where python 2^>nul') do (
  echo %%i | find /i "WindowsApps" >nul || if not defined PYEXE set "PYEXE=%%i"
)
if not defined PYEXE for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python3*") do if exist "%%D\python.exe" if not defined PYEXE set "PYEXE=%%D\python.exe"
if not defined PYEXE for /d %%D in ("%LOCALAPPDATA%\Doubao\User Data\sandbox_runtime\bases\*") do if exist "%%D\python\python.exe" if not defined PYEXE set "PYEXE=%%D\python\python.exe"
if not defined PYEXE (
    echo [失败] 找不到 Python 3，无法自动下载。
    echo        请先安装 Python 3.8+ 并勾选 "Add python.exe to PATH"，
    echo        或者自己下载 ffmpeg.exe 放到本目录。
    echo.
    pause
    exit /b 1
)
"%PYEXE%" %PYARG% "%~dp0download_ffmpeg.py"
echo.
if exist "%~dp0ffmpeg.exe" (
    echo [成功] ffmpeg 已安装到程序目录。
    echo 现在可以在设置里指定媒体库目录，播放 MKV/AVI 等格式了。
) else (
    echo [失败] 下载或解压失败。国内访问 GitHub 常常需要代理，请检查网络后重试；
    echo        也可以自己下载 ffmpeg.exe 放到本目录。
)
echo.
pause
exit /b 0
