# -*- coding: utf-8 -*-
"""下载 ffmpeg Windows 构建，把 ffmpeg.exe 放到程序目录。
自动检测并使用系统代理（Clash / v2ray 等）。

用法：python download_ffmpeg.py   （或双击「安装ffmpeg.bat」）
退出码：0 成功（或已存在）/ 1 失败
"""
import os
import sys
import zipfile
import urllib.request
import shutil
import time

HERE = os.path.dirname(os.path.abspath(__file__))
TARGET = os.path.join(HERE, "ffmpeg.exe")
URL = "https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip"
TMPZIP = os.path.join(HERE, "_ffmpeg_download.zip")


def log(msg):
    print(msg, flush=True)


def proxy_from_value(raw):
    """把注册表 Internet Settings 里的 ProxyServer 值变成可用的代理 URL。

    这个值有三种常见形态（都真实存在）：
      · 127.0.0.1:7897                            单代理，不带 scheme
      · http://127.0.0.1:7897                     已经带 scheme
      · http=127.0.0.1:7897;https=127.0.0.1:7897  分协议

    以前是无条件在前面拼 "http://"：后两种会被拼成 http://http://… 或
    http://http=… —— 代理直接失效，下载必定失败，而用户只看到"下载失败"。
    """
    if not raw:
        return None
    v = str(raw).strip()
    if not v:
        return None
    if "=" in v:                       # 分协议形态：取 https，其次 http
        parts = {}
        for seg in v.split(";"):
            if "=" in seg:
                k, _, val = seg.partition("=")
                parts[k.strip().lower()] = val.strip()
        v = parts.get("https") or parts.get("http") or ""
        if not v:
            return None
    if "://" not in v:                 # 只有真的没 scheme 才补
        v = "http://" + v
    return v


def get_system_proxy():
    """读 Windows 系统代理；没开或读不到返回 None。"""
    try:
        import winreg
    except Exception:
        return None
    key = None
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                             r"Software\Microsoft\Windows\CurrentVersion\Internet Settings")
        enable, _ = winreg.QueryValueEx(key, "ProxyEnable")
        if not enable:
            return None
        server, _ = winreg.QueryValueEx(key, "ProxyServer")
        return proxy_from_value(server)
    except Exception:
        return None
    finally:
        # 以前只在成功分支 CloseKey：取值抛异常时句柄会泄漏
        if key is not None:
            try:
                winreg.CloseKey(key)
            except Exception:
                pass


def apply_proxy(proxy):
    """让 urllib 走这个代理。"""
    if not proxy:
        return
    os.environ["HTTPS_PROXY"] = proxy
    os.environ["HTTP_PROXY"] = proxy
    opener = urllib.request.build_opener(
        urllib.request.ProxyHandler({"https": proxy, "http": proxy}))
    urllib.request.install_opener(opener)
    log("使用代理: %s" % proxy)


def download():
    """下载 zip 到 TMPZIP；失败抛异常。"""
    req = urllib.request.Request(URL, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=120) as r, open(TMPZIP, "wb") as f:
        total = int(r.headers.get("Content-Length", 0))
        done = 0
        last = time.time()
        while True:
            chunk = r.read(1024 * 256)
            if not chunk:
                break
            f.write(chunk)
            done += len(chunk)
            now = time.time()
            if now - last > 3:
                pct = (done * 100 // total) if total else 0
                log("  下载中 %d%% (%d MB)" % (pct, done // 1048576))
                last = now
    log("下载完成 (%d MB)" % (os.path.getsize(TMPZIP) // 1048576))


def extract_ffmpeg(zip_path, target):
    """只把 zip 里的 ffmpeg.exe 写到 target（先写 .part 再原子改名）。

    只取这一个成员，而不是 extractall：
      · 少写上百 MB 的临时文件（包里还有 ffprobe/ffplay/文档）；
      · 从根上避免 zip 里带 ../ 或绝对路径时写到目标目录之外（zip slip）。
    """
    name = None
    with zipfile.ZipFile(zip_path, "r") as z:
        for n in z.namelist():
            norm = n.replace("\\", "/").rstrip("/")
            if norm.lower() == "ffmpeg.exe" or norm.lower().endswith("/ffmpeg.exe"):
                name = n
                break
        if name is None:
            return False
        tmp = target + ".part"
        try:
            with z.open(name) as src, open(tmp, "wb") as dst:
                shutil.copyfileobj(src, dst, 1024 * 256)
            if os.path.getsize(tmp) == 0:
                raise IOError("解压出来的 ffmpeg.exe 是空文件")
            os.replace(tmp, target)
            return True
        except Exception:
            try:
                os.remove(tmp)
            except Exception:
                pass
            raise


def main():
    if os.path.isfile(TARGET):
        log("ffmpeg.exe 已存在，跳过下载")
        return 0

    apply_proxy(get_system_proxy() or os.environ.get("HTTPS_PROXY")
                or os.environ.get("HTTP_PROXY"))

    log("开始下载 ffmpeg（压缩包约 190MB，只取其中的 ffmpeg.exe）…")
    try:
        download()
    except Exception as e:
        log("下载失败: %s" % e)
        return 1

    log("解压中…")
    try:
        if not extract_ffmpeg(TMPZIP, TARGET):
            log("错误：压缩包里没有找到 ffmpeg.exe")
            return 1
        log("已复制 ffmpeg.exe 到程序目录")
        log("ffmpeg 安装成功：%s" % TARGET)
        return 0
    except Exception as e:
        log("解压失败: %s" % e)
        return 1
    finally:
        # 无论成败都清掉下载包（以前解压失败时会把 80MB 留在程序目录里）
        try:
            if os.path.exists(TMPZIP):
                os.remove(TMPZIP)
        except Exception:
            pass


if __name__ == "__main__":
    sys.exit(main())
